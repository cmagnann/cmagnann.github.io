import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import ctypes
import threading
import os
import pandas as pd
import time
import gc
import pickle
import importlib.util
import psutil
import sys

# Importaciones para trabajar con openpyxl y validación de datos
from openpyxl import load_workbook
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment

# Variables globales para la selección de DJ y archivos
dj_seleccionado = None
dj_opciones = {}
dj_path = ""
txt_path = ""
registros_path = ""
output_path = ""

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Obtener la ruta del directorio del script
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    script_dir = os.getcwd()

# Cargar fase1.py dinámicamente (Fase 1 genera el archivo pickle)
fase1_path = os.path.join(script_dir, "fase1.py")
spec1 = importlib.util.spec_from_file_location("fase1", fase1_path)
fase1 = importlib.util.module_from_spec(spec1)
spec1.loader.exec_module(fase1)
ejecutar_fase1 = fase1.ejecutar_fase1

# Cargar fase2.py dinámicamente (Fase 2 usa el pickle generado)
fase222_path = os.path.join(script_dir, "fase222.py")
spec2 = importlib.util.spec_from_file_location("fase222", fase222_path)
fase222 = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(fase222)
ejecutar_fase222 = fase222.ejecutar_fase222

#########################
# Funciones de selección
#########################
def seleccionar_dj():
    global dj_path
    dj_path = filedialog.askopenfilename(filetypes=[("Archivos DJ", "*.xlsx;*.pkl")])
    if dj_path:
        label_dj.config(text=f"📂 DJ seleccionada: {os.path.basename(dj_path)}")

def seleccionar_txt():
    global txt_path
    txt_path = filedialog.askopenfilename(filetypes=[("Todos los archivos", "*.*"), ("Archivos TXT", "*.txt")])
    if txt_path:
        label_txt.config(text=f"📂 TXT seleccionado: {os.path.basename(txt_path)}")

def seleccionar_dj_inicial():
    ventana = tk.Toplevel(root)
    ventana.title("Seleccionar Declaración Jurada")
    ventana.geometry("300x150")
    ventana.configure(bg="#B1C5F1")  # Fondo de la ventana
    ventana.grab_set()  # Modal: bloquea la ventana principal

    # Etiqueta de instrucción con fondo y fuente coherentes
    tk.Label(ventana, text="Seleccione la DJ a procesar:", bg="#B1C5F1",
             font=("Arial", 12)).pack(pady=10)
    
    # Opciones de DJ
    opciones = {
        "DJ 1889": resource_path(os.path.join("fases", "1889listo.py")),
        "DJ 1891": resource_path(os.path.join("fases", "1891listo.py")),
        "DJ 1899": resource_path(os.path.join("fases", "1899listo.py")),
        "DJ 1894": resource_path(os.path.join("fases", "1894listo.py")),
        "DJ 1932": resource_path(os.path.join("fases", "1932listo.py")),
        "DJ 1949": resource_path(os.path.join("fases", "1949listo.py")),
        "DJ 1922": resource_path(os.path.join("fases", "1922.py")),
        "DJ 1944": resource_path(os.path.join("fases", "1944listo.py")),
        "DJ 1871": resource_path(os.path.join("fases", "1871listo.py")),
        "DJ 1870": resource_path(os.path.join("fases", "1870listo.py")),
        "DJ 1862": resource_path(os.path.join("fases", "1862listo.py")),
        "Ninguna": "Ninguna"   # Valor especial para indicar que no se ejecuta script
    }
    var_seleccion = tk.StringVar(value="Ninguna")
    
    # Crear y configurar el OptionMenu con los estilos solicitados
    option_menu = tk.OptionMenu(ventana, var_seleccion, *opciones.keys())
    option_menu.config(bg="#EC7B0A", fg="white", font=("Arial", 12, "bold"))
    option_menu["menu"].config(bg="#EC7B0A", fg="white", font=("Arial", 12, "bold"))
    option_menu.pack(pady=10)
    
    # Botón Confirmar con estilo
    confirm_button = tk.Button(ventana, text="Confirmar", command=ventana.destroy,
                               bg="green", fg="white", font=("Arial", 12, "bold"))
    confirm_button.pack(pady=10)
    
    root.wait_window(ventana)
    return var_seleccion.get(), opciones

def seleccionar_y_ejecutar_dj():
    """
    Utiliza la opción ya seleccionada (almacenada en las variables globales)
    para ejecutar el script de la DJ sin mostrar otro modal.
    Si se selecciona "Ninguna", se omite la ejecución y se deja el último archivo modificado.
    """
    global dj_seleccionado, dj_opciones
    opcion = dj_seleccionado
    if opcion == "Ninguna":
        messagebox.showinfo("Información", "Se utilizará el último archivo modificado sin aplicar ningún script adicional.")
        return
    script_path = dj_opciones.get(opcion)
    if script_path and os.path.exists(script_path):
        try:
            spec = importlib.util.spec_from_file_location("dj_especifico", script_path)
            dj_modulo = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(dj_modulo)
            if hasattr(dj_modulo, "procesar_dj"):
                dj_modulo.procesar_dj()  # Se asume que este script usa el archivo modificado ya generado
                messagebox.showinfo("Ejecutado", f"Se ejecutó correctamente {opcion}.")
            else:
                messagebox.showerror("Error", f"El módulo {script_path} no tiene la función 'procesar_dj'.")
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error al ejecutar {opcion}:\n{str(e)}")
    else:
        messagebox.showerror("Error", f"No se encontró el archivo: {script_path}")

#############################
# Funciones de procesamiento
#############################
def procesar_modificacion():
    global output_path
    if not output_path or not os.path.exists(output_path):
        messagebox.showerror("Error", "❌ No se encontró el archivo de Fase 2 para modificar.")
        return

    modificado_path = output_path.replace(".xlsx", "_modificado.xlsx")
    try:
        hojas_modificadas = {}
        with pd.ExcelFile(output_path) as xls:
            for sheet_name in xls.sheet_names:
                df = pd.read_excel(xls, sheet_name=sheet_name, header=None)
                df_modificado = procesar_hoja(df)
                hojas_modificadas[sheet_name] = df_modificado

        # Guardar las hojas modificadas en un nuevo archivo sin fusión aún
        with pd.ExcelWriter(modificado_path, engine='openpyxl') as writer:
            for sheet_name, df in hojas_modificadas.items():
                df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

        # Primero: Eliminar columnas que solo tienen datos en la primera fila
        eliminar_columnas_solo_primera_fila(modificado_path)
        # Luego: Aplicar la fusión de celdas en la primera fila (estético)
        fusionar_celdas_en_excel(modificado_path)

        wb_mod = load_workbook(modificado_path)
        for sheet_name in wb_mod.sheetnames:
            ws = wb_mod[sheet_name]
            header = [cell.value for cell in ws[1]]
            # Si existe la columna "Validar", se añade validación de datos
            if "Validar" in header:
                col_index = header.index("Validar") + 1
                col_letter = get_column_letter(col_index)
                last_row = ws.max_row
                dv = DataValidation(type="list", formula1='"☐,☑"', allow_blank=True)
                ws.add_data_validation(dv)
                dv.add(f"{col_letter}2:{col_letter}{last_row}")
            # Ajustar el ancho de cada columna evitando el error con MergedCell
            for col_idx in range(1, ws.max_column + 1):
                col_letter = get_column_letter(col_idx)
                max_length = 0
                for cell in ws[col_letter]:
                    try:
                        if cell.value:
                            cell_length = len(str(cell.value))
                            if cell_length > max_length:
                                max_length = cell_length
                    except Exception:
                        pass
                ws.column_dimensions[col_letter].width = max_length + 2
        wb_mod.save(modificado_path)
        wb_mod.close()
        del wb_mod
        gc.collect()

        if os.path.exists(output_path):
            os.remove(output_path)
        output_path = modificado_path

        # Aquí se fija la ruta del archivo modificado en la variable de entorno
        os.environ["MODIFIED_FILE"] = output_path

    except Exception as e:
        messagebox.showerror("Error", f"❌ Ocurrió un error en la modificación:\n{str(e)}")



def procesar():
    global dj_seleccionado, dj_opciones, dj_path, txt_path, output_path

    if not dj_path or not txt_path:
        messagebox.showwarning("Error", "⚠️ Debes seleccionar ambos archivos (DJ y TXT).")
        return

    # Paso 2: Mostrar modal de selección inicial y almacenar la elección
    dj_seleccionado, dj_opciones = seleccionar_dj_inicial()

    try:
        # Paso 3: Ejecutar Fase 1 y Fase 2
        base_dir = os.path.dirname(txt_path)
        output_dir = os.path.join(base_dir, "Archivos Procesados")
        os.makedirs(output_dir, exist_ok=True)

        messagebox.showinfo("Procesando", "⏳ Ejecutando Fase 1...")
        registros_path = os.path.join(output_dir, "cmagnanregistros.pkl")
        ejecutar_fase1(dj_path, output_dir)

        if not os.path.exists(registros_path):
            messagebox.showerror("Error", f"❌ No se encontró el archivo Pickle en:\n{registros_path}")
            return

        messagebox.showinfo("Procesando", "⏳ Ejecutando Fase 2...")
        resultados = ejecutar_fase222(txt_path, registros_path)
        if not resultados:
            messagebox.showerror("Error", "❌ Error en Fase 2. Verifica el archivo TXT.")
            return

        # Paso 4: Guardar el archivo intermedio
        output_path = os.path.join(output_dir, "Registros_Validados.xlsx")
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            for registro, df in resultados:
                if "Registro2_Validacion" in registro:
                    df = df.loc[:, df.columns != "LARGO DEL REGISTRO"]
                df.to_excel(writer, sheet_name=registro[:31], index=False)

        # Ajustar validaciones y anchos
        wb = load_workbook(output_path)
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            header = [cell.value for cell in ws[1]]
            if "Validar" in header:
                col_index = header.index("Validar") + 1
                col_letter = get_column_letter(col_index)
                last_row = ws.max_row
                dv = DataValidation(type="list", formula1='"☐,☑"', allow_blank=True)
                ws.add_data_validation(dv)
                dv.add(f"{col_letter}2:{col_letter}{last_row}")
            for col in ws.columns:
                max_length = 0
                column = col[0].column_letter
                for cell in col:
                    try:
                        if cell.value:
                            cell_length = len(str(cell.value))
                            if cell_length > max_length:
                                max_length = cell_length
                    except:
                        pass
                ws.column_dimensions[column].width = max_length + 2
        wb.save(output_path)

        # Paso 5: Procesar modificación para generar el archivo modificado
        procesar_modificacion()

        # Paso 6: Ejecutar el script de la DJ seleccionado (si no se eligió "Ninguna")
        seleccionar_y_ejecutar_dj()

    except Exception as e:
        messagebox.showerror("Error", f"❌ Ocurrió un error:\n{str(e)}")

#############################
# Funciones auxiliares de Excel
#############################
def eliminar_columnas_vacias(df):
    df = df.dropna(axis=1, how='all')
    df.columns = range(df.shape[1])
    return df

def procesar_hoja(df):
    df = eliminar_columnas_vacias(df)
    primera_fila_modificada = df.iloc[0].copy()
    ultimo_valor_encontrado = None
    indice_origen = None
    for i in range(len(primera_fila_modificada)):
        if pd.notna(primera_fila_modificada[i]):
            if indice_origen is not None and indice_origen != i - 1:
                primera_fila_modificada[indice_origen] = f"{primera_fila_modificada[indice_origen]} Padre"
            ultimo_valor_encontrado = primera_fila_modificada[i]
            indice_origen = i
        elif ultimo_valor_encontrado is not None:
            primera_fila_modificada[i] = ultimo_valor_encontrado
    df.iloc[0] = primera_fila_modificada
    columnas_a_eliminar = [i for i in range(len(primera_fila_modificada)) if "Padre" in str(primera_fila_modificada[i])]
    df = df.drop(columns=df.columns[columnas_a_eliminar])
    return df

def fusionar_celdas_en_excel(archivo):
    wb = load_workbook(archivo)
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        col_inicio = None
        valor_anterior = None
        for col in range(1, ws.max_column + 1):
            celda = ws.cell(row=1, column=col)
            if celda.value == valor_anterior:
                if col_inicio is None:
                    col_inicio = col - 1
            else:
                if col_inicio is not None:
                    ws.merge_cells(start_row=1, start_column=col_inicio, end_row=1, end_column=col-1)
                    ws.cell(row=1, column=col_inicio).alignment = Alignment(horizontal="center", vertical="center")
                col_inicio = None
                valor_anterior = celda.value
        if col_inicio is not None:
            ws.merge_cells(start_row=1, start_column=col_inicio, end_row=1, end_column=ws.max_column)
            ws.cell(row=1, column=col_inicio).alignment = Alignment(horizontal="center", vertical="center")
    wb.save(archivo)

def eliminar_columnas_solo_primera_fila(archivo):
    wb = load_workbook(archivo)
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        for col in range(ws.max_column, 0, -1):
            if ws.cell(row=1, column=col).value not in (None, ''):
                solo_primera = True
                for row in range(2, ws.max_row + 1):
                    if ws.cell(row=row, column=col).value not in (None, ''):
                        solo_primera = False
                        break
                if solo_primera:
                    ws.delete_cols(col)
    wb.save(archivo)

def procesar_wrapper():
    progress_bar.start()  # Inicia la animación del cargador
    procesar()            # Ejecuta la función de procesamiento original
    # Detiene la animación en el hilo principal
    root.after(0, progress_bar.stop)

def iniciar_proceso():
    # Ejecuta 'procesar_wrapper' en un hilo separado para no bloquear la UI
    threading.Thread(target=procesar_wrapper).start()


#############################
# Interfaz Gráfica
#############################
root = tk.Tk()
root.title("Automatización DJs")
root.geometry("280x310")

progress_bar = ttk.Progressbar(root, mode='indeterminate')
progress_bar.pack(pady=10)

# Cambiamos el color de fondo de toda la interfaz
root.configure(bg="#B1C5F1")


btn_dj = tk.Button(root, text="Seleccionar DJ", command=seleccionar_dj, 
                   bg="#EC7B0A", fg="white", font=("Arial", 12, "bold"))
btn_dj.pack(pady=10)

label_dj = tk.Label(root, text="📂 Ninguna DJ seleccionada")
label_dj.pack()

btn_txt = tk.Button(root, text="Seleccionar TXT", command=seleccionar_txt, 
                        bg="#EC7B0A", fg="white", font=("Arial", 12, "bold"))
btn_txt.pack(pady=10)

label_txt = tk.Label(root, text="📂 Ningún TXT seleccionado")
label_txt.pack()

# Aquí se asigna la función que inicia el hilo en lugar de llamar a procesar directamente
btn_procesar = tk.Button(root, text="Procesar Archivos", command=iniciar_proceso, 
                         bg="green", fg="white", font=("Arial", 12, "bold"))
btn_procesar.pack(pady=20)

root.update()  # Se actualiza la ventana para tener las dimensiones definidas
#redondear_ventana_parcial(root, 20)  # Aplica el redondeo de bordes (solo en Windows)


root.mainloop()
