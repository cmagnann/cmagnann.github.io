import pandas as pd
import os
import pickle
from openpyxl import Workbook

def contar_tablas_y_organizar(excel_path):
    """Procesa el archivo DJ 1889 Excel y estructura los registros"""
    # Cargar el archivo Excel
    xls = pd.ExcelFile(excel_path)
    sheet_name = xls.sheet_names[0]  # Tomamos la primera hoja
    df = pd.read_excel(xls, sheet_name, dtype=str, header=None)
    
    # Reemplazar NaN con cadenas vacías
    df.fillna("", inplace=True)
    
    # Identificar las filas que contienen "Nº" en la columna A
    encabezados = df[df.iloc[:, 0].str.contains("Nº", na=False)].index.tolist()
    
    # Crear una estructura para almacenar los registros y sus tablas
    registros = {}
    registros_dinamicos = {}
    
    for i, encabezado in enumerate(encabezados):
        if i < len(encabezados) - 1:
            tabla = df.iloc[encabezado:encabezados[i+1], :].reset_index(drop=True)
        else:
            tabla = df.iloc[encabezado:, :].reset_index(drop=True)
        
        # Ajustar el encabezado de la tabla
        tabla.columns = tabla.iloc[0]  # La primera fila se convierte en encabezado
        tabla = tabla[1:].reset_index(drop=True)  # Eliminar la fila de encabezado duplicada
        
        # Modificar el encabezado de las columnas C, D y E con los valores de la primera fila después del encabezado
        nuevos_encabezados = list(tabla.columns)
        nuevos_encabezados[2] = "SUBCAMPOS"  # Asignar nombre fijo a la columna C
        nuevos_encabezados[3] = tabla.iloc[0, 3]  # Asignar el valor de la primera fila como encabezado de la columna D
        nuevos_encabezados[4] = tabla.iloc[0, 4]  # Asignar el valor de la primera fila como encabezado de la columna E
        tabla.columns = nuevos_encabezados
        tabla = tabla[1:].reset_index(drop=True)  # Eliminar la fila duplicada
        
        # Obtener el número de registro desde la columna Validaciones
        num_registro = tabla.iloc[0, -1].strip()  # Última columna sin espacios
        if num_registro:
            numero_registro = f"Registro{num_registro}"
        else:
            numero_registro = f"Registro{tabla.iloc[1, -1].strip()}.{tabla.iloc[2, -1].strip()}"

        # Limpiar el formato del nombre del registro
        numero_registro = numero_registro.replace("=", "").replace(" ", "")  # Eliminar caracteres no deseados
        
        # Convertir toda la tabla a string explícitamente antes de analizar filas vacías
        tabla = tabla.astype(str)

        # Eliminar espacios sobrantes en cada celda (inicios y finales)
        tabla = tabla.apply(lambda col: col.str.strip() if col.dtype == "object" else col)

        # ── BLOQUE DE ELIMINACIÓN DE FILAS ──
        # 1) Filas completamente vacías (todas las celdas vacías)
        filas_vacias = tabla.eq("", axis=1).all(axis=1)

        # 2) Filas donde la columna "CAMPOS" tenga "blanco" o "blancos"
        #if "CAMPOS" in tabla.columns:
         #   filas_blancos = tabla["CAMPOS"].str.strip().str.lower().isin(["blanco", "blancos"])
        #else:
         #   filas_blancos = pd.Series(False, index=tabla.index)

        # 3) Filas que solo tengan contenido en la columna "Nº" y el resto vacío
        if "Nº" in tabla.columns:
            filas_solo_num = (tabla["Nº"].str.strip() != "") & tabla.drop(columns=["Nº"], errors="ignore").eq("", axis=1).all(axis=1)
        else:
            filas_solo_num = pd.Series(False, index=tabla.index)
        # Combinar condiciones y eliminar filas
        indices_a_eliminar = filas_vacias | filas_solo_num

        tabla = tabla[~indices_a_eliminar].reset_index(drop=True)
        
        # Almacenar la tabla dentro del registro correspondiente
        if numero_registro not in registros:
            registros[numero_registro] = []
        registros[numero_registro].append(tabla)
        
        # Guardar en la variable dinámica
        if numero_registro not in registros_dinamicos:
            registros_dinamicos[numero_registro] = []
        registros_dinamicos[numero_registro].append(tabla)
    
    return registros, registros_dinamicos

def ejecutar_fase1(dj_path, output_dir):
    """
    Ejecuta la Fase 1 del procesamiento.
    - dj_path: Ruta del archivo DJ 1889 Excel
    - output_dir: Carpeta donde se guardarán los archivos generados
    """
    try:
        registros_estructurados, registros_dinamicos = contar_tablas_y_organizar(dj_path)

        # Guardar registros_dinamicos para la fase 2
        registros_path = os.path.join(output_dir, "cmagnanregistros.pkl")
        with open(registros_path, "wb") as f:
            pickle.dump(registros_dinamicos, f)

        # Guardar todos los registros en un único archivo Excel
        output_path = os.path.join(output_dir, "Registros_Estructurados.xlsx")
        wb = Workbook()
        del wb[wb.active.title]  # Eliminar la hoja por defecto

        for registro, tablas in registros_estructurados.items():
            for idx, tabla in enumerate(tablas):
                sheet_name = f"{registro}_{idx+1}" if len(tablas) > 1 else registro
                sheet_name = sheet_name[:31]  # Limitar a 31 caracteres
                ws = wb.create_sheet(title=sheet_name)

                for r_idx, row in enumerate([tabla.columns.tolist()] + tabla.values.tolist(), start=1):
                    ws.append(row)

        wb.save(output_path)

        print(f"✅ Fase 1 completada. Archivo guardado: {output_path}")
        return output_path  # Devuelve la ruta del archivo para Fase 2

    except Exception as e:
        print(f"❌ Error en Fase 1: {e}")
        return None
