import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Border, Side, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import os

def acceder_hojas(modified_file_path, lista_hojas=None):
    """
    Función base para acceder a las hojas necesarias de un archivo Excel modificado.
    Se puede reutilizar para aplicar reglas especiales a distintos DJ.
    
    Args:
        modified_file_path (str): Ruta del archivo Excel modificado.
        lista_hojas (list): Lista de nombres de hojas requeridas. Si se omite,
                             se usan por defecto ["Registro3_Validacion", "Registro2_Validacion"].
    
    Returns:
        tuple: (hojas, workbook)
               hojas: Diccionario con las hojas extraídas (clave: nombre de la hoja, valor: objeto worksheet).
               workbook: Objeto workbook de openpyxl, que se debe cerrar o guardar posteriormente.
    """
    if lista_hojas is None:
        lista_hojas = ["Registro3.1_Validacion", "Registro2_Validacion", "Registro3.2_Validacion"]
    try:
        wb = load_workbook(modified_file_path)
    except Exception as e:
        print(f"Error al abrir {modified_file_path} con openpyxl: {e}")
        return None, None

    hojas = {}
    for hoja in lista_hojas:
        if hoja in wb.sheetnames:
            hojas[hoja] = wb[hoja]
        else:
            print(f"La hoja '{hoja}' no se encontró en el archivo modificado.")
    return hojas, wb

def procesar_dj():
    # Rutas específicas para DJ 1894 (archivo de entrada y salida)
    modified_file = os.environ.get("MODIFIED_FILE")
    if not modified_file or not os.path.exists(modified_file):
        print("No se encontró el archivo modificado.")
        return

    # Define la ruta de salida para este DJ de forma dinámica
    output_file = os.path.join(os.path.dirname(modified_file), "Registros_Validados_1899.xlsx")
    # Accedemos a las tres hojas requeridas para DJ 1899:
    # "Registro2_Validacion", "Registro3.1_Validacion" y "Registro3.2_Validacion"
    hojas, wb = acceder_hojas(modified_file, lista_hojas=["Registro2_Validacion", "Registro3.1_Validacion", "Registro3.2_Validacion"])
    if wb is None:
        print("No se pudo abrir el archivo modificado.")
        return

    # Crear la nueva hoja especial para DJ 1899
    ws = wb.create_sheet("Comparativa R3 y R2")
    ws2 = hojas["Registro2_Validacion"]
    ws_detalle = wb.create_sheet("Detalle RentaB")

    # Aplicar fusiones y asignar valores estéticos (inicio común)
    ws.merge_cells("A1:E1")
    ws["A1"] = "Comparativa de Registro3 con Registro2"
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.column_dimensions["A"].width = 50

    ws.merge_cells("A3:B3")
    ws["A3"] = "Datos Registro3"
    ws["A3"].alignment = Alignment(horizontal="center", vertical="center")
    
    # Extraer valores de las hojas:
    hoja31 = hojas["Registro3.1_Validacion"]
    hoja32 = hojas["Registro3.2_Validacion"]
    
    # --- Se desplazan todas las asignaciones una fila hacia abajo ---
    # 1. Fusionar A5:B5 y asignar el valor de A12 de hoja31
    ws.merge_cells("A5:B5")
    ws["A5"] = hoja31["A12"].value

    # 2. Extraer de hoja31:
    #    - B13 se asigna en A6
    #    - B14 se asigna en A7
    ws["A6"] = hoja31["B13"].value
    ws["A7"] = hoja31["B14"].value

    # 3. Extraer de hoja31:
    #    - D13 se asigna en B6
    #    - D14 se asigna en B7
    ws["B6"] = hoja31["D13"].value
    ws["B7"] = hoja31["D14"].value

    # 4. Extraer de hoja31:
    #    - A15 se asigna en la celda fusionada A9:B9
    ws.merge_cells("A9:B9")
    ws["A9"] = hoja31["A15"].value

    #    - A16 se asigna en la celda fusionada A10:B10
    ws.merge_cells("A10:B10")
    ws["A10"] = hoja31["A16"].value

    # 5. Extraer de hoja31:
    #    - B17, B18, B19, B20, B21, B22 se asignan en A11, A12, A13, A14, A15, A16 respectivamente
    ws["A11"] = hoja31["B17"].value
    ws["A12"] = hoja31["B18"].value
    ws["A13"] = hoja31["B19"].value
    ws["A14"] = hoja31["B20"].value
    ws["A15"] = hoja31["B21"].value
    ws["A16"] = hoja31["B22"].value

    # 6. Extraer de hoja31:
    #    - D17, D18, D19, D20, D21, D22 se asignan en B11, B12, B13, B14, B15, B16 respectivamente
    ws["B11"] = hoja31["D17"].value
    ws["B12"] = hoja31["D18"].value
    ws["B13"] = hoja31["D19"].value
    ws["B14"] = hoja31["D20"].value
    ws["B15"] = hoja31["D21"].value
    ws["B16"] = hoja31["D22"].value

    # 7. Extraer de hoja31:
    #    - A23 se asigna en la celda fusionada A18:B18
    ws.merge_cells("A18:B18")
    ws["A18"] = hoja31["A23"].value

    # 8. Extraer de hoja31:
    #    - B24, B25, B26, B27 se asignan en A19, A20, A21, A22 respectivamente
    ws["A19"] = hoja31["B24"].value
    ws["A20"] = hoja31["B25"].value
    ws["A21"] = hoja31["B26"].value
    ws["A22"] = hoja31["B27"].value

    # 9. Extraer de hoja31:
    #    - D24, D25, D26, D27 se asignan en B19, B20, B21, B22 respectivamente
    ws["B19"] = hoja31["D24"].value
    ws["B20"] = hoja31["D25"].value
    ws["B21"] = hoja31["D26"].value
    ws["B22"] = hoja31["D27"].value

    # 10. Extraer de hoja31:
    #     - A28 se asigna en la celda fusionada A24:B24
    ws.merge_cells("A24:B24")
    ws["A24"] = hoja31["A28"].value
    #     - A29 se asigna en la celda fusionada A25:B25
    ws.merge_cells("A25:B25")
    ws["A25"] = hoja31["A29"].value

    # 11. Extraer de hoja31:
    #     - B30, B31, B32, B33 se asignan en A26, A27, A28, A29 respectivamente
    ws["A26"] = hoja31["B30"].value
    ws["A27"] = hoja31["B31"].value
    ws["A28"] = hoja31["B32"].value
    ws["A29"] = hoja31["B33"].value

    # 12. Extraer de hoja31:
    #     - D30, D31, D32, D33 se asignan en B26, B27, B28, B29 respectivamente
    ws["B26"] = hoja31["D30"].value
    ws["B27"] = hoja31["D31"].value
    ws["B28"] = hoja31["D32"].value
    ws["B29"] = hoja31["D33"].value

    # 13. Extraer de hoja31:
    #     - A34 se asigna en la celda fusionada A31:B31
    ws.merge_cells("A31:B31")
    ws["A31"] = hoja31["A34"].value
    #     - B35 y B36 se asignan en A32 y A33 respectivamente
    ws["A32"] = hoja31["B35"].value
    ws["A33"] = hoja31["B36"].value
    #     - D35 y D36 se asignan en B32 y B33 respectivamente
    ws["B32"] = hoja31["D35"].value
    ws["B33"] = hoja31["D36"].value

    # 14. Extraer de hoja32 (Registro3.2_Validacion):
    #     - A5 se asigna en la celda fusionada A36:B36
    ws.merge_cells("A36:B36")
    ws["A36"] = hoja32["A5"].value
    #     - A6 se asigna en la celda fusionada A37:B37
    ws.merge_cells("A37:B37")
    ws["A37"] = hoja32["A6"].value

    # 15. Extraer de hoja32:
    #     - B7 se asigna en A38
    ws["A38"] = hoja32["B7"].value
    #     - B8 se asigna en A39
    ws["A39"] = hoja32["B8"].value

    # 16. Extraer de hoja32:
    #     - D7 se asigna en B38
    ws["B38"] = hoja32["D7"].value
    #     - D8 se asigna en B39
    ws["B39"] = hoja32["D8"].value

    ws["A41"] = hoja32["A9"].value
    ws["B41"] = hoja32["D9"].value
    ws["A43"] = hoja32["A10"].value
    ws["B43"] = hoja32["D10"].value
    ws["A45"] = hoja32["A11"].value
    ws["B45"] = hoja32["D11"].value

    # 17. Bloque Nuevo: Fusionar D3:E3 e ingresar "Datos Registro 2"
    ws.merge_cells("D3:E3")
    ws["D3"] = "Datos Registro 2"
    ws["D3"].alignment = Alignment(horizontal="center", vertical="center")


 # 18. Bloque Nuevo: Copiar, a partir de la fila 5, todos los datos de la columna A en la columna E
    # (Desde E5 en adelante)
    for row in range(5, ws.max_row + 1):
        cell_a = ws.cell(row=row, column=1)
        # Buscamos si la celda A está en un rango combinado
        rango_combinado = None
        for mrange in ws.merged_cells.ranges:
            if cell_a.coordinate in mrange:
                rango_combinado = mrange
                break

        # Si la celda A forma parte de un rango combinado de A:B
        if rango_combinado and rango_combinado.min_col == 1 and rango_combinado.max_col == 2:
            # Fusionamos las celdas D y E en esa fila
            ws.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)
            # Se asigna el valor a la celda superior (D) de la celda fusionada
            ws.cell(row=row, column=4).value = cell_a.value
        else:
            # Si no está combinada, copia el valor de A a la columna E normalmente
            ws.cell(row=row, column=5).value = cell_a.value

# DEFINICIÓN DE ESTILOS
    thick_border = Border(left=Side(style="thick"),
                          right=Side(style="thick"),
                          top=Side(style="thick"),
                          bottom=Side(style="thick"))
    thin_border = Border(left=Side(style="thin"),
                         right=Side(style="thin"),
                         top=Side(style="thin"),
                         bottom=Side(style="thin"))
    font_TT14 = Font(bold=True, size=14)
    font_TT12 = Font(bold=True, size=12)
    fill_60 = PatternFill("solid", fgColor="8DB4E2")  # Azul oscuro con claro 40%
    fill_80 = PatternFill("solid", fgColor="BDD7EE")  # Azul oscuro con claro 60%
    # Para Grupo 3 y 4 se reutiliza fill_60 en este ejemplo
    center_alignment = Alignment(horizontal="center", vertical="center")
    # Aplicar estilos a la fila de encabezado (A1:E1)
    for row in ws["A1:E1"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango A3:B3
    for row in ws["A3:B3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango D3:E3
    for row in ws["D3:E3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment


    # Ajustar anchos de columnas para mejorar la apariencia
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 15
    ws.column_dimensions["C"].width = 15
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 30

    # 19. Bloque Nuevo: Extraer de hoja2 (Registro2_Validacion)
    # Traer todas las columnas desde M hasta AG (columnas 13 a 33) de la hoja2,
    # e insertarlas en la nueva hoja a partir de la columna L (columna 12).
    # Se copia la fila 1 y 2 sin transformación; a partir de la fila 3 se convierten a enteros.
    for r in range(1, ws2.max_row + 1):
        for c in range(13, 34):  # Columnas M (13) hasta AG (33) inclusive
            val = ws2.cell(row=r, column=c).value
            if r < 3:
                new_val = val  # Sin transformación para las dos primeras filas
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            # Insertar en la nueva hoja: la columna destino es c - 1 (de modo que M=13 se inserta en L=12, etc.)
            ws.cell(row=r, column=c - 1).value = new_val


    ultima_fila = ws.max_row

    ws["D6"].value = f"=SUM(L3:L{ultima_fila}) + INT(SUM(M3:M{ultima_fila})/1000)"
    ws["D7"].value = f"=MOD(SUM(M3:M{ultima_fila}),1000)"
    ws["D11"].value = f"=SUM(N3:N{ultima_fila}) + INT(SUM(O3:O{ultima_fila})/1000)"
    ws["D12"].value = f"=MOD(SUM(O3:O{ultima_fila}),1000)"
    ws["D13"].value = f"=SUM(P3:P{ultima_fila}) + INT(SUM(Q3:Q{ultima_fila})/1000)"
    ws["D14"].value = f"=MOD(SUM(Q3:Q{ultima_fila}),1000)"
    ws["D15"].value = f"=SUM(R3:R{ultima_fila})"   # Columna 18 -> R
    ws["D16"].value = f"=SUM(S3:S{ultima_fila})"   # Columna 19 -> S
    ws["D19"].value = f"=SUM(T3:T{ultima_fila}) + INT(SUM(U3:U{ultima_fila})/1000)"
    ws["D20"].value = f"=MOD(SUM(U3:U{ultima_fila}),1000)"

    ws["D21"].value = f"=SUM(V3:V{ultima_fila}) + INT(SUM(W3:W{ultima_fila})/1000)"
    ws["D22"].value = f"=MOD(SUM(W3:W{ultima_fila}),1000)"

    ws["D26"].value = f"=SUM(X3:X{ultima_fila}) + INT(SUM(Y3:Y{ultima_fila})/1000)"
    ws["D27"].value = f"=MOD(SUM(Y3:Y{ultima_fila}),1000)"

    ws["D28"].value = f"=SUM(Z3:Z{ultima_fila}) + INT(SUM(AA3:AA{ultima_fila})/1000)"
    ws["D29"].value = f"=MOD(SUM(AA3:AA{ultima_fila}),1000)"

    ws["D32"].value = f"=SUM(AB3:AB{ultima_fila}) + INT(SUM(AC3:AC{ultima_fila})/1000)"
    ws["D33"].value = f"=MOD(SUM(AC3:AC{ultima_fila}),1000)"

    ws["D41"].value = f"=SUM(AE3:AE{ultima_fila})" # Columna 31 -> AE
    ws["D43"].value = f"=SUM(AF3:AF{ultima_fila})" # Columna 32 -> AF

    # Si la hoja ws2 tiene los datos de H, y quieres contar celdas con contenido:
    ws["D45"].value = f"=COUNTA('Registro2_Validacion'!H3:H1048576)"

    for row in range(1, ultima_fila + 1):
        # Extraer el valor de la columna J de ws2 (J es la 10ª columna)
        valor = ws2[f"J{row}"].value
        # Colocar ese valor en la columna K de ws (K es la 11ª columna)
        ws[f"K{row}"].value = valor

    # Nuevo arreglo de longitudes:
    # - Para ws2 (Registro2_Validacion): 14 columnas
    #   A: 1, B: 4, C: 1, D: 7, E: 1, F: 8, G: 1, H: 8, I: 1, J: 1, K: 8, L: 1,
    #   AH: 7, AI: 7
    # - Para ws (Comparativa R3 y R2): 21 columnas (de L a AF)
    #   Se mantienen los siguientes 21 números: 10, 3, 10, 3, 10, 3, 10, 10, 10, 3, 10, 3, 10, 3, 10, 3, 10, 3, 12, 12, 12

    from openpyxl.utils import get_column_letter
    # Definir el arreglo de longitudes (35 números en total)
    arr_longitudes = [
        # Para ws2, parte 1 (A a L: 12 columnas)
        1, 4, 1, 7, 1, 8, 1, 8, 1, 1, 8, 1,
        # Para ws (Comparativa R3 y R2): 21 columnas (por ejemplo, de L a AF)
        10, 3, 10, 3, 10, 3, 10, 10, 10, 3, 10, 3, 10, 3, 10, 3, 10, 3, 12, 12, 12,
        # Para ws2, parte 2 (AH y AI): 2 columnas
        7, 7
    ]

    # Definir las columnas a extraer de ws2:
    ws2_cols_first = list("ABCDEFGHIJKL")  # 12 columnas: A a L
    ws2_cols_last  = ["AH", "AI"]           # 2 columnas que se colocarán al final

    # Definir las columnas a extraer de ws (Comparativa R3 y R2):
    ws_cols = [get_column_letter(i) for i in range(12, 33)]  # 21 columnas (por ejemplo, de L a AF)

    # Determinar el máximo de filas a procesar (ajusta según tu caso)
    max_row = min(ws.max_row, ws2.max_row)

    # Recorrer desde la fila 3 hasta max_row para escribir la fórmula en la columna deseada.
    # En este ejemplo, se escribe la fórmula en la columna 10 de la hoja ws.
    for row in range(3, max_row + 1):
        formula_parts = []
        
        # Procesar la parte 1 de ws2 (A a L)
        for i, col in enumerate(ws2_cols_first):
            ref = f"'Registro2_Validacion'!{col}{row}"
            longitud = arr_longitudes[i]  # Índice 0 a 11
            formato = "0" * longitud
            formula_parts.append(f'TEXT({ref}, "{formato}")')
        
        # Procesar las columnas de ws (Comparativa R3 y R2)
        for j, col in enumerate(ws_cols):
            index = len(ws2_cols_first) + j  # Índice empieza en 12 y llega a 12+20 = 32
            ref = f"'Comparativa R3 y R2'!{col}{row}"
            longitud = arr_longitudes[index]
            formato = "0" * longitud
            formula_parts.append(f'TEXT({ref}, "{formato}")')
        
        # Procesar la parte 2 de ws2 (AH y AI)
        for k, col in enumerate(ws2_cols_last):
            index = len(ws2_cols_first) + len(ws_cols) + k  # Índice empieza en 33 y luego 34
            ref = f"'Registro2_Validacion'!{col}{row}"
            longitud = arr_longitudes[index]
            formato = "0" * longitud
            formula_parts.append(f'TEXT({ref}, "{formato}")')
        
        # Combinar todas las partes con el operador de concatenación "&"
        formula = "=" + " & ".join(formula_parts)
        
        # Escribir la fórmula en la columna deseada de la hoja ws (por ejemplo, columna 10)
        ws.cell(row=row, column=33).value = formula


    ws["D38"].value = f"=SUMIFS(AD3:AD{ultima_fila}, K3:K{ultima_fila}, \"1\")"
    ws["D39"].value = f"=SUMIFS(AD3:AD{ultima_fila}, K3:K{ultima_fila}, \"2\")"


    # Para la hoja2, aplicar estilos solo a las celdas no vacías de las dos primeras filas
    for row in ws2.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border

    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value not in (None, "", " "):
                    # Si la celda está en la primera fila o en la primera columna, aplicamos borde grueso, negrita y fill
                    if cell.row == 1 or cell.column == 1:
                        cell.border = thick_border
                        cell.font = font_TT12
                        cell.fill = fill_80
                        cell.alignment = center_alignment
                    else:
                        cell.border = thin_border

        # 2. Para todas las hojas que NO sean la nueva ni la hoja2, ajustar la columna B.
    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        # Ajustar el ancho de la columna B a 30
        ws_temp.column_dimensions["B"].width = 30
        ws_temp.column_dimensions["E"].width = 55
        ws_temp.column_dimensions["C"].width = 26
        ws_temp.column_dimensions["D"].width = 26
        # Recorrer la columna B y aplicar estilos en las celdas con datos.
        for cell in ws_temp["B"]:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.border = thick_border
                cell.font = font_TT12
                cell.fill = fill_80

    # 1. Copiar las columnas 10 y 11 de ws2 a las columnas 1 y 2 de ws_detalle
    for r in range(1, ws2.max_row + 1):
        ws_detalle.cell(row=r, column=1).value = ws2.cell(row=r, column=8).value
        ws_detalle.cell(row=r, column=2).value = ws2.cell(row=r, column=9).value

    # 2. Definir las columnas a extraer (se usa el mismo arreglo que en el bloque original)
    columns_to_extract = [13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33] 

    # 3. Copiar a partir de la columna 3 de ws_detalle los datos extraídos de ws2
    for r in range(1, ws2.max_row + 1):
        for idx, col in enumerate(columns_to_extract):
            val = ws2.cell(row=r, column=col).value
            if r < 3:
                new_val = val  # Para las dos primeras filas se copia el valor sin transformación
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            ws_detalle.cell(row=r, column=3 + idx).value = new_val

    # --- Bloque de Estilos para "Detalle RentaB" ---
    # Se asume que ya se han definido los estilos en el código principal:
    # thick_border, font_TT12 (bold, size 12), fill_80 y Alignment
    #
    # Por ejemplo, en el código original se definieron:
    #     font_TT12 = Font(bold=True, size=12)
    #     fill_80 = PatternFill("solid", fgColor="BDD7EE")
    #     thick_border = Border(left=Side(style="thick"),
    #                           right=Side(style="thick"),
    #                           top=Side(style="thick"),
    #                           bottom=Side(style="thick"))
    
    # Aplicar estilos a las dos primeras filas (encabezados) en ws_detalle
    for row in ws_detalle.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border
    
    # Ajustar los anchos de columnas en la hoja "Detalle RentaB"
    # Se puede ajustar el ancho fijo o calcularlo en función del contenido;
    # aquí se asigna un ancho fijo de 15 a cada columna, similar a lo usado en otras hojas.
    from openpyxl.utils import get_column_letter
    for col in range(1, ws_detalle.max_column + 1):
        col_letter = get_column_letter(col)
        ws_detalle.column_dimensions[col_letter].width = 20
        
    # Congelar las dos primeras filas (es decir, se quedarán fijas mientras se desplaza el resto)
    ws_detalle.freeze_panes = "A3"  # Esto congela las filas 1 y 2

    # Aplicar un AutoFilter a toda la hoja desde la fila 2 hasta la última,
    # obteniendo la letra de la última columna y el número de la última fila.
    last_col_letter = get_column_letter(ws_detalle.max_column)
    ws_detalle.auto_filter.ref = f"A2:{last_col_letter}{ws_detalle.max_row}"

    ws_detalle.column_dimensions["O"].width = 40
    ws_detalle.column_dimensions["S"].width = 40
    ws_detalle.column_dimensions["U"].width = 40

    # Primero definimos una función auxiliar para determinar si una celda es la celda superior izquierda de un rango fusionado
    def is_top_left_merged(cell, ws):
        for merged_range in ws.merged_cells.ranges:
            if cell.coordinate in merged_range:
                return cell.coordinate == merged_range.start_cell.coordinate
        return True

    # Aplicar un borde y centrado a todas las celdas de datos (desde la fila 5 en adelante)
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=11, max_col=ws.max_column):
        for cell in row:
            cell.border = thin_border
            cell.alignment = center_alignment

    for r in range(5, ws.max_row + 1):
        # Comprobar si en las columnas A, B, D y E la fila está vacía (sin valor o solo espacios)
        if all(ws.cell(row=r, column=c).value in (None, "", " ") for c in [1, 2, 4, 5]):
            continue  # Si la fila está vacía, se salta
        for c in [1, 2, 4, 5]:
            cell = ws.cell(row=r, column=c)
            if cell.value not in (None, "", " "):
                if is_top_left_merged(cell, ws):
                    cell.border = thin_border

    # Se asume que thick_border, fill_80, font_TT12 y ws ya están definidos.

    def aplicar_estilos_a_rango(ws, rango, border, fill, font):
        """Aplica los estilos a todas las celdas dentro de un rango fusionado."""
        for fila in range(rango.min_row, rango.max_row + 1):
            for col in range(rango.min_col, rango.max_col + 1):
                celda = ws.cell(row=fila, column=col)
                celda.border = border
                celda.fill = fill
                celda.font = font

    # ===============================
    # 1. Aplicar formato a la fila 1 y 2,
    #    pero solo a celdas (o rangos fusionados) con valor.
    # ===============================
    merged_procesados = set()
    for row in [1, 2]:  # Ahora aplicamos a la fila 1 y la fila 2
        for col in range(1, ws.max_column + 1):
            celda = ws.cell(row=row, column=col)
            # Buscar si la celda pertenece a un rango fusionado.
            rango_fusionado = None
            for mr in ws.merged_cells.ranges:
                if celda.coordinate in mr:
                    rango_fusionado = mr
                    break
            if rango_fusionado:
                # Evitar reprocesar el mismo rango.
                if rango_fusionado in merged_procesados:
                    continue
                # Solo se aplica el formato si la celda superior izquierda tiene valor.
                celda_superior = ws.cell(row=rango_fusionado.min_row, column=rango_fusionado.min_col)
                if celda_superior.value is None:
                    merged_procesados.add(rango_fusionado)
                    continue
                aplicar_estilos_a_rango(ws, rango_fusionado, thick_border, fill_80, font_TT12)
                merged_procesados.add(rango_fusionado)
            else:
                # Si no está fusionada, se formatea solo si la celda tiene algún valor.
                if celda.value is None:
                    continue
                celda.border = thick_border
                celda.fill = fill_80
                celda.font = font_TT12

# ==========================================================
    # 2. Aplicar formato a las columnas A y E para filas desde la 5 en adelante
    #    (se omite la fila completa si en A y E están ambas vacías)
    # ==========================================================
    for row in range(5, ws.max_row + 1):
        # Si ambas celdas A y E están vacías, se omite la fila.
        if ws.cell(row=row, column=1).value is None and ws.cell(row=row, column=5).value is None:
            continue

        # --- Columna A (posible fusión A:B) ---
        cell_A = ws.cell(row=row, column=1)
        procesada_A = False
        for mr in ws.merged_cells.ranges:
            if cell_A.coordinate in mr:
                # Si es una fusión en A:B (columna 1 y 2)
                if mr.min_col == 1 and mr.max_col == 2:
                    # Se aplica el formato a todo el rango fusionado
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_A.border = thick_border
                    cell_A.fill = fill_80
                    cell_A.font = font_TT12
                procesada_A = True
                break
        if not procesada_A:
            # Si la celda no está fusionada, se aplica el formato.
            cell_A.border = thick_border
            cell_A.fill = fill_80
            cell_A.font = font_TT12

        # --- Columna E (posible fusión D:E; D=4 y E=5) ---
        cell_E = ws.cell(row=row, column=5)
        procesada_E = False
        for mr in ws.merged_cells.ranges:
            if cell_E.coordinate in mr:
                # Si es una fusión en D:E (columnas 4 y 5)
                if mr.min_col == 4 and mr.max_col == 5:
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_E.border = thick_border
                    cell_E.fill = fill_80
                    cell_E.font = font_TT12
                procesada_E = True
                break
        if not procesada_E:
            cell_E.border = thick_border
            cell_E.fill = fill_80
            cell_E.font = font_TT12

    # Para la nueva hoja (ws) desde la columna L hasta la última columna con datos:
    for col in range(8, ws.max_column + 1):
        col_letter = get_column_letter(col)
        ws.column_dimensions[col_letter].width = 30
        for r in [1, 2]:
            cell = ws.cell(row=r, column=col)
            if cell.value is None or str(cell.value).strip() == "":
                cell.border = None
            else:
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border



    # Ajustar los textos de todas las celdas de todas las hojas
    for ws_temp in wb.worksheets:
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value is not None and str(cell.value).strip() != "":
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.column_dimensions["AG"].width = 220

    # Guardar el archivo de salida
    try:
        wb.save(output_file)
        wb.close()
        print(f"Archivo generado: {output_file}")
    except Exception as e:
        print(f"Error al guardar el archivo: {e}")

if __name__ == "__main__":
    procesar_dj()