import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Border, Side, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import os

def acceder_hojas(modified_file_path, lista_hojas=None):
    """
    Función base para acceder a las hojas necesarias de un archivo Excel modificado.
    Se puede reutilizar para aplicar reglas especiales a distintos DJ.
    
    Args:
        modified_file_path (str): Ruta del archivo Excel modificado.
        lista_hojas (list): Lista de nombres de hojas requeridas. Si se omite,
                             se usan por defecto ["Registro3_Validacion", "Registro2_Validacion"].
    
    Returns:
        tuple: (hojas, workbook)
               hojas: Diccionario con las hojas extraídas (clave: nombre de la hoja, valor: objeto worksheet).
               workbook: Objeto workbook de openpyxl, que se debe cerrar o guardar posteriormente.
    """
    if lista_hojas is None:
        lista_hojas = ["Registro3_Validacion", "Registro2_Validacion"]
    try:
        wb = load_workbook(modified_file_path)
    except Exception as e:
        print(f"Error al abrir {modified_file_path} con openpyxl: {e}")
        return None, None

    hojas = {}
    for hoja in lista_hojas:
        if hoja in wb.sheetnames:
            hojas[hoja] = wb[hoja]
        else:
            print(f"La hoja '{hoja}' no se encontró en el archivo modificado.")
    return hojas, wb

def procesar_dj():
    # Recupera la ruta del archivo modificado a través de la variable de entorno
    modified_file = os.environ.get("MODIFIED_FILE")
    if not modified_file or not os.path.exists(modified_file):
        print("No se encontró el archivo modificado.")
        return

    # Define la ruta de salida para este DJ de forma dinámica
    output_file = os.path.join(os.path.dirname(modified_file), "Registros_Validados_1862.xlsx")
    # Accedemos a las tres hojas requeridas para DJ 1894:
    # "Registro2_Validacion", "Registro3.1_Validacion" y "Registro3.2_Validacion"
    hojas, wb = acceder_hojas(modified_file, lista_hojas=["Registro2_Validacion", "Registro3.1_Validacion"])
    if wb is None:
        print("No se pudo abrir el archivo modificado.")
        return

    # Crear la nueva hoja especial para DJ 1894
    ws = wb.create_sheet("Comparativa R3 y R2")
    ws2 = hojas["Registro2_Validacion"]
    ws_detalle = wb.create_sheet("Detalle RentaB")

    # Aplicar fusiones y asignar valores estéticos (inicio común)
    ws.merge_cells("A1:E1")
    ws["A1"] = "Comparativa de Registro3 con Registro2"
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.column_dimensions["A"].width = 50

    ws.merge_cells("A3:B3")
    ws["A3"] = "Datos Registro3"
    ws["A3"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("D3:E3")
    ws["D3"] = "Datos Registro 2"
    ws["D3"].alignment = Alignment(horizontal="center", vertical="center")
    
    # Extraer valores de las hojas:
    hoja31 = hojas["Registro3.1_Validacion"]
    
    ws["A5"] = hoja31["A12"].value
    ws["B5"] = hoja31["D12"].value
    ws["A7"] = hoja31["A13"].value
    ws["B7"] = hoja31["D13"].value
    ws["A9"] = hoja31["A14"].value
    ws["B9"] = hoja31["D14"].value

 # 18. Bloque Nuevo: Copiar, a partir de la fila 5, todos los datos de la columna A en la columna E
    # (Desde E5 en adelante)
    for row in range(5, ws.max_row + 1):
        cell_a = ws.cell(row=row, column=1)
        # Buscamos si la celda A está en un rango combinado
        rango_combinado = None
        for mrange in ws.merged_cells.ranges:
            if cell_a.coordinate in mrange:
                rango_combinado = mrange
                break

        # Si la celda A forma parte de un rango combinado de A:B
        if rango_combinado and rango_combinado.min_col == 1 and rango_combinado.max_col == 2:
            # Fusionamos las celdas D y E en esa fila
            ws.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)
            # Se asigna el valor a la celda superior (D) de la celda fusionada
            ws.cell(row=row, column=4).value = cell_a.value
        else:
            # Si no está combinada, copia el valor de A a la columna E normalmente
            ws.cell(row=row, column=5).value = cell_a.value

# DEFINICIÓN DE ESTILOS
    thick_border = Border(left=Side(style="thick"),
                          right=Side(style="thick"),
                          top=Side(style="thick"),
                          bottom=Side(style="thick"))
    thin_border = Border(left=Side(style="thin"),
                         right=Side(style="thin"),
                         top=Side(style="thin"),
                         bottom=Side(style="thin"))
    font_TT14 = Font(bold=True, size=14)
    font_TT12 = Font(bold=True, size=12)
    fill_60 = PatternFill("solid", fgColor="8DB4E2")  # Azul oscuro con claro 40%
    fill_80 = PatternFill("solid", fgColor="BDD7EE")  # Azul oscuro con claro 60%
    # Para Grupo 3 y 4 se reutiliza fill_60 en este ejemplo
    center_alignment = Alignment(horizontal="center", vertical="center")
    # Aplicar estilos a la fila de encabezado (A1:E1)
    for row in ws["A1:E1"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango A3:B3
    for row in ws["A3:B3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango D3:E3
    for row in ws["D3:E3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment


    # Ajustar anchos de columnas para mejorar la apariencia
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 15
    ws.column_dimensions["C"].width = 15
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 30
    ws.column_dimensions["H"].width = 22
    ws.column_dimensions["I"].width = 22


    # Definimos los índices de las columnas a extraer: S, U, W, X y AB
    columns_to_extract = [14, 17]  # S=19, U=21, W=23, X=24, AB=28

    for r in range(1, ws2.max_row + 1):
        for idx, col in enumerate(columns_to_extract):
            val = ws2.cell(row=r, column=col).value
            if r < 3:
                new_val = val  # Sin transformación para las dos primeras filas
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            # Insertar en la nueva hoja: la columna destino es H (8) + idx
            ws.cell(row=r, column=8 + idx).value = new_val

    count_L = 0
    for cell in ws2["K"]:
        if cell.row >= 3:
            if cell.value is not None and str(cell.value).strip() != "":
                count_L += 1
    ws["D5"].value = count_L

    # total_H = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=8).value
    #     try:
    #         total_H += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_H += 0
    # ws["D7"].value = total_H

    # total_I = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=9).value
    #     try:
    #         total_I += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_I += 0
    # ws["D9"].value = total_I    


    # Define las hojas y parámetros 
    source_ws = wb["Comparativa R3 y R2"]  # Hoja con los datos numéricos a sumar (por ejemplo, en columna H)
    # Ahora la condición también proviene de "Comparativa R3 y R2" en la columna 9 (I)
    destination_ws = wb["Comparativa R3 y R2"]  # Hoja donde se escribirán los resultados

    start_row = 3  # Fila inicial de los datos
    source_data_column = 8  # Columna en source_ws con los valores numéricos (columna H)
    condition_column = 9    # Ahora la condición se toma de la columna 9 (columna I) de la misma hoja

    # Determinar la última fila a procesar (mínimo entre las hojas, pero en este caso es la misma hoja)
    ultima_fila = source_ws.max_row

    # Asumiendo que la condición es numérica (por ejemplo, 11260 o 21260)
    destination_ws["D7"].value = (
        f"=SUMPRODUCT(('Comparativa R3 y R2'!I{start_row}:I{ultima_fila}=11260)*"
        f"('Comparativa R3 y R2'!H{start_row}:H{ultima_fila}))"
    )
    destination_ws["D9"].value = (
        f"=SUMPRODUCT(('Comparativa R3 y R2'!I{start_row}:I{ultima_fila}=21260)*"
        f"('Comparativa R3 y R2'!H{start_row}:H{ultima_fila}))"
    )


    #     # Define las hojas y parámetros
    # source_ws = wb["Comparativa R3 y R2"]  # Hoja con los datos numéricos a sumar
    # condition_ws = wb["Registro2_Validacion"]  # Hoja donde se encuentra la condición (1 o 2)
    # destination_ws = wb["Comparativa R3 y R2"]  # Hoja donde se escribirán los resultados
    # start_row = 3  # Fila inicial de los datos
    # source_data_column = 8  # Columna en source_ws con los valores numéricos
    # condition_column = 17  # Columna en condition_ws con la condición (ej. 1 o 2)

    # # Obtén los objetos Cell directamente de la hoja destino
    # dest_cell_x = destination_ws["D7"]  # Celda destino para la suma de los valores con condición 1
    # dest_cell_y = destination_ws["D9"]  # Celda destino para la suma de los valores con condición 2

    # # Inicializa las variables para acumular las sumas
    # sum_x = 0
    # sum_y = 0

    # # Recorre las filas desde start_row hasta la última fila con datos
    # for r in range(start_row, source_ws.max_row + 1):
    #     # Obtén el valor numérico de la hoja de datos
    #     cell_value = source_ws.cell(row=r, column=source_data_column).value
    #     # Obtén el valor de la condición de la otra hoja
    #     condition_value = condition_ws.cell(row=r, column=condition_column).value
        
    #     try:
    #         # Intenta convertir el valor a entero, o usa 0 si está vacío
    #         value_to_add = int(cell_value) if cell_value is not None else 0
    #     except Exception:
    #         value_to_add = 0
        
    #     # Convierte el valor de la condición a cadena para aceptar distintos formatos
    #     cond_str = str(condition_value).strip()
        
    #     # Si la condición es "1", suma a sum_x; si es "2", suma a sum_y.
    #     if cond_str == "11260":
    #         sum_x += value_to_add
    #     elif cond_str == "21260":
    #         sum_y += value_to_add


    # # Asigna las sumas directamente a las celdas destino
    # dest_cell_x.value = sum_x
    # dest_cell_y.value = sum_y

#--------------------------------------------------------------------------------------------------------------


    # Definir el arreglo de longitudes (27 números en total, en el orden indicado)
    arr_longitudes = [
        # Segmento 1: ws2, parte 1: "ABCDEFGHIJKLM" (13 columnas)
        1, 4, 1, 7, 1, 8, 1, 8, 1, 15, 3, 30, 4,
        # Segmento 2: ws, primer elemento: "N" (1 columna)
        15,
        # Segmento 3: ws2, parte 2: ["O", "P"] (2 columnas)
        15, 2,
        # Segmento 4: ws, segundo elemento: "Q" (1 columna)
        5,
        # Segmento 5: ws2, parte 3: list("RSTUVWXZ") + ["AA", "AB"] (10 columnas)
        2, 2, 4, 30, 15, 3, 30, 5, 3, 5
    ]

    # Definir las columnas a extraer de ws2 por segmentos:
    ws2_cols_first = list("ABCDEFGHIJKLM")         # 13 columnas: A a M
    ws2_cols_second = ["O", "P"]                      # 2 columnas
    ws2_cols_third  = list("RSTUVWXZ") + ["AA", "AB"]  # 10 columnas

    # Definir las columnas a extraer de ws (Comparativa R3 y R2):
    ws_cols = ["H", "I"]  # 2 columnas, en el orden deseado

    # Determinar el máximo de filas a procesar (ajusta según tu caso)
    max_row = min(ws.max_row, ws2.max_row)

    # Recorrer desde la fila 3 hasta max_row para construir la fórmula
    for row in range(3, max_row + 1):
        formula_parts = []
        
        # Segmento 1: Procesar ws2, parte 1 ("ABCDEFGHIJKLM")
        for i, col in enumerate(ws2_cols_first):
            ref = f"'Registro2_Validacion'!{col}{row}"
            longitud = arr_longitudes[i]  # índices 0 a 12
            # Forzar que si la celda está vacía se use "" (para que REPT rellene con espacios)
            part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
            formula_parts.append(part)
        
        # Segmento 2: Procesar ws, primer elemento ("N")
        ref = f"'Comparativa R3 y R2'!{ws_cols[0]}{row}"
        index = len(ws2_cols_first)  # índice 13
        longitud = arr_longitudes[index]
        part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
        formula_parts.append(part)
        
        # Segmento 3: Procesar ws2, parte 2 (["O", "P"])
        for k, col in enumerate(ws2_cols_second):
            ref = f"'Registro2_Validacion'!{col}{row}"
            index = len(ws2_cols_first) + len(ws_cols[:1]) + k  # para k=0 => índice 14, k=1 => índice 15
            longitud = arr_longitudes[index]
            part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
            formula_parts.append(part)
        
        # Segmento 4: Procesar ws, segundo elemento ("Q")
        ref = f"'Comparativa R3 y R2'!{ws_cols[1]}{row}"
        index = len(ws2_cols_first) + len(ws_cols[:1]) + len(ws2_cols_second)  # 13 + 1 + 2 = 16
        longitud = arr_longitudes[index]
        part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
        formula_parts.append(part)
        
        # Segmento 5: Procesar ws2, parte 3 (list("RSTUVWXZ") + ["AA", "AB"])
        for j, col in enumerate(ws2_cols_third):
            ref = f"'Registro2_Validacion'!{col}{row}"
            index = len(ws2_cols_first) + len(ws_cols) + len(ws2_cols_second) + j  # índices 17 a 26
            longitud = arr_longitudes[index]
            part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
            formula_parts.append(part)
        
        # Combinar todas las partes con el operador de concatenación "&"
        formula = "=" + " & ".join(formula_parts)
        
        # Escribir la fórmula en la columna deseada de la hoja ws (por ejemplo, columna 33)
        ws.cell(row=row, column=10).value = formula



#-------------------------------------------------------------------------------

    # Para la hoja2, aplicar estilos solo a las celdas no vacías de las dos primeras filas
    for row in ws2.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border

    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value not in (None, "", " "):
                    # Si la celda está en la primera fila o en la primera columna, aplicamos borde grueso, negrita y fill
                    if cell.row == 1 or cell.column == 1:
                        cell.border = thick_border
                        cell.font = font_TT12
                        cell.fill = fill_80
                        cell.alignment = center_alignment
                    else:
                        cell.border = thin_border

        # 2. Para todas las hojas que NO sean la nueva ni la hoja2, ajustar la columna B.
    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        # Ajustar el ancho de la columna B a 30
        ws_temp.column_dimensions["B"].width = 30
        ws_temp.column_dimensions["E"].width = 55
        ws_temp.column_dimensions["C"].width = 26
        ws_temp.column_dimensions["D"].width = 26
        # Recorrer la columna B y aplicar estilos en las celdas con datos.
        for cell in ws_temp["B"]:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.border = thick_border
                cell.font = font_TT12
                cell.fill = fill_80

    # 1. Copiar las columnas 10 y 11 de ws2 a las columnas 1 y 2 de ws_detalle
    for r in range(1, ws2.max_row + 1):
        ws_detalle.cell(row=r, column=1).value = ws2.cell(row=r, column=8).value
        ws_detalle.cell(row=r, column=2).value = ws2.cell(row=r, column=9).value

    # 2. Definir las columnas a extraer (se usa el mismo arreglo que en el bloque original)
    columns_to_extract = [14, 17] 

    # 3. Copiar a partir de la columna 3 de ws_detalle los datos extraídos de ws2
    for r in range(1, ws2.max_row + 1):
        for idx, col in enumerate(columns_to_extract):
            val = ws2.cell(row=r, column=col).value
            if r < 3:
                new_val = val  # Para las dos primeras filas se copia el valor sin transformación
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            ws_detalle.cell(row=r, column=3 + idx).value = new_val

    # --- Bloque de Estilos para "Detalle RentaB" ---
    # Se asume que ya se han definido los estilos en el código principal:
    # thick_border, font_TT12 (bold, size 12), fill_80 y Alignment
    #
    # Por ejemplo, en el código original se definieron:
    #     font_TT12 = Font(bold=True, size=12)
    #     fill_80 = PatternFill("solid", fgColor="BDD7EE")
    #     thick_border = Border(left=Side(style="thick"),
    #                           right=Side(style="thick"),
    #                           top=Side(style="thick"),
    #                           bottom=Side(style="thick"))
    
    # Aplicar estilos a las dos primeras filas (encabezados) en ws_detalle
    for row in ws_detalle.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border
    
    # Ajustar los anchos de columnas en la hoja "Detalle RentaB"
    # Se puede ajustar el ancho fijo o calcularlo en función del contenido;
    # aquí se asigna un ancho fijo de 15 a cada columna, similar a lo usado en otras hojas.
    from openpyxl.utils import get_column_letter
    for col in range(1, ws_detalle.max_column + 1):
        col_letter = get_column_letter(col)
        ws_detalle.column_dimensions[col_letter].width = 20

    # Congelar las dos primeras filas (es decir, se quedarán fijas mientras se desplaza el resto)
    ws_detalle.freeze_panes = "A3"  # Esto congela las filas 1 y 2

    # Aplicar un AutoFilter a toda la hoja desde la fila 2 hasta la última,
    # obteniendo la letra de la última columna y el número de la última fila.
    last_col_letter = get_column_letter(ws_detalle.max_column)
    ws_detalle.auto_filter.ref = f"A2:{last_col_letter}{ws_detalle.max_row}"


    # Primero definimos una función auxiliar para determinar si una celda es la celda superior izquierda de un rango fusionado
    def is_top_left_merged(cell, ws):
        for merged_range in ws.merged_cells.ranges:
            if cell.coordinate in merged_range:
                return cell.coordinate == merged_range.start_cell.coordinate
        return True

    # Aplicar un borde y centrado a todas las celdas de datos (desde la fila 5 en adelante)
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=8, max_col=ws.max_column):
        for cell in row:
            cell.border = thin_border
            cell.alignment = center_alignment

    for r in range(5, ws.max_row + 1):
        # Comprobar si en las columnas A, B, D y E la fila está vacía (sin valor o solo espacios)
        if all(ws.cell(row=r, column=c).value in (None, "", " ") for c in [1, 2, 4, 5]):
            continue  # Si la fila está vacía, se salta
        for c in [1, 2, 4, 5]:
            cell = ws.cell(row=r, column=c)
            if cell.value not in (None, "", " "):
                if is_top_left_merged(cell, ws):
                    cell.border = thin_border

    # Se asume que thick_border, fill_80, font_TT12 y ws ya están definidos.

    def aplicar_estilos_a_rango(ws, rango, border, fill, font):
        """Aplica los estilos a todas las celdas dentro de un rango fusionado."""
        for fila in range(rango.min_row, rango.max_row + 1):
            for col in range(rango.min_col, rango.max_col + 1):
                celda = ws.cell(row=fila, column=col)
                celda.border = border
                celda.fill = fill
                celda.font = font

    # ===============================
    # 1. Aplicar formato a la fila 1 y 2,
    #    pero solo a celdas (o rangos fusionados) con valor.
    # ===============================
    merged_procesados = set()
    for row in [1, 2]:  # Ahora aplicamos a la fila 1 y la fila 2
        for col in range(1, ws.max_column + 1):
            celda = ws.cell(row=row, column=col)
            # Buscar si la celda pertenece a un rango fusionado.
            rango_fusionado = None
            for mr in ws.merged_cells.ranges:
                if celda.coordinate in mr:
                    rango_fusionado = mr
                    break
            if rango_fusionado:
                # Evitar reprocesar el mismo rango.
                if rango_fusionado in merged_procesados:
                    continue
                # Solo se aplica el formato si la celda superior izquierda tiene valor.
                celda_superior = ws.cell(row=rango_fusionado.min_row, column=rango_fusionado.min_col)
                if celda_superior.value is None:
                    merged_procesados.add(rango_fusionado)
                    continue
                aplicar_estilos_a_rango(ws, rango_fusionado, thick_border, fill_80, font_TT12)
                merged_procesados.add(rango_fusionado)
            else:
                # Si no está fusionada, se formatea solo si la celda tiene algún valor.
                if celda.value is None:
                    continue
                celda.border = thick_border
                celda.fill = fill_80
                celda.font = font_TT12

# ==========================================================
    # 2. Aplicar formato a las columnas A y E para filas desde la 5 en adelante
    #    (se omite la fila completa si en A y E están ambas vacías)
    # ==========================================================
    for row in range(5, ws.max_row + 1):
        # Si ambas celdas A y E están vacías, se omite la fila.
        if ws.cell(row=row, column=1).value is None and ws.cell(row=row, column=5).value is None:
            continue

        # --- Columna A (posible fusión A:B) ---
        cell_A = ws.cell(row=row, column=1)
        procesada_A = False
        for mr in ws.merged_cells.ranges:
            if cell_A.coordinate in mr:
                # Si es una fusión en A:B (columna 1 y 2)
                if mr.min_col == 1 and mr.max_col == 2:
                    # Se aplica el formato a todo el rango fusionado
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_A.border = thick_border
                    cell_A.fill = fill_80
                    cell_A.font = font_TT12
                procesada_A = True
                break
        if not procesada_A:
            # Si la celda no está fusionada, se aplica el formato.
            cell_A.border = thick_border
            cell_A.fill = fill_80
            cell_A.font = font_TT12

        # --- Columna E (posible fusión D:E; D=4 y E=5) ---
        cell_E = ws.cell(row=row, column=5)
        procesada_E = False
        for mr in ws.merged_cells.ranges:
            if cell_E.coordinate in mr:
                # Si es una fusión en D:E (columnas 4 y 5)
                if mr.min_col == 4 and mr.max_col == 5:
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_E.border = thick_border
                    cell_E.fill = fill_80
                    cell_E.font = font_TT12
                procesada_E = True
                break
        if not procesada_E:
            cell_E.border = thick_border
            cell_E.fill = fill_80
            cell_E.font = font_TT12

    # Ajustar los textos de todas las celdas de todas las hojas
    for ws_temp in wb.worksheets:
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value is not None and str(cell.value).strip() != "":
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.column_dimensions["J"].width = 220

    # Guardar el archivo de salida
    try:
        wb.save(output_file)
        wb.close()
        print(f"Archivo generado: {output_file}")
    except Exception as e:
        print(f"Error al guardar el archivo: {e}")

if __name__ == "__main__":
    procesar_dj()