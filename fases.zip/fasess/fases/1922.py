import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Border, Side, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import os

def acceder_hojas(modified_file_path, lista_hojas=None):
    """
    Función base para acceder a las hojas necesarias de un archivo Excel modificado.
    Se puede reutilizar para aplicar reglas especiales a distintos DJ.
    
    Args:
        modified_file_path (str): Ruta del archivo Excel modificado.
        lista_hojas (list): Lista de nombres de hojas requeridas. Si se omite,
                             se usan por defecto ["Registro3_Validacion", "Registro2_Validacion"].
    
    Returns:
        tuple: (hojas, workbook)
               hojas: Diccionario con las hojas extraídas (clave: nombre de la hoja, valor: objeto worksheet).
               workbook: Objeto workbook de openpyxl, que se debe cerrar o guardar posteriormente.
    """
    if lista_hojas is None:
        lista_hojas = ["Registro3_Validacion", "Registro2_Validacion"]
    try:
        wb = load_workbook(modified_file_path)
    except Exception as e:
        print(f"Error al abrir {modified_file_path} con openpyxl: {e}")
        return None, None

    hojas = {}
    for hoja in lista_hojas:
        if hoja in wb.sheetnames:
            hojas[hoja] = wb[hoja]
        else:
            print(f"La hoja '{hoja}' no se encontró en el archivo modificado.")
    return hojas, wb

def procesar_dj():
    # Rutas específicas para DJ 1894 (archivo de entrada y salida)
    modified_file = os.environ.get("MODIFIED_FILE")
    if not modified_file or not os.path.exists(modified_file):
        print("No se encontró el archivo modificado.")
        return

    # Define la ruta de salida para este DJ de forma dinámica
    output_file = os.path.join(os.path.dirname(modified_file), "Registros_Validados_1922.xlsx")
    # Accedemos a las tres hojas requeridas para DJ 1894:
    # "Registro2_Validacion", "Registro3.1_Validacion" y "Registro3.2_Validacion"
    # Accedemos a las tres hojas requeridas para DJ 1894:
    # "Registro2_Validacion", "Registro3.1_Validacion" y "Registro3.2_Validacion"
    hojas, wb = acceder_hojas(modified_file, lista_hojas=["Registro2_Validacion", "Registro3.1_Validacion"])
    if wb is None:
        print("No se pudo abrir el archivo modificado.")
        return

    # Crear la nueva hoja especial para DJ 1894
    ws = wb.create_sheet("Comparativa R3 y R2")
    ws2 = hojas["Registro2_Validacion"]
    ws_detalle = wb.create_sheet("Detalle RentaB")

    # Aplicar fusiones y asignar valores estéticos (inicio común)
    ws.merge_cells("A1:E1")
    ws["A1"] = "Comparativa de Registro3 con Registro2"
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.column_dimensions["A"].width = 50

    ws.merge_cells("A3:B3")
    ws["A3"] = "Datos Registro3"
    ws["A3"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("D3:E3")
    ws["D3"] = "Datos Registro 2"
    ws["D3"].alignment = Alignment(horizontal="center", vertical="center")
    
    # Extraer valores de las hojas:
    hoja31 = hojas["Registro3.1_Validacion"]
    
    # --- Se desplazan todas las asignaciones una fila hacia abajo ---
    # 1. Fusionar A5:B5 y asignar el valor de A12 de hoja31
    #ws.merge_cells("A5:B5")
    ws["A5"] = hoja31["A12"].value
    ws["B5"] = hoja31["D12"].value

    ws["A7"] = hoja31["A13"].value
    ws["B7"] = hoja31["D13"].value

    ws["A9"] = hoja31["A14"].value
    ws["B9"] = hoja31["D14"].value

    ws["A11"] = hoja31["A15"].value
    ws["B11"] = hoja31["D15"].value

    ws.merge_cells("A13:B13")
    ws["A13"] = hoja31["A16"].value    
    ws.merge_cells("A14:B14")
    ws["A14"] = hoja31["A17"].value
    ws["A15"] = hoja31["B18"].value
    ws["B15"] = hoja31["D18"].value    
    ws["A16"] = hoja31["B19"].value
    ws["B16"] = hoja31["D19"].value    
    ws["A17"] = hoja31["B20"].value
    ws["B17"] = hoja31["D20"].value    
    ws["A18"] = hoja31["B21"].value
    ws["B18"] = hoja31["D21"].value  

    ws.merge_cells("A20:B20")
    ws["A20"] = hoja31["A22"].value
    ws["A21"] = hoja31["B23"].value
    ws["B21"] = hoja31["D23"].value    
    ws["A22"] = hoja31["B24"].value
    ws["B22"] = hoja31["D24"].value    
    ws["A23"] = hoja31["B25"].value
    ws["B23"] = hoja31["D25"].value    
    ws["A24"] = hoja31["B26"].value
    ws["B24"] = hoja31["D26"].value
    ws["A25"] = hoja31["B27"].value
    ws["B25"] = hoja31["D27"].value

    ws.merge_cells("A27:B27")
    ws["A27"] = hoja31["A28"].value
    ws["A28"] = hoja31["B29"].value
    ws["B28"] = hoja31["D29"].value    
    ws["A29"] = hoja31["B30"].value
    ws["B29"] = hoja31["D30"].value

    ws.merge_cells("A31:B31")
    ws["A31"] = hoja31["A31"].value
    ws["A32"] = hoja31["B32"].value
    ws["B32"] = hoja31["D32"].value    
    ws["A33"] = hoja31["B33"].value
    ws["B33"] = hoja31["D33"].value   

    ws["A35"] = hoja31["A34"].value
    ws["B35"] = hoja31["D34"].value    
    ws["A36"] = hoja31["A35"].value
    ws["B36"] = hoja31["D35"].value    
    ws["A37"] = hoja31["A36"].value
    ws["B37"] = hoja31["D36"].value
    ws["A38"] = hoja31["A37"].value
    ws["B38"] = hoja31["D37"].value

    ws.merge_cells("A40:B40")
    ws["A40"] = hoja31["A38"].value
    ws.merge_cells("A41:B41")
    ws["A41"] = hoja31["A39"].value
    ws.merge_cells("A42:B42")
    ws["A42"] = hoja31["A40"].value
    ws["A43"] = hoja31["B41"].value
    ws["B43"] = hoja31["D41"].value    
    ws["A44"] = hoja31["B42"].value
    ws["B44"] = hoja31["D42"].value

    ws.merge_cells("A46:B46")
    ws["A46"] = hoja31["A43"].value
    ws["A47"] = hoja31["B44"].value
    ws["B47"] = hoja31["D44"].value    
    ws["A48"] = hoja31["B45"].value
    ws["B48"] = hoja31["D45"].value

    ws.merge_cells("A50:B50")
    ws["A50"] = hoja31["A46"].value
    ws["A51"] = hoja31["B47"].value
    ws["B51"] = hoja31["D47"].value    
    ws["A52"] = hoja31["B48"].value
    ws["B52"] = hoja31["D48"].value

    ws.merge_cells("A54:B54")
    ws["A54"] = hoja31["A49"].value
    ws["A55"] = hoja31["B50"].value
    ws["B55"] = hoja31["D50"].value    
    ws["A56"] = hoja31["B51"].value
    ws["B56"] = hoja31["D51"].value

    ws["A58"] = hoja31["A52"].value
    ws["B58"] = hoja31["D52"].value

    ws.merge_cells("A60:B60")
    ws["A60"] = hoja31["A53"].value
    ws.merge_cells("A61:B61")
    ws["A61"] = hoja31["A54"].value
    ws["A62"] = hoja31["B55"].value
    ws["B62"] = hoja31["D55"].value    
    ws["A63"] = hoja31["B56"].value
    ws["B63"] = hoja31["D56"].value

    ws.merge_cells("A65:B65")
    ws["A65"] = hoja31["A57"].value
    ws["A66"] = hoja31["B58"].value
    ws["B66"] = hoja31["D58"].value    
    ws["A67"] = hoja31["B59"].value
    ws["B67"] = hoja31["D59"].value

    ws["A69"] = hoja31["A60"].value
    ws["B69"] = hoja31["D60"].value    
    ws["A71"] = hoja31["A61"].value
    ws["B71"] = hoja31["D61"].value    
    ws["A73"] = hoja31["A62"].value
    ws["B73"] = hoja31["D62"].value    
    ws["A75"] = hoja31["A63"].value
    ws["B75"] = hoja31["D63"].value
    ws["A76"] = hoja31["A64"].value
    ws["B76"] = hoja31["D64"].value

    ws["E77"] = ws["BC1"].value    
    ws["E78"] = ws["BD1"].value
    ws["E79"] = ws["BE1"].value
    ws["E80"] = ws["BF1"].value
    ws["E81"] = ws["BG1"].value

 # 18. Bloque Nuevo: Copiar, a partir de la fila 5, todos los datos de la columna A en la columna E
    # (Desde E5 en adelante)
    for row in range(5, ws.max_row + 1):
        cell_a = ws.cell(row=row, column=1)
        # Buscamos si la celda A está en un rango combinado
        rango_combinado = None
        for mrange in ws.merged_cells.ranges:
            if cell_a.coordinate in mrange:
                rango_combinado = mrange
                break

        # Si la celda A forma parte de un rango combinado de A:B
        if rango_combinado and rango_combinado.min_col == 1 and rango_combinado.max_col == 2:
            # Fusionamos las celdas D y E en esa fila
            ws.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)
            # Se asigna el valor a la celda superior (D) de la celda fusionada
            ws.cell(row=row, column=4).value = cell_a.value
        else:
            # Si no está combinada, copia el valor de A a la columna E normalmente
            ws.cell(row=row, column=5).value = cell_a.value

# DEFINICIÓN DE ESTILOS
    thick_border = Border(left=Side(style="thick"),
                          right=Side(style="thick"),
                          top=Side(style="thick"),
                          bottom=Side(style="thick"))
    thin_border = Border(left=Side(style="thin"),
                         right=Side(style="thin"),
                         top=Side(style="thin"),
                         bottom=Side(style="thin"))
    font_TT14 = Font(bold=True, size=14)
    font_TT12 = Font(bold=True, size=12)
    fill_60 = PatternFill("solid", fgColor="8DB4E2")  # Azul oscuro con claro 40%
    fill_80 = PatternFill("solid", fgColor="BDD7EE")  # Azul oscuro con claro 60%
    # Para Grupo 3 y 4 se reutiliza fill_60 en este ejemplo
    center_alignment = Alignment(horizontal="center", vertical="center")
    # Aplicar estilos a la fila de encabezado (A1:E1)
    for row in ws["A1:E1"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango A3:B3
    for row in ws["A3:B3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango D3:E3
    for row in ws["D3:E3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment


    # Ajustar anchos de columnas para mejorar la apariencia
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 15
    ws.column_dimensions["C"].width = 15
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 30
    hoja31.column_dimensions["A"].width = 35

    # Definimos los índices de las columnas a extraer: S, U, W, X y AB
    columns_to_extract = [25,27,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,76,77,78,79,80,81,82]  # S=19, U=21, W=23, X=24, AB=28

    for r in range(1, ws2.max_row + 1):
        for idx, col in enumerate(columns_to_extract):
            val = ws2.cell(row=r, column=col).value
            if r < 3:
                new_val = val  # Sin transformación para las dos primeras filas
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            # Insertar en la nueva hoja: la columna destino es H (8) + idx
            ws.cell(row=r, column=8 + idx).value = new_val

    count_L = 0
    for cell in ws2["M"]:
        if cell.row >= 3:
            if cell.value is not None and str(cell.value).strip() != "":
                count_L += 1
    ws["D5"].value = count_L

    ultima_fila = ws.max_row


    ws["D7"].value = f"=SUM(O3:O{ultima_fila})" # Columna 32 -> AF

    # total_O = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=15).value
    #     try:
    #         total_O += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_O += 0
    # ws["D7"].value = total_O

    # total_P = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=16).value
    #     try:
    #         total_P += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_P += 0
    # ws["D9"].value = total_P
    ws["D9"].value = f"=SUM(P3:P{ultima_fila})" # Columna 31 -> AE
    ws["D11"].value = f"=SUM(S3:S{ultima_fila})" # Columna 32 -> AF

    # total_S = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=19).value
    #     try:
    #         total_S += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_S += 0
    # ws["D11"].value = total_S

    # total_T = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=20).value
    #     try:
    #         total_T += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_T += 0
    # ws["D15"].value = total_T
    ws["D15"].value = f"=SUM(T3:T{ultima_fila})" # Columna 31 -> AE
    ws["D16"].value = f"=SUM(U3:U{ultima_fila})" # Columna 32 -> AF
    # total_U = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=21).value
    #     try:
    #         total_U += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_U += 0
    # ws["D16"].value = total_U

    # total_V = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=22).value
    #     try:
    #         total_V += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_V += 0
    # ws["D17"].value = total_V
    ws["D17"].value = f"=SUM(V3:V{ultima_fila})" # Columna 31 -> AE
    ws["D18"].value = f"=SUM(W3:W{ultima_fila})" # Columna 32 -> AF
    # total_W = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=23).value
    #     try:
    #         total_W += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_W += 0
    # ws["D18"].value = total_W

    # total_X = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=24).value
    #     try:
    #         total_X += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_X += 0
    # ws["D21"].value = total_X
    ws["D21"].value = f"=SUM(X3:X{ultima_fila})" # Columna 31 -> AE
    ws["D22"].value = f"=SUM(Y3:Y{ultima_fila})" # Columna 32 -> AF
    # total_Y = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=25).value
    #     try:
    #         total_Y += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_Y += 0
    # ws["D22"].value = total_Y

    # total_Z = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=26).value
    #     try:
    #         total_Z += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_Z += 0
    # ws["D23"].value = total_Z
    ws["D23"].value = f"=SUM(Z3:Z{ultima_fila})" # Columna 31 -> AE
    ws["D24"].value = f"=SUM(AA3:AA{ultima_fila})" # Columna 32 -> AF
    # total_AA = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=27).value
    #     try:
    #         total_AA += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AA += 0
    # ws["D24"].value = total_AA

    # total_AB = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=28).value
    #     try:
    #         total_AB += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AB += 0
    # ws["D25"].value = total_AB
    ws["D25"].value = f"=SUM(AB3:AB{ultima_fila})" # Columna 31 -> AE
    ws["D28"].value = f"=SUM(AC3:AC{ultima_fila})" # Columna 32 -> AF

    # total_AC = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=29).value
    #     try:
    #         total_AC += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AC += 0
    # ws["D28"].value = total_AC


    # total_AD = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=30).value
    #     try:
    #         total_AD += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AD += 0
    # ws["D29"].value = total_AD
    ws["D29"].value = f"=SUM(AD3:AD{ultima_fila})" # Columna 31 -> AE
    ws["D32"].value = f"=SUM(AE3:AE{ultima_fila})" # Columna 32 -> AF

    # total_AE = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=31).value
    #     try:
    #         total_AE += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AE += 0
    # ws["D32"].value = total_AE

    # total_AF = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=32).value
    #     try:
    #         total_AF += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AF += 0
    # ws["D33"].value = total_AF
    ws["D33"].value = f"=SUM(AF3:AF{ultima_fila})" # Columna 31 -> AE
    ws["D35"].value = f"=SUM(AG3:AG{ultima_fila})" # Columna 32 -> AF

    # total_AG = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=33).value
    #     try:
    #         total_AG += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AG += 0
    # ws["D35"].value = total_AG


    # total_AH = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=34).value
    #     try:
    #         total_AH += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AH += 0
    # ws["D36"].value = total_AH
    ws["D35"].value = f"=SUM(AH3:AH{ultima_fila})" # Columna 31 -> AE
    ws["D37"].value = f"=SUM(AI3:AI{ultima_fila})" # Columna 32 -> AF

    # total_AI = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=35).value
    #     try:
    #         total_AI += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AI += 0
    # ws["D37"].value = total_AI


    # total_AJ = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=36).value
    #     try:
    #         total_AJ += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AJ += 0
    # ws["D38"].value = total_AJ
    ws["D38"].value = f"=SUM(AJ3:AJ{ultima_fila})" # Columna 31 -> AE
    ws["D43"].value = f"=SUM(AJ3:AJ{ultima_fila})" # Columna 32 -> AF

    # total_AK = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=37).value
    #     try:
    #         total_AK += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AK += 0
    # ws["D43"].value = total_AK


    # total_AL = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=38).value
    #     try:
    #         total_AL += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AL += 0
    # ws["D44"].value = total_AL
    ws["D44"].value = f"=SUM(AL3:AL{ultima_fila})" # Columna 31 -> AE
    ws["D47"].value = f"=SUM(AM3:AM{ultima_fila})" # Columna 32 -> AF
    # total_AM = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=39).value
    #     try:
    #         total_AM += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AM += 0
    # ws["D47"].value = total_AM

    # total_AN = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=40).value
    #     try:
    #         total_AN += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AN += 0
    # ws["D48"].value = total_AN
    ws["D48"].value = f"=SUM(AN3:AN{ultima_fila})" # Columna 31 -> AE
    ws["D51"].value = f"=SUM(AO3:AO{ultima_fila})" # Columna 32 -> AF
    # total_AO = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=41).value
    #     try:
    #         total_AO += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AO += 0
    # ws["D51"].value = total_AO

    # total_AP = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=42).value
    #     try:
    #         total_AP += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AP += 0
    # ws["D52"].value = total_AP
    ws["D52"].value = f"=SUM(AP3:AP{ultima_fila})" # Columna 31 -> AE
    ws["D55"].value = f"=SUM(AQ3:AQ{ultima_fila})" # Columna 32 -> AF

    # total_AQ = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=43).value
    #     try:
    #         total_AQ += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AQ += 0
    # ws["D55"].value = total_AQ


    # total_AR = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=44).value
    #     try:
    #         total_AR += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AR += 0
    # ws["D56"].value = total_AR
    ws["D56"].value = f"=SUM(AR3:AR{ultima_fila})" # Columna 31 -> AE
    ws["D58"].value = f"=SUM(AS3:AS{ultima_fila})" # Columna 32 -> AF

    # total_AS = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=45).value
    #     try:
    #         total_AS += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AS += 0
    # ws["D58"].value = total_AS

    # total_AT = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=46).value
    #     try:
    #         total_AT += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AT += 0
    # ws["D62"].value = total_AT
    ws["D62"].value = f"=SUM(AT3:AT{ultima_fila})" # Columna 31 -> AE
    ws["D63"].value = f"=SUM(AU3:AU{ultima_fila})" # Columna 32 -> AF

    # total_AU = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=47).value
    #     try:
    #         total_AU += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AU += 0
    # ws["D63"].value = total_AU


    # total_AV = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=48).value
    #     try:
    #         total_AV += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AV += 0
    # ws["D66"].value = total_AV
    ws["D66"].value = f"=SUM(AV3:AV{ultima_fila})" # Columna 31 -> AE
    ws["D67"].value = f"=SUM(AW3:AW{ultima_fila})" # Columna 32 -> AF

    # total_AW = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=49).value
    #     try:
    #         total_AW += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AW += 0
    # ws["D67"].value = total_AW


    # total_AX = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=50).value
    #     try:
    #         total_AX += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AX += 0
    # ws["D69"].value = total_AX
    ws["D69"].value = f"=SUM(AX3:AX{ultima_fila})" # Columna 31 -> AE
    ws["D71"].value = f"=SUM(AY3:AY{ultima_fila})" # Columna 32 -> AF

    # total_AY = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=51).value
    #     try:
    #         total_AY += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AY += 0
    # ws["D70"].value = total_AY


    # total_AZ = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=52).value
    #     try:
    #         total_AZ += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_AZ += 0
    # ws["D71"].value = total_AZ
    ws["D73"].value = f"=SUM(AZ3:AZ{ultima_fila})" # Columna 31 -> AE
    ws["D75"].value = f"=SUM(BA3:BA{ultima_fila})" # Columna 32 -> AF
    # total_BA = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=53).value
    #     try:
    #         total_BA += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_BA += 0
    # ws["D72"].value = total_BA
    ws["D76"].value = f"=SUM(BB3:BB{ultima_fila})" # Columna 31 -> AE
    ws["D77"].value = f"=SUM(BC3:BC{ultima_fila})" # Columna 32 -> AF
    # total_BB = 0
    # for r in range(3, ws.max_row + 1):
    #     cell_val = ws.cell(row=r, column=54).value
    #     try:
    #         total_BB += int(cell_val) if cell_val is not None else 0
    #     except Exception:
    #         total_BB += 0
    # ws["D73"].value = total_BB
    ws["D78"].value = f"=SUM(BD3:BD{ultima_fila})" # Columna 31 -> AE
    ws["D79"].value = f"=SUM(BE3:BE{ultima_fila})" # Columna 32 -> AF

    ws["D80"].value = f"=SUM(BF3:BF{ultima_fila})" # Columna 31 -> AE
    ws["D81"].value = f"=SUM(BG3:BG{ultima_fila})" # Columna 32 -> AF


    # Para la hoja2, aplicar estilos solo a las celdas no vacías de las dos primeras filas
    for row in ws2.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border

    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value not in (None, "", " "):
                    # Si la celda está en la primera fila o en la primera columna, aplicamos borde grueso, negrita y fill
                    if cell.row == 1 or cell.column == 1:
                        cell.border = thick_border
                        cell.font = font_TT12
                        cell.fill = fill_80
                        cell.alignment = center_alignment
                    else:
                        cell.border = thin_border

        # 2. Para todas las hojas que NO sean la nueva ni la hoja2, ajustar la columna B.
    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        # Ajustar el ancho de la columna B a 30
        ws_temp.column_dimensions["B"].width = 30
        ws_temp.column_dimensions["E"].width = 55
        ws_temp.column_dimensions["C"].width = 26
        ws_temp.column_dimensions["D"].width = 26
        # Recorrer la columna B y aplicar estilos en las celdas con datos.
        for cell in ws_temp["B"]:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.border = thick_border
                cell.font = font_TT12
                cell.fill = fill_80
#------------------------------------------------------------------------------------------------------------------------                

    # Definir el arreglo de longitudes (27 números en total, en el orden indicado)
    arr_longitudes = [
        1, 4, 1, 7, 1, 8, 1, 1, 8, 1, 8, 1, 8, 1, 1,1, 30, 8, 1, 15, 2, 1, 8, 1, 15, 21, 10, 1, 1, 15,
        15, 5, 15,10, 15, 15, 15, 10,
        15, 15, 
        15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,
        7,8,1,
        18,20,20,20,20,20,20 
    ]

    # Definir las columnas a extraer de ws2 por segmentos:
    ws2_cols_one = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + ["AA", "AB", "AC", "AD"]  #primero
    ws2_cols_third = ["BU","BV","BW"]

    # Definir las columnas a extraer de ws (Comparativa R3 y R2):
    ws_cols_second = list("KLMNOPQRSTUVWXYZ") + ["AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ"]
    ws_cols_four = ["BA","BB","BC","BD","BE","BF","BG"]



    # Determinar el máximo de filas a procesar (ajusta según tu caso)
    max_row = min(ws.max_row, ws2.max_row)

    for row in range(3, max_row + 1):
        formula_parts = []
        
        # Segmento 1: Procesar ws2, parte 1 (ws2_cols_one)
        for i, col in enumerate(ws2_cols_one):
            ref = f"'Registro2_Validacion'!{col}{row}"
            longitud = arr_longitudes[i]
            if col in ["Q", "T"]:
                # Para columnas Q y U: alineación izquierda (se toma primero el contenido y se complementa con espacios a la derecha)
                part = f'LEFT(IF({ref}="","",{ref}) & REPT(" ", {longitud}), {longitud})'
            else:
                # Para las demás columnas: alineación derecha (se complementan espacios a la izquierda)
                part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
            formula_parts.append(part)

        
        # Segmento 2: Procesar ws, primer elemento (ws_cols_second)
        for i, col in enumerate(ws_cols_second):
            index = len(ws2_cols_one) + i  # índice 18
            ref = f"'Comparativa R3 y R2'!{col}{row}"
            longitud = arr_longitudes[index]
            formato = "0" * longitud
            formula_parts.append(f'TEXT({ref}, "{formato}")')
        
        # Segmento 3: Procesar ws2, parte 2 (ws2_cols_third)
        for i, col in enumerate(ws2_cols_third):
            index = len(ws2_cols_one) + len(ws_cols_second) + i  # índice 18 + 1 = 19
            ref = f"'Registro2_Validacion'!{col}{row}"
            longitud = arr_longitudes[index]
            formato = "0" * longitud
            part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
            formula_parts.append(part)
        
        # Segmento 4: Procesar ws, siguiente (ws_cols_four)
        for i, col in enumerate(ws_cols_four):
            index = len(ws2_cols_one) + len(ws_cols_second) + len(ws2_cols_third) + i  # índice 18+1+1 = 20, luego 21, 22
            ref = f"'Comparativa R3 y R2'!{col}{row}"
            longitud = arr_longitudes[index]
            formato = "0" * longitud
            formula_parts.append(f'TEXT({ref}, "{formato}")')
        
        # Combinar todas las partes con el operador de concatenación "&"
        formula = "=" + " & ".join(formula_parts)
           # Escribir la fórmula en la columna deseada de la hoja ws (por ejemplo, columna 33)
        ws.cell(row=row, column=60).value = formula

    # 1. Copiar las columnas 10 y 11 de ws2 a las columnas 1 y 2 de ws_detalle
    for r in range(1, ws2.max_row + 1):
        ws_detalle.cell(row=r, column=1).value = ws2.cell(row=r, column=18).value
        ws_detalle.cell(row=r, column=2).value = ws2.cell(row=r, column=19).value

    # 2. Definir las columnas a extraer (se usa el mismo arreglo que en el bloque original)
    columns_to_extract = [25,27,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,76,77,78,79,80,81,82]  

    # 3. Copiar a partir de la columna 3 de ws_detalle los datos extraídos de ws2
    for r in range(1, ws2.max_row + 1):
        for idx, col in enumerate(columns_to_extract):
            val = ws2.cell(row=r, column=col).value
            if r < 3:
                new_val = val  # Para las dos primeras filas se copia el valor sin transformación
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            ws_detalle.cell(row=r, column=3 + idx).value = new_val

    # --- Bloque de Estilos para "Detalle RentaB" ---
    # Se asume que ya se han definido los estilos en el código principal:
    # thick_border, font_TT12 (bold, size 12), fill_80 y Alignment
    #
    # Por ejemplo, en el código original se definieron:
    #     font_TT12 = Font(bold=True, size=12)
    #     fill_80 = PatternFill("solid", fgColor="BDD7EE")
    #     thick_border = Border(left=Side(style="thick"),
    #                           right=Side(style="thick"),
    #                           top=Side(style="thick"),
    #                           bottom=Side(style="thick"))
    
    # Aplicar estilos a las dos primeras filas (encabezados) en ws_detalle
    for row in ws_detalle.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border
    
    # Ajustar los anchos de columnas en la hoja "Detalle RentaB"
    # Se puede ajustar el ancho fijo o calcularlo en función del contenido;
    # aquí se asigna un ancho fijo de 15 a cada columna, similar a lo usado en otras hojas.
    from openpyxl.utils import get_column_letter
    for col in range(1, ws_detalle.max_column + 1):
        col_letter = get_column_letter(col)
        ws_detalle.column_dimensions[col_letter].width = 40

    # Congelar las dos primeras filas (es decir, se quedarán fijas mientras se desplaza el resto)
    ws_detalle.freeze_panes = "A3"  # Esto congela las filas 1 y 2

    # Aplicar un AutoFilter a toda la hoja desde la fila 2 hasta la última,
    # obteniendo la letra de la última columna y el número de la última fila.
    last_col_letter = get_column_letter(ws_detalle.max_column)
    ws_detalle.auto_filter.ref = f"A2:{last_col_letter}{ws_detalle.max_row}"        
#------------------------------------------------------------------------------------------------------------------------
    # Primero definimos una función auxiliar para determinar si una celda es la celda superior izquierda de un rango fusionado
    def is_top_left_merged(cell, ws):
        for merged_range in ws.merged_cells.ranges:
            if cell.coordinate in merged_range:
                return cell.coordinate == merged_range.start_cell.coordinate
        return True

    # Aplicar un borde y centrado a todas las celdas de datos (desde la fila 5 en adelante)
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=8, max_col=ws.max_column):
        for cell in row:
            cell.border = thin_border
            cell.alignment = center_alignment

    for r in range(5, ws.max_row + 1):
        # Comprobar si en las columnas A, B, D y E la fila está vacía (sin valor o solo espacios)
        if all(ws.cell(row=r, column=c).value in (None, "", " ") for c in [1, 2, 4, 5]):
            continue  # Si la fila está vacía, se salta
        for c in [1, 2, 4, 5]:
            cell = ws.cell(row=r, column=c)
            if cell.value not in (None, "", " "):
                if is_top_left_merged(cell, ws):
                    cell.border = thin_border

    # Se asume que thick_border, fill_80, font_TT12 y ws ya están definidos.

    def aplicar_estilos_a_rango(ws, rango, border, fill, font):
        """Aplica los estilos a todas las celdas dentro de un rango fusionado."""
        for fila in range(rango.min_row, rango.max_row + 1):
            for col in range(rango.min_col, rango.max_col + 1):
                celda = ws.cell(row=fila, column=col)
                celda.border = border
                celda.fill = fill
                celda.font = font

    # ===============================
    # 1. Aplicar formato a la fila 1 y 2,
    #    pero solo a celdas (o rangos fusionados) con valor.
    # ===============================
    merged_procesados = set()
    for row in [1, 2]:  # Ahora aplicamos a la fila 1 y la fila 2
        for col in range(1, ws.max_column + 1):
            celda = ws.cell(row=row, column=col)
            # Buscar si la celda pertenece a un rango fusionado.
            rango_fusionado = None
            for mr in ws.merged_cells.ranges:
                if celda.coordinate in mr:
                    rango_fusionado = mr
                    break
            if rango_fusionado:
                # Evitar reprocesar el mismo rango.
                if rango_fusionado in merged_procesados:
                    continue
                # Solo se aplica el formato si la celda superior izquierda tiene valor.
                celda_superior = ws.cell(row=rango_fusionado.min_row, column=rango_fusionado.min_col)
                if celda_superior.value is None:
                    merged_procesados.add(rango_fusionado)
                    continue
                aplicar_estilos_a_rango(ws, rango_fusionado, thick_border, fill_80, font_TT12)
                merged_procesados.add(rango_fusionado)
            else:
                # Si no está fusionada, se formatea solo si la celda tiene algún valor.
                if celda.value is None:
                    continue
                celda.border = thick_border
                celda.fill = fill_80
                celda.font = font_TT12

# ==========================================================
    # 2. Aplicar formato a las columnas A y E para filas desde la 5 en adelante
    #    (se omite la fila completa si en A y E están ambas vacías)
    # ==========================================================
    for row in range(5, ws.max_row + 1):
        # Si ambas celdas A y E están vacías, se omite la fila.
        if ws.cell(row=row, column=1).value is None and ws.cell(row=row, column=5).value is None:
            continue

        # --- Columna A (posible fusión A:B) ---
        cell_A = ws.cell(row=row, column=1)
        procesada_A = False
        for mr in ws.merged_cells.ranges:
            if cell_A.coordinate in mr:
                # Si es una fusión en A:B (columna 1 y 2)
                if mr.min_col == 1 and mr.max_col == 2:
                    # Se aplica el formato a todo el rango fusionado
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_A.border = thick_border
                    cell_A.fill = fill_80
                    cell_A.font = font_TT12
                procesada_A = True
                break
        if not procesada_A:
            # Si la celda no está fusionada, se aplica el formato.
            cell_A.border = thick_border
            cell_A.fill = fill_80
            cell_A.font = font_TT12

        # --- Columna E (posible fusión D:E; D=4 y E=5) ---
        cell_E = ws.cell(row=row, column=5)
        procesada_E = False
        for mr in ws.merged_cells.ranges:
            if cell_E.coordinate in mr:
                # Si es una fusión en D:E (columnas 4 y 5)
                if mr.min_col == 4 and mr.max_col == 5:
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_E.border = thick_border
                    cell_E.fill = fill_80
                    cell_E.font = font_TT12
                procesada_E = True
                break
        if not procesada_E:
            cell_E.border = thick_border
            cell_E.fill = fill_80
            cell_E.font = font_TT12

    # Para la nueva hoja (ws) desde la columna L hasta la última columna con datos:
    for col in range(8, ws.max_column + 1):
        col_letter = get_column_letter(col)
        ws.column_dimensions[col_letter].width = 36
        for r in [1, 2]:
            cell = ws.cell(row=r, column=col)
            if cell.value is None or str(cell.value).strip() == "":
                cell.border = None
            else:
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border

    # Ajustar los textos de todas las celdas de todas las hojas
    for ws_temp in wb.worksheets:
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value is not None and str(cell.value).strip() != "":
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.column_dimensions["BH"].width = 600

    # Guardar el archivo de salida
    try:
        wb.save(output_file)
        wb.close()
        print(f"Archivo generado: {output_file}")
    except Exception as e:
        print(f"Error al guardar el archivo: {e}")

if __name__ == "__main__":
    procesar_dj()