import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Border, Side, PatternFill, Alignment
from openpyxl.utils import get_column_letter
import os

def acceder_hojas(modified_file_path, lista_hojas=None):
    """
    Función base para acceder a las hojas necesarias de un archivo Excel modificado.
    Se puede reutilizar para aplicar reglas especiales a distintos DJ.
    
    Args:
        modified_file_path (str): Ruta del archivo Excel modificado.
        lista_hojas (list): Lista de nombres de hojas requeridas. Si se omite,
                             se usan por defecto ["Registro3_Validacion", "Registro2_Validacion"].
    
    Returns:
        tuple: (hojas, workbook)
               hojas: Diccionario con las hojas extraídas (clave: nombre de la hoja, valor: objeto worksheet).
               workbook: Objeto workbook de openpyxl, que se debe cerrar o guardar posteriormente.
    """
    if lista_hojas is None:
        lista_hojas = ["Registro3_Validacion", "Registro2_Validacion"]
    try:
        wb = load_workbook(modified_file_path)
    except Exception as e:
        print(f"Error al abrir {modified_file_path} con openpyxl: {e}")
        return None, None

    hojas = {}
    for hoja in lista_hojas:
        if hoja in wb.sheetnames:
            hojas[hoja] = wb[hoja]
        else:
            print(f"La hoja '{hoja}' no se encontró en el archivo modificado.")
    return hojas, wb

def procesar_dj():
    # Rutas específicas para DJ 1894 (archivo de entrada y salida)
    modified_file = os.environ.get("MODIFIED_FILE")
    if not modified_file or not os.path.exists(modified_file):
        print("No se encontró el archivo modificado.")
        return

    # Define la ruta de salida para este DJ de forma dinámica
    output_file = os.path.join(os.path.dirname(modified_file), "Registros_Validados_1944.xlsx")
  # Accedemos a las tres hojas requeridas para DJ 1894:
    # "Registro2_Validacion", "Registro3.1_Validacion" y "Registro3.2_Validacion"
    hojas, wb = acceder_hojas(modified_file, lista_hojas=["Registro2_Validacion", "Registro3.1_Validacion"])
    if wb is None:
        print("No se pudo abrir el archivo modificado.")
        return

    # Crear la nueva hoja especial para DJ 1894
    ws = wb.create_sheet("Comparativa R3 y R2")
    ws2 = hojas["Registro2_Validacion"]
    ws_detalle = wb.create_sheet("Detalle RentaB")

    # Aplicar fusiones y asignar valores estéticos (inicio común)
    ws.merge_cells("A1:E1")
    ws["A1"] = "Comparativa de Registro3 con Registro2"
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.column_dimensions["A"].width = 50

    ws.merge_cells("A3:B3")
    ws["A3"] = "Datos Registro3"
    ws["A3"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("D3:E3")
    ws["D3"] = "Datos Registro 2"
    ws["D3"].alignment = Alignment(horizontal="center", vertical="center")
    
    # Extraer valores de las hojas:
    hoja31 = hojas["Registro3.1_Validacion"]
    
    # --- Se desplazan todas las asignaciones una fila hacia abajo ---
    # 1. Fusionar A5:B5 y asignar el valor de A12 de hoja31
    ws.merge_cells("A5:B5")
    ws["A5"] = hoja31["A12"].value
    ws["A6"] = hoja31["B13"].value
    ws["B6"] = hoja31["D13"].value
    ws["A7"] = hoja31["B14"].value
    ws["B7"] = hoja31["D14"].value

    ws.merge_cells("A9:B9")
    ws["A9"] = hoja31["A15"].value
    ws["A10"] = hoja31["B16"].value
    ws["B10"] = hoja31["D16"].value
    ws["A11"] = hoja31["B17"].value
    ws["B11"] = hoja31["D17"].value

    ws["A13"] = hoja31["A18"].value
    ws["B13"] = hoja31["D18"].value

    ws.merge_cells("A15:B15")
    ws["A15"] = hoja31["A19"].value
    ws.merge_cells("A16:B16")
    ws["A16"] = hoja31["A20"].value
    ws["A17"] = hoja31["B21"].value
    ws["B17"] = hoja31["D21"].value
    ws["A18"] = hoja31["B22"].value
    ws["B18"] = hoja31["D22"].value

    ws["A20"] = hoja31["A23"].value
    ws["B20"] = hoja31["D23"].value

    ws.merge_cells("A22:B22")
    ws["A22"] = hoja31["A24"].value
    ws["A23"] = hoja31["B25"].value
    ws["B23"] = hoja31["D25"].value
    ws["A24"] = hoja31["B26"].value
    ws["B24"] = hoja31["D26"].value

    ws.merge_cells("A26:B26")
    ws["A26"] = hoja31["A27"].value
    ws["A27"] = hoja31["B28"].value
    ws["B27"] = hoja31["D28"].value
    ws["A28"] = hoja31["B29"].value
    ws["B28"] = hoja31["D29"].value

    ws["A30"] = hoja31["A31"].value
    ws["B30"] = hoja31["D31"].value


 # 18. Bloque Nuevo: Copiar, a partir de la fila 5, todos los datos de la columna A en la columna E
    # (Desde E5 en adelante)
    for row in range(5, ws.max_row + 1):
        cell_a = ws.cell(row=row, column=1)
        # Buscamos si la celda A está en un rango combinado
        rango_combinado = None
        for mrange in ws.merged_cells.ranges:
            if cell_a.coordinate in mrange:
                rango_combinado = mrange
                break

        # Si la celda A forma parte de un rango combinado de A:B
        if rango_combinado and rango_combinado.min_col == 1 and rango_combinado.max_col == 2:
            # Fusionamos las celdas D y E en esa fila
            ws.merge_cells(start_row=row, start_column=4, end_row=row, end_column=5)
            # Se asigna el valor a la celda superior (D) de la celda fusionada
            ws.cell(row=row, column=4).value = cell_a.value
        else:
            # Si no está combinada, copia el valor de A a la columna E normalmente
            ws.cell(row=row, column=5).value = cell_a.value

# DEFINICIÓN DE ESTILOS
    thick_border = Border(left=Side(style="thick"),
                          right=Side(style="thick"),
                          top=Side(style="thick"),
                          bottom=Side(style="thick"))
    thin_border = Border(left=Side(style="thin"),
                         right=Side(style="thin"),
                         top=Side(style="thin"),
                         bottom=Side(style="thin"))
    font_TT14 = Font(bold=True, size=14)
    font_TT12 = Font(bold=True, size=12)
    fill_60 = PatternFill("solid", fgColor="8DB4E2")  # Azul oscuro con claro 40%
    fill_80 = PatternFill("solid", fgColor="BDD7EE")  # Azul oscuro con claro 60%
    # Para Grupo 3 y 4 se reutiliza fill_60 en este ejemplo
    center_alignment = Alignment(horizontal="center", vertical="center")
    # Aplicar estilos a la fila de encabezado (A1:E1)
    for row in ws["A1:E1"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango A3:B3
    for row in ws["A3:B3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment

    # Aplicar estilos a los encabezados en el rango D3:E3
    for row in ws["D3:E3"]:
        for cell in row:
            cell.font = font_TT14
            cell.fill = fill_60
            cell.border = thick_border
            cell.alignment = center_alignment


    # Ajustar anchos de columnas para mejorar la apariencia
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 15
    ws.column_dimensions["C"].width = 15
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 30

# Definimos los índices de las columnas a extraer: S, U, W, X y AB
    columns_to_extract = [13, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]

    for r in range(1, ws2.max_row + 1):
        for idx, col in enumerate(columns_to_extract):
            val = ws2.cell(row=r, column=col).value
            if r < 3:
                new_val = val  # Sin transformación para las dos primeras filas
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            # Insertar en la nueva hoja: la columna destino es H (8) + idx
            ws.cell(row=r, column=8 + idx).value = new_val

    ultima_fila = ws.max_row

    ws["D6"].value = f"=SUM(H3:H{ultima_fila})" # Columna 31 -> AE
    ws["D7"].value = f"=SUM(I3:I{ultima_fila})" # Columna 32 -> AF

    ws["D10"].value = f"=SUM(J3:J{ultima_fila})" # Columna 31 -> AE
    ws["D11"].value = f"=SUM(K3:K{ultima_fila})" # Columna 32 -> AF

    ws["D13"].value = f"=SUM(L3:L{ultima_fila})" # Columna 31 -> AE
    ws["D17"].value = f"=SUM(M3:M{ultima_fila})" # Columna 32 -> AF

    ws["D18"].value = f"=SUM(N3:N{ultima_fila})" # Columna 31 -> AE
    ws["D20"].value = f"=SUM(O3:O{ultima_fila})" # Columna 32 -> AF

    ws["D23"].value = f"=SUM(P3:P{ultima_fila})" # Columna 31 -> AE
    ws["D24"].value = f"=SUM(Q3:Q{ultima_fila})" # Columna 32 -> AF

    ws["D27"].value = f"=SUM(R3:R{ultima_fila})" # Columna 31 -> AE
    ws["D28"].value = f"=SUM(S3:S{ultima_fila})" # Columna 32 -> AF

    count_L = 0
    for cell in ws2["M"]:
        if cell.row >= 3:
            if cell.value is not None and str(cell.value).strip() != "":
                count_L += 1
    ws["D30"].value = count_L

    # Para la hoja2, aplicar estilos solo a las celdas no vacías de las dos primeras filas
    for row in ws2.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border

    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value not in (None, "", " "):
                    # Si la celda está en la primera fila o en la primera columna, aplicamos borde grueso, negrita y fill
                    if cell.row == 1 or cell.column == 1:
                        cell.border = thick_border
                        cell.font = font_TT12
                        cell.fill = fill_80
                        cell.alignment = center_alignment
                    else:
                        cell.border = thin_border

        # 2. Para todas las hojas que NO sean la nueva ni la hoja2, ajustar la columna B.
    for sheet_name in wb.sheetnames:
        if sheet_name in ["Comparativa R3 y R2", "Registro2_Validacion"]:
            continue
        ws_temp = wb[sheet_name]
        # Ajustar el ancho de la columna B a 30
        ws_temp.column_dimensions["B"].width = 30
        ws_temp.column_dimensions["E"].width = 55
        ws_temp.column_dimensions["C"].width = 26
        ws_temp.column_dimensions["D"].width = 26
        # Recorrer la columna B y aplicar estilos en las celdas con datos.
        for cell in ws_temp["B"]:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.border = thick_border
                cell.font = font_TT12
                cell.fill = fill_80

#------------------------------------------------------------------------------------------------------------------------                

    # Definir el arreglo de longitudes (27 números en total, en el orden indicado)
    arr_longitudes = [
        # Segmento 1: ws2, parte 1: "ABCDEFGHIJKLM" (13 columnas)
        1, 4, 1, 7, 1, 8, 1, 8, 1, 8, 1,
        # Segmento 2: ws, primer elemento: "N" (1 columna)
        15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,
        # Segmento 3: ws2, parte 2: ["O", "P"] (2 columnas)
        7
    ]

    # Definir las columnas a extraer de ws2 por segmentos:
    ws2_cols_first = list("ABCDEFGHIJK")         # 13 columnas: A a M
    ws2_cols_second = ["X"]                   # 2 columnas


    # Definir las columnas a extraer de ws (Comparativa R3 y R2):
    ws_cols = list("HIJKLMNOPQRS")    # 2 columnas, en el orden deseado

    # Determinar el máximo de filas a procesar (ajusta según tu caso)
    max_row = min(ws.max_row, ws2.max_row)

    for row in range(3, max_row + 1):
        formula_parts = []
        
        # Segmento 1: Procesar ws2, parte 1 ("ABCDEFGHIJ")
        for i, col in enumerate(ws2_cols_first):
            ref = f"'Registro2_Validacion'!{col}{row}"
            longitud = arr_longitudes[i]  # índices 0 a 12
            # Forzar que si la celda está vacía se use "" (para que REPT rellene con espacios)
            part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
            formula_parts.append(part)

        # Segmento 2: Procesar las columnas de ws (Comparativa R3 y R2)
        for j, col in enumerate(ws_cols):
            index = len(ws2_cols_first) + j  # índice empieza en 10
            ref = f"'Comparativa R3 y R2'!{col}{row}"
            longitud = arr_longitudes[index]
            formato = "0" * longitud
            formula_parts.append(f'TEXT({ref}, "{formato}")')
        
        # Segmento 3: Procesar ws2, parte 2 (PQRS)
        for k, col in enumerate(ws2_cols_second):
            ref = f"'Registro2_Validacion'!{col}{row}"
            index = len(ws2_cols_first) + len(ws_cols) + k  # CORREGIDO: suma total de columnas ya procesadas
            longitud = arr_longitudes[index]
            part = f'RIGHT(REPT(" ", {longitud}) & IF({ref}="","",{ref}), {longitud})'
            formula_parts.append(part)

        formula_parts.append('REPT(" ", 1)')

        # Combinar todas las partes con el operador de concatenación "&"
        formula = "=" + " & ".join(formula_parts)
        
        # Escribir la fórmula en la columna deseada de la hoja ws (por ejemplo, columna 33)
        ws.cell(row=row, column=20).value = formula
#------------------------------------------------------------------------------------------------------------------------
    # 1. Copiar las columnas 10 y 11 de ws2 a las columnas 1 y 2 de ws_detalle
    for r in range(1, ws2.max_row + 1):
        ws_detalle.cell(row=r, column=1).value = ws2.cell(row=r, column=8).value
        ws_detalle.cell(row=r, column=2).value = ws2.cell(row=r, column=9).value

    # 2. Definir las columnas a extraer (se usa el mismo arreglo que en el bloque original)
    columns_to_extract = [13, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23] 

    # 3. Copiar a partir de la columna 3 de ws_detalle los datos extraídos de ws2
    for r in range(1, ws2.max_row + 1):
        for idx, col in enumerate(columns_to_extract):
            val = ws2.cell(row=r, column=col).value
            if r < 3:
                new_val = val  # Para las dos primeras filas se copia el valor sin transformación
            else:
                try:
                    new_val = int(val) if val is not None else 0
                except Exception:
                    new_val = 0
            ws_detalle.cell(row=r, column=3 + idx).value = new_val

    # --- Bloque de Estilos para "Detalle RentaB" ---
    # Se asume que ya se han definido los estilos en el código principal:
    # thick_border, font_TT12 (bold, size 12), fill_80 y Alignment
    #
    # Por ejemplo, en el código original se definieron:
    #     font_TT12 = Font(bold=True, size=12)
    #     fill_80 = PatternFill("solid", fgColor="BDD7EE")
    #     thick_border = Border(left=Side(style="thick"),
    #                           right=Side(style="thick"),
    #                           top=Side(style="thick"),
    #                           bottom=Side(style="thick"))
    
    # Aplicar estilos a las dos primeras filas (encabezados) en ws_detalle
    for row in ws_detalle.iter_rows(min_row=1, max_row=2):
        for cell in row:
            if cell.value is not None and str(cell.value).strip() != "":
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border
    
    # Ajustar los anchos de columnas en la hoja "Detalle RentaB"
    # Se puede ajustar el ancho fijo o calcularlo en función del contenido;
    # aquí se asigna un ancho fijo de 15 a cada columna, similar a lo usado en otras hojas.
    from openpyxl.utils import get_column_letter
    for col in range(1, ws_detalle.max_column + 1):
        col_letter = get_column_letter(col)
        ws_detalle.column_dimensions[col_letter].width = 20
        
    # Congelar las dos primeras filas (es decir, se quedarán fijas mientras se desplaza el resto)
    ws_detalle.freeze_panes = "A3"  # Esto congela las filas 1 y 2

    # Aplicar un AutoFilter a toda la hoja desde la fila 2 hasta la última,
    # obteniendo la letra de la última columna y el número de la última fila.
    last_col_letter = get_column_letter(ws_detalle.max_column)
    ws_detalle.auto_filter.ref = f"A2:{last_col_letter}{ws_detalle.max_row}"


    # Primero definimos una función auxiliar para determinar si una celda es la celda superior izquierda de un rango fusionado
    def is_top_left_merged(cell, ws):
        for merged_range in ws.merged_cells.ranges:
            if cell.coordinate in merged_range:
                return cell.coordinate == merged_range.start_cell.coordinate
        return True

    # Aplicar un borde y centrado a todas las celdas de datos (desde la fila 5 en adelante)
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=8, max_col=ws.max_column):
        for cell in row:
            cell.border = thin_border
            cell.alignment = center_alignment

    for r in range(5, ws.max_row + 1):
        # Comprobar si en las columnas A, B, D y E la fila está vacía (sin valor o solo espacios)
        if all(ws.cell(row=r, column=c).value in (None, "", " ") for c in [1, 2, 4, 5]):
            continue  # Si la fila está vacía, se salta
        for c in [1, 2, 4, 5]:
            cell = ws.cell(row=r, column=c)
            if cell.value not in (None, "", " "):
                if is_top_left_merged(cell, ws):
                    cell.border = thin_border

    # Se asume que thick_border, fill_80, font_TT12 y ws ya están definidos.

    def aplicar_estilos_a_rango(ws, rango, border, fill, font):
        """Aplica los estilos a todas las celdas dentro de un rango fusionado."""
        for fila in range(rango.min_row, rango.max_row + 1):
            for col in range(rango.min_col, rango.max_col + 1):
                celda = ws.cell(row=fila, column=col)
                celda.border = border
                celda.fill = fill
                celda.font = font

    # ===============================
    # 1. Aplicar formato a la fila 2,
    #    pero solo a celdas (o rangos fusionados) con valor.
    # ===============================
    merged_procesados = set()
    for col in range(1, ws.max_column + 1):
        celda = ws.cell(row=2, column=col)
        # Buscar si la celda pertenece a un rango fusionado.
        rango_fusionado = None
        for mr in ws.merged_cells.ranges:
            if celda.coordinate in mr:
                rango_fusionado = mr
                break
        if rango_fusionado:
            # Evitar reprocesar el mismo rango.
            if rango_fusionado in merged_procesados:
                continue
            # Solo se aplica el formato si la celda superior izquierda tiene valor.
            celda_superior = ws.cell(row=rango_fusionado.min_row, column=rango_fusionado.min_col)
            if celda_superior.value is None:
                merged_procesados.add(rango_fusionado)
                continue
            aplicar_estilos_a_rango(ws, rango_fusionado, thick_border, fill_80, font_TT12)
            merged_procesados.add(rango_fusionado)
        else:
            # Si no está fusionada, se formatea solo si la celda tiene algún valor.
            if celda.value is None:
                continue
            celda.border = thick_border
            celda.fill = fill_80
            celda.font = font_TT12

    # ===============================
    # 1. Aplicar formato a la fila 1 y 2,
    #    pero solo a celdas (o rangos fusionados) con valor.
    # ===============================
    merged_procesados = set()
    for row in [1, 2]:  # Ahora aplicamos a la fila 1 y la fila 2
        for col in range(1, ws.max_column + 1):
            celda = ws.cell(row=row, column=col)
            # Buscar si la celda pertenece a un rango fusionado.
            rango_fusionado = None
            for mr in ws.merged_cells.ranges:
                if celda.coordinate in mr:
                    rango_fusionado = mr
                    break
            if rango_fusionado:
                # Evitar reprocesar el mismo rango.
                if rango_fusionado in merged_procesados:
                    continue
                # Solo se aplica el formato si la celda superior izquierda tiene valor.
                celda_superior = ws.cell(row=rango_fusionado.min_row, column=rango_fusionado.min_col)
                if celda_superior.value is None:
                    merged_procesados.add(rango_fusionado)
                    continue
                aplicar_estilos_a_rango(ws, rango_fusionado, thick_border, fill_80, font_TT12)
                merged_procesados.add(rango_fusionado)
            else:
                # Si no está fusionada, se formatea solo si la celda tiene algún valor.
                if celda.value is None:
                    continue
                celda.border = thick_border
                celda.fill = fill_80
                celda.font = font_TT12

# ==========================================================
    # 2. Aplicar formato a las columnas A y E para filas desde la 5 en adelante
    #    (se omite la fila completa si en A y E están ambas vacías)
    # ==========================================================
    for row in range(5, ws.max_row + 1):
        # Si ambas celdas A y E están vacías, se omite la fila.
        if ws.cell(row=row, column=1).value is None and ws.cell(row=row, column=5).value is None:
            continue

        # --- Columna A (posible fusión A:B) ---
        cell_A = ws.cell(row=row, column=1)
        procesada_A = False
        for mr in ws.merged_cells.ranges:
            if cell_A.coordinate in mr:
                # Si es una fusión en A:B (columna 1 y 2)
                if mr.min_col == 1 and mr.max_col == 2:
                    # Se aplica el formato a todo el rango fusionado
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_A.border = thick_border
                    cell_A.fill = fill_80
                    cell_A.font = font_TT12
                procesada_A = True
                break
        if not procesada_A:
            # Si la celda no está fusionada, se aplica el formato.
            cell_A.border = thick_border
            cell_A.fill = fill_80
            cell_A.font = font_TT12

        # --- Columna E (posible fusión D:E; D=4 y E=5) ---
        cell_E = ws.cell(row=row, column=5)
        procesada_E = False
        for mr in ws.merged_cells.ranges:
            if cell_E.coordinate in mr:
                # Si es una fusión en D:E (columnas 4 y 5)
                if mr.min_col == 4 and mr.max_col == 5:
                    aplicar_estilos_a_rango(ws, mr, thick_border, fill_80, font_TT12)
                else:
                    cell_E.border = thick_border
                    cell_E.fill = fill_80
                    cell_E.font = font_TT12
                procesada_E = True
                break
        if not procesada_E:
            cell_E.border = thick_border
            cell_E.fill = fill_80
            cell_E.font = font_TT12

    # Para la nueva hoja (ws) desde la columna L hasta la última columna con datos:
    for col in range(8, ws.max_column + 1):
        col_letter = get_column_letter(col)
        ws.column_dimensions[col_letter].width = 36
        for r in [1, 2]:
            cell = ws.cell(row=r, column=col)
            if cell.value is None or str(cell.value).strip() == "":
                cell.border = None
            else:
                cell.font = font_TT12
                cell.fill = fill_80
                cell.border = thick_border


    # Ajustar los textos de todas las celdas de todas las hojas
    for ws_temp in wb.worksheets:
        for row in ws_temp.iter_rows(min_row=1, max_row=ws_temp.max_row, min_col=1, max_col=ws_temp.max_column):
            for cell in row:
                if cell.value is not None and str(cell.value).strip() != "":
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.column_dimensions["T"].width = 220                    

    # Guardar el archivo de salida
    try:
        wb.save(output_file)
        wb.close()
        print(f"Archivo generado: {output_file}")
    except Exception as e:
        print(f"Error al guardar el archivo: {e}")

if __name__ == "__main__":
    procesar_dj()