import pandas as pd
import numpy as np
import os
import pickle
from collections import defaultdict

def ejecutar_fase222(txt_path, registros_path):
    if not os.path.exists(registros_path):
        print("❌ No se encontró el archivo de registros. Asegúrate de ejecutar la fase 1 primero.")
        return []

    # Cargar el diccionario de registros (pickle)
    with open(registros_path, "rb") as f:
        registros_dinamicos = pickle.load(f)

    print(f"✅ Fase 2: Cargados {len(registros_dinamicos)} registros.")
    
    if not os.path.exists(txt_path):
        print(f"❌ El archivo TXT no existe: {txt_path}")
        return []

    # Leemos todas las líneas del TXT (si bien esto se podría optimizar leyendo en streaming)
    with open(txt_path, 'r', encoding='utf-8') as file:
        lineas = file.readlines()
    
    resultados = []
    registros_2 = []               # Para construir Registro2_Validacion
    encabezado_registro2 = None    # Encabezado (primeras dos filas) de Registro2
    validaciones_usadas = defaultdict(int)
    validaciones_mapeo = {}

    # Recolectamos validaciones usadas en registros distintos a Registro2
    todas_las_validaciones = set()
    for clave_registro, data in registros_dinamicos.items():
        if "Registro2" not in clave_registro:
            tabla = data[0]
            todas_las_validaciones.update(tabla["VALIDACIONES DE FORMATO"].dropna().unique())
    
    # Cargamos el archivo de Registros Estructurados (usado para obtener "LARGO DEL REGISTRO")
    registros_estructurados_path = os.path.join(os.path.dirname(registros_path), "Registros_Estructurados.xlsx")
    df_estructurados = pd.read_excel(registros_estructurados_path, sheet_name=None)
    
    for linea in lineas:
        if len(linea) < 32:
            continue  
        
        # Se extraen el número de registro y de tabla a partir de la línea
        num_registro = linea[:1]  
        num_tabla = linea[1:2] if len(linea) > 1 else "1"  
        # Se arma la clave: se prueba primero con "RegistroX.Y"; si no existe, se usa "RegistroX"
        posible_clave = f"Registro{num_registro}.{num_tabla}"
        clave_registro = posible_clave if posible_clave in registros_dinamicos else f"Registro{num_registro}"
        
        if clave_registro in registros_dinamicos:
            tabla = registros_dinamicos[clave_registro][0]
            
            # ─────────────────────────────────────────────────────────────
            # Caso Registro2: se utiliza la columna "LARGO" de la tabla para determinar
            # los límites de cada campo en la línea TXT, de forma vectorizada.
            # ─────────────────────────────────────────────────────────────
            if "Registro2" in clave_registro:
                # Convertir cada valor en la columna "LARGO" a entero; si no se puede, se asume 0.
                try:
                    largos = tabla["LARGO"].apply(lambda x: int(x) if x and str(x).strip() != "" else 0).tolist()
                except Exception:
                    largos = [0] * len(tabla)
                # Calcular límites acumulados: el primer valor es 0, y cada siguiente es la suma de los anteriores.
                boundaries = np.cumsum([0] + largos)
                # Con estos límites se extrae, para cada campo, el segmento correspondiente de la línea.
                valores_extraidos = [
                    linea[int(boundaries[i]):int(boundaries[i+1])].strip() for i in range(len(largos))
                ]
                # Se construye el DataFrame tal como se hacía originalmente:
                df_fila = pd.DataFrame({
                    "CAMPOS": tabla["CAMPOS"].values,
                    "SUBCAMPOS": tabla["SUBCAMPOS"].values,
                    "Información TXT": valores_extraidos
                }).T  

                if encabezado_registro2 is None:
                    encabezado_registro2 = df_fila.iloc[:2]  
                
                registros_2.append(df_fila.iloc[2:].reset_index(drop=True))
            
            # ─────────────────────────────────────────────────────────────
            # Caso para otros registros (Registro1, Registro3, etc.)
            # Se utiliza la lógica original: se recorre cada fila de la tabla y se usa "LARGO" y "CARACTER"
            # para extraer el segmento correspondiente de la línea.
            # ─────────────────────────────────────────────────────────────
            else:
                valores_extraidos = []
                valores_convertidos = []
                posicion = 0  
                
                for _, fila in tabla.iterrows():
                    largo = fila.get("LARGO", "")
                    caracter = fila.get("CARACTER", "")
                    # Se obtiene la validación (aunque en esta versión solo se usa para la visualización)
                    validacion = fila.get("VALIDACIONES DE FORMATO", "")
                    
                    try:
                        largo = int(largo) if largo and str(largo).strip() != "" else 0
                    except ValueError:
                        largo = 0  
                    
                    if largo == 0:
                        valores_extraidos.append("")
                        valores_convertidos.append("")
                        continue
                    
                    valor_extraido = linea[posicion:posicion+largo]
                    posicion += largo
                    
                    if caracter == "N":
                        try:
                            valor_convertido = int(valor_extraido)
                        except ValueError:
                            valor_convertido = ""
                    else:
                        valor_convertido = valor_extraido
                    
                    valores_extraidos.append(valor_extraido)
                    valores_convertidos.append(valor_convertido)
                
                df_resultado = pd.DataFrame({
                    "CAMPOS": tabla["CAMPOS"].values,
                    "SUBCAMPOS": tabla["SUBCAMPOS"].values,
                    "Información TXT": valores_extraidos,
                    "Información TXT (Convertida)": valores_convertidos,
                    "VALIDACIONES DE FORMATO": tabla["VALIDACIONES DE FORMATO"].values,
                    "Validar": [
                        "☐" if pd.notna(valid) and str(valid).strip() != "" else ""
                        for valid in tabla["VALIDACIONES DE FORMATO"].values
                    ]
                })
                
                # Se calcula el largo total exacto de la línea (sin salto de línea)
                largo_total = len(linea.rstrip("\n"))
                df_largo = pd.DataFrame([
                    ["Largo"] + [largo_total] + ["" for _ in range(df_resultado.shape[1] - 2)]
                ], columns=df_resultado.columns)
                
                df_resultado = pd.concat([df_resultado, df_largo], ignore_index=True)
                
                # Se extrae el valor de "LARGO DEL REGISTRO" desde el archivo de registros estructurados
                for sheet_name, df in df_estructurados.items():
                    if df.shape[1] > 5:
                        mask = df.iloc[:, 1].astype(str).str.strip().str.upper() == "LARGO DEL REGISTRO"
                        if mask.any():
                            valor_largo_del_registro = df.loc[mask, df.columns[5]].values[0]
                            df_resultado.loc[df_resultado["CAMPOS"] == "LARGO DEL REGISTRO", "SUBCAMPOS"] = valor_largo_del_registro
                
                # Se eliminan las filas que contengan la palabra "Blancos" en alguna de las primeras 6 columnas
                df_resultado = df_resultado[~df_resultado.iloc[:, :6].apply(
                    lambda row: row.astype(str).str.contains("Blancos", na=False).any(), axis=1
                )]
              
                resultados.append((f"{clave_registro}_Validacion", df_resultado))
    
    # Fuera del bucle, se unen todos los datos de Registro2
    if registros_2:
        df_registro2 = pd.concat(registros_2, ignore_index=True)
        df_registro2 = pd.concat([encabezado_registro2, df_registro2], ignore_index=True)  
        df_registro2.columns = df_registro2.iloc[0]
        df_registro2 = df_registro2[1:].reset_index(drop=True)
        
        resultados.append(("Registro2_Validacion", df_registro2))
    
    return resultados
