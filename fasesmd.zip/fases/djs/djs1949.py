import pandas as pd

NAME = "DJ 1949"
SHEET_KEYS = ['R0', 'R1', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',        # ← Ajusta estos nombres
    'R1': 'Registro1.1_Validacion',      #    según tus hojas de Excel
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
}

# -------------------------------------------------------------------
# Aquí vas rellenando una vez que sepas el largo de cada campo
# -------------------------------------------------------------------
FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 10,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 6,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Código certificación > Cód. empresa': 2,
        'Código certificación > Nº de cliente': 4,
        'Localización del docto. > Unidad': 5,
        'Localización del docto. > Número de caja': 3,
        'Localización del docto. > Número de paquete': 5,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Cantidad de acciones al 31/12': 15,
        'Afectos a IGC y/o IA > Con Crédito por IDPC  Generados a contar del 01.01.2017': 20,
        'Afectos a IGC y/o IA > Con Crédito por IDPC  Acumulados hasta el 31.12.2016': 20,
        'Afectos a IGC y/o IA > Con Derecho a Crédito por IDPC Voluntario': 20,
        'Afectos a IGC y/o IA > Sin Derecho a Crédito': 20,
        'Rentas con tributación cumplida > Rentas provenientes del registro RAP y diferecnia inicial de sociedad acogida al ex Art.14 TER A) LIR': 20,
        'Rentas con tributación cumplida > Otras rentas percibidas Sin prioridad en su orden de imputación': 20,
        'Rentas con tributación cumplida > Exceso distribuciones desproporcionadas': 20,
        'Rentas con tributación cumplida > Utilidades afectadas con ISFUT': 20,
        'Rentas con tributación cumplida > Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681': 20,
        'Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) (Artículo 11, Ley 18.401), Afectas a Impuesto Adicional': 20,
        'Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) y/o Impuesto Adicional (IA)': 20,
        'Ingresos No Constitutivos de  Renta': 20,
        'No Sujetos a Restitución generados Hasta el 31.12.2019 > Sin derecho a devolución': 20,
        'No Sujetos a Restitución generados Hasta el 31.12.2019 > Con derecho a devolución': 20,
        'No Sujetos a Restitución generados a contar del 01.01.2020 > Sin derecho a devolución': 20,
        'No Sujetos a Restitución generados a contar del 01.01.2020 > Con derecho a devolución': 20,
        'Sujetos a Restitución > Sin derecho a devolución': 20,
        'Sujetos a Restitución > Con derecho a devolución': 20,
        'Sujetos a Restitución > Sin derecho a devolución': 20,
        'Sujetos a Restitución > Con derecho a devolución': 20,
        'Sujetos a Restitución > Sin derecho a devolución': 20,
        'Sujetos a Restitución > Con derecho a devolución': 20,
        'Créditopor IPE': 20,
        'Asociados a rentas afectas > Sin derecho a devolución': 20,
        'Asociados a rentas afectas > Con derecho a devolución': 20,
        'Asociados a rentas exentas > Sin derecho a devolución': 20,
        'Asociados a rentas exentas > Con derecho a devolución': 20,
        'Crédito por IPE': 20,
        'Crédito por Impuesto Tasa Adicional ex. Art. 21 LIR.': 20,
        'Devolución de Capital art.17 N° 7 LIR': 20,
        'Total de Casos Informados': 10,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
        'Rut Profesional o Técnico que elaboró los registros > Nº de RUT': 8,
        'Rut Profesional o Técnico que elaboró los registros > Dígito verific.': 1,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Fecha del dividendo distribuido': 8,
        'RUT  de la sociedad pagadora del dividendo > Nº de RUT': 8,
        'RUT  de la sociedad pagadora del dividendo > Díg.verificador': 1,
        'Tipo S.A.': 1,
        'RUT del beneficiario del los dividendos distribuidos > Nº de RUT': 8,
        'RUT del beneficiario del los dividendos distribuidos > Díg.verificador': 1,
        'Cantidad de acciones al 31/12': 15,
        'Afectos a IGC y/o IA > Con Crédito por IDPC  Generados a contar del 01.01.2017': 18,
        'Afectos a IGC y/o IA > Con Crédito por IDPC  Acumulados hasta el 31.12.2016': 18,
        'Afectos a IGC y/o IA > Con Derecho a Crédito por IDPC Voluntario': 18,
        'Afectos a IGC y/o IA > Sin Derecho a Crédito': 18,
        'Rentas con tributación cumplida > Rentas provenientes del registro RAP y diferecnia inicial de sociedad acogida al ex Art.14 TER A) LIR': 18,
        'Rentas con tributación cumplida > Otras rentas percibidas Sin prioridad en su orden de imputación': 18,
        'Rentas con tributación cumplida > Exceso distribuciones desproporcionadas': 18,
        'Rentas con tributación cumplida > Utilidades afectadas con ISFUT': 18,
        'Rentas con tributación cumplida > Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681': 18,
        'Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) (Artículo 11, Ley 18.401), Afectas a Impuesto Adicional': 18,
        'Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) y/o Impuesto Adicional (IA)': 18,
        'Ingresos No Constitutivos de  Renta': 18,
        'No Sujetos a Restitución generados Hasta el 31.12.2019 > Sin derecho a devolución': 18,
        'No Sujetos a Restitución generados Hasta el 31.12.2019 > Con derecho a devolución': 18,
        'No Sujetos a Restitución generados a contar del 01.01.2020 > Sin derecho a devolución': 18,
        'No Sujetos a Restitución generados a contar del 01.01.2020 > Con derecho a devolución': 18,
        'Sujetos a Restitución > Sin derecho a devolución': 18,
        'Sujetos a Restitución > Con derecho a devolución': 18,
        'Sujetos a Restitución > Sin derecho a devolución.1': 18,
        'Sujetos a Restitución > Con derecho a devolución.1': 18,
        'Créditopor IPE': 18,
        'Asociados a rentas afectas > Sin derecho a devolución': 18,
        'Asociados a rentas afectas > Con derecho a devolución': 18,
        'Asociados a rentas exentas > Sin derecho a devolución': 18,
        'Asociados a rentas exentas > Con derecho a devolución': 18,
        'Crédito por IPE': 18,
        'Crédito por Impuesto Tasa Adicional ex. Art. 21 LIR.': 18,
        'Devolución de Capital art.17 N° 7 LIR': 18,
        'Número de Certificado': 7,
    },
}

def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con multi-índice y dtype=str para preservar ceros.
    """
    dfs = {}
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)
    # — Ahora imprimimos los índices y etiquetas de R0, R1 y R3 —
    for rec in ['R0','R1','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: índices y etiquetas ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(f"{i:3d}: {label}")

    # — Imprimimos R2: nivel0 y nivel1 de cada columna con su índice —
    df2 = dfs['R2']
    print("\n=== R2: índices de columnas (lvl0, lvl1) ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        # si lvl1 es 'Unnamed' sólo mostramos lvl0
        if str(lvl1).startswith("Unnamed"):
            print(f"{idx:3d}: {lvl0}")
        else:
            print(f"{idx:3d}: {lvl0} > {lvl1}")

    return dfs

def print_fields(dfs):
    """
    Imprime en consola todos los labels de R0, R1, R2 y R3
    para ayudarte a poblar FIELD_LENGTHS.
    """
    # — R0, R1 y R3 (verticales de tres columnas) —
    for rec in ['R0','R1','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: campos ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(label)

    # — R2 (multi-índice) —
    df2 = dfs['R2']
    print("\n=== R2: columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        label = f"{lvl0} > {lvl1}" if not str(lvl1).startswith("Unnamed") else str(lvl0)
        print(f"{idx:3d}: {label}")

def _get_val_vertical(df, label):
    """Busca en df (tres columnas) el valor cuya etiqueta ensamblada == label."""
    current = ''
    for i in range(len(df)):
        hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        if pd.notna(val):
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return str(val)
    return ''

def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera las líneas de texto [R0_line, R1_line, *R2_rows, R3_line].
    Usa FIELD_LENGTHS para hacer zfill donde corresponda.
    """
    lines = []
    RIGHT_PAD_FIELDS = {
    'Razón Social o Nombre',
    'Dirección Postal',
    'Comuna',
    'Correo Electrónico',
    }
    # --- R0 ---
    df0 = dfs['R0']
    parts0 = []
    for i in range(1, len(df0)):
        raw_hdr, raw_sub, raw_val = df0.iat[i,0], df0.iat[i,1], df0.iat[i,2]
        if pd.isna(raw_val):
            continue
        hdr_txt = str(raw_hdr).strip()
        sub_txt = str(raw_sub).strip() if pd.notna(raw_sub) else ''
        label = f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt
        txt = str(raw_val).strip()
        length = FIELD_LENGTHS['R0'].get(label)
        if length:
            txt = txt.zfill(length)
        parts0.append(txt)
    lines.append(''.join(parts0))

    # --- R1 ---
    df1 = dfs['R1']
    parts1 = []
    for i in range(1, len(df1)):
        raw_hdr, raw_sub, raw_val = df1.iat[i,0], df1.iat[i,1], df1.iat[i,2]
        if pd.isna(raw_val):
            continue
        hdr_txt = str(raw_hdr).strip()
        sub_txt = str(raw_sub).strip() if pd.notna(raw_sub) else ''
        label = f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt
        txt = str(raw_val).strip()
        length = FIELD_LENGTHS['R1'].get(label)
        if length is not None:
            if label in RIGHT_PAD_FIELDS:
                txt = txt.ljust(length)
            else:
                txt = txt.zfill(length)
        parts1.append(txt)
    lines.append(''.join(parts1))

    # --- R2 (fila a fila) ---
    df2_clean = df_r2.dropna(how='all')
    for _, row in df2_clean.iterrows():
        parts = []
        for (lvl0, lvl1), raw_v in zip(df_r2.columns, row.values):
            txt = str(raw_v).strip() if pd.notna(raw_v) else ''
            lvl0_txt = str(lvl0).strip()
            lvl1_txt = str(lvl1).strip()
            label = lvl0_txt if lvl1_txt.startswith("Unnamed") else f"{lvl0_txt} > {lvl1_txt}"
            length = FIELD_LENGTHS['R2'].get(label)
            if length:
                txt = txt.zfill(length)
            parts.append(txt)
        lines.append(''.join(parts))

    # --- R3 ---
    df3 = dfs['R3']
    parts3 = []
    for i in range(1, len(df3)):
        raw_hdr, raw_sub, raw_val = df3.iat[i,0], df3.iat[i,1], df3.iat[i,2]
        if pd.isna(raw_val):
            continue
        hdr_txt = str(raw_hdr).strip()
        sub_txt = str(raw_sub).strip() if pd.notna(raw_sub) else ''
        label = f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt
        txt = str(raw_val).strip()
        length = FIELD_LENGTHS['R3'].get(label)
        if length:
            txt = txt.zfill(length)
        parts3.append(txt)
    lines.append(''.join(parts3))

    return lines


def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2 (count/sum).
    Define aquí tu lista de `config = [ {...}, ... ]`
    siguiendo el esquema de DJ 1932/1944.
    """
    df3 = dfs['R3']

    # 1) Construir mapa label→fila en R3
    label_to_row = {}
    for i in range(1, len(df3)):
        raw_hdr = df3.iat[i,0]
        raw_sub = df3.iat[i,1]
        hdr_txt = str(raw_hdr).strip()
        sub_txt = str(raw_sub).strip() if pd.notna(raw_sub) else ''
        key = (f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt).lower()
        label_to_row[key] = i

    # 2) Lista de configs (ejemplo vacío; completa con tus casos)
    config = [
        {
          "type": "count",
          "r3_match": "Total de Casos Informados",
          "r3_index": 56,
          "length": FIELD_LENGTHS['R3']["Total de Casos Informados"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Cantidad de acciones al 31/12",
            "r2_lvl1_match":"",
            "r3_match":"Cantidad de acciones al 31/12",
            "r3_index":11,
            "length":FIELD_LENGTHS['R3']["Cantidad de acciones al 31/12"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Afectos a IGC y/o IA",
            "r2_lvl1_match":"Con Crédito por IDPC  Generados a contar del 01.01.2017",
            "r3_match":"Afectos a IGC y/o IA > Con Crédito por IDPC  Generados a contar del 01.01.2017",
            "r3_index":14,
            "length":FIELD_LENGTHS['R3']["Afectos a IGC y/o IA > Con Crédito por IDPC  Generados a contar del 01.01.2017"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Afectos a IGC y/o IA",
            "r2_lvl1_match":"Con Crédito por IDPC  Acumulados hasta el 31.12.2016",
            "r3_match":"Afectos a IGC y/o IA > Con Crédito por IDPC  Acumulados hasta el 31.12.2016",
            "r3_index":15,
            "length":FIELD_LENGTHS['R3']["Afectos a IGC y/o IA > Con Crédito por IDPC  Acumulados hasta el 31.12.2016"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Afectos a IGC y/o IA",
            "r2_lvl1_match":"Con Derecho a Crédito por IDPC Voluntario",
            "r3_match":"Afectos a IGC y/o IA > Con Derecho a Crédito por IDPC Voluntario",
            "r3_index":16,
            "length":FIELD_LENGTHS['R3']["Afectos a IGC y/o IA > Con Derecho a Crédito por IDPC Voluntario"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Afectos a IGC y/o IA",
            "r2_lvl1_match":"Sin Derecho a Crédito",
            "r3_match":"Afectos a IGC y/o IA > Sin Derecho a Crédito",
            "r3_index":17,
            "length":FIELD_LENGTHS['R3']["Afectos a IGC y/o IA > Sin Derecho a Crédito"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Rentas con tributación cumplida",
            "r2_lvl1_match":"Rentas provenientes del registro RAP y diferecnia inicial de sociedad acogida al ex Art.14 TER A) LIR",
            "r3_match":"Rentas con tributación cumplida > Rentas provenientes del registro RAP y diferecnia inicial de sociedad acogida al ex Art.14 TER A) LIR",
            "r3_index":20,
            "length":FIELD_LENGTHS['R3']["Rentas con tributación cumplida > Rentas provenientes del registro RAP y diferecnia inicial de sociedad acogida al ex Art.14 TER A) LIR"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Rentas con tributación cumplida",
            "r2_lvl1_match":"Otras rentas percibidas Sin prioridad en su orden de imputación",
            "r3_match":"Rentas con tributación cumplida > Otras rentas percibidas Sin prioridad en su orden de imputación",
            "r3_index":21,
            "length":FIELD_LENGTHS['R3']["Rentas con tributación cumplida > Otras rentas percibidas Sin prioridad en su orden de imputación"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Rentas con tributación cumplida",
            "r2_lvl1_match":"Exceso distribuciones desproporcionadas",
            "r3_match":"Rentas con tributación cumplida > Exceso distribuciones desproporcionadas",
            "r3_index":22,
            "length":FIELD_LENGTHS['R3']["Rentas con tributación cumplida > Exceso distribuciones desproporcionadas"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Rentas con tributación cumplida",
            "r2_lvl1_match":"Utilidades afectadas con ISFUT",
            "r3_match":"Rentas con tributación cumplida > Utilidades afectadas con ISFUT",
            "r3_index":23,
            "length":FIELD_LENGTHS['R3']["Rentas con tributación cumplida > Utilidades afectadas con ISFUT"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Rentas con tributación cumplida",
            "r2_lvl1_match":"Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681",
            "r3_match":"Rentas con tributación cumplida > Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681",
            "r3_index":24,
            "length":FIELD_LENGTHS['R3']["Rentas con tributación cumplida > Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Rentas exentas",
            "r2_lvl1_match":"Rentas Exentas de Impuesto Global Complementario (IGC) (Artículo 11, Ley 18.401), Afectas a Impuesto Adicional",
            "r3_match":"Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) (Artículo 11, Ley 18.401), Afectas a Impuesto Adicional",
            "r3_index":26,
            "length":FIELD_LENGTHS['R3']["Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) (Artículo 11, Ley 18.401), Afectas a Impuesto Adicional"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Rentas exentas",
            "r2_lvl1_match":"Rentas Exentas de Impuesto Global Complementario (IGC) y/o Impuesto Adicional (IA)",
            "r3_match":"Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) y/o Impuesto Adicional (IA)",
            "r3_index":27,
            "length":FIELD_LENGTHS['R3']["Rentas exentas > Rentas Exentas de Impuesto Global Complementario (IGC) y/o Impuesto Adicional (IA)"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Ingresos No Constitutivos de  Renta",
            "r2_lvl1_match":"",
            "r3_match":"Ingresos No Constitutivos de  Renta",
            "r3_index":28,
            "length":FIELD_LENGTHS['R3']["Ingresos No Constitutivos de  Renta"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"No Sujetos a Restitución generados Hasta el 31.12.2019",
            "r2_lvl1_match":"Sin derecho a devolución",
            "r3_match":"No Sujetos a Restitución generados Hasta el 31.12.2019 > Sin derecho a devolución",
            "r3_index":33,
            "length":FIELD_LENGTHS['R3']["No Sujetos a Restitución generados Hasta el 31.12.2019 > Sin derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"No Sujetos a Restitución generados Hasta el 31.12.2019",
            "r2_lvl1_match":"Con derecho a devolución",
            "r3_match":"No Sujetos a Restitución generados Hasta el 31.12.2019 > Con derecho a devolución",
            "r3_index":34,
            "length":FIELD_LENGTHS['R3']["No Sujetos a Restitución generados Hasta el 31.12.2019 > Con derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"No Sujetos a Restitución generados a contar del 01.01.2020",
            "r2_lvl1_match":"Sin derecho a devolución",
            "r3_match":"No Sujetos a Restitución generados a contar del 01.01.2020 > Sin derecho a devolución",
            "r3_index":36,
            "length":FIELD_LENGTHS['R3']["No Sujetos a Restitución generados a contar del 01.01.2020 > Sin derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"No Sujetos a Restitución generados a contar del 01.01.2020",
            "r2_lvl1_match":"Con derecho a devolución",
            "r3_match":"No Sujetos a Restitución generados a contar del 01.01.2020 > Con derecho a devolución",
            "r3_index":37,
            "length":FIELD_LENGTHS['R3']["No Sujetos a Restitución generados a contar del 01.01.2020 > Con derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Sujetos a Restitución",
            "r2_lvl1_match":"Sin derecho a devolución",
            "r3_match":"Sujetos a Restitución > Sin derecho a devolución",
            "r3_index":39,
            "length":FIELD_LENGTHS['R3']["Sujetos a Restitución > Sin derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Sujetos a Restitución",
            "r2_lvl1_match":"Con derecho a devolución",
            "r3_match":"Sujetos a Restitución > Con derecho a devolución",
            "r3_index":40,
            "length":FIELD_LENGTHS['R3']["Sujetos a Restitución > Con derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Sujetos a Restitución",
            "r2_lvl1_match":"Sin derecho a devolución.1",
            "r3_match":"Sujetos a Restitución > Sin derecho a devolución",
            "r3_index":43,
            "length":FIELD_LENGTHS['R3']["Sujetos a Restitución > Sin derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Sujetos a Restitución",
            "r2_lvl1_match":"Con derecho a devolución.1",
            "r3_match":"Sujetos a Restitución > Con derecho a devolución",
            "r3_index":44,
            "length":FIELD_LENGTHS['R3']["Sujetos a Restitución > Con derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Créditopor IPE",
            "r2_lvl1_match":"",
            "r3_match":"Créditopor IPE",
            "r3_index":45,
            "length":FIELD_LENGTHS['R3']["Créditopor IPE"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Asociados a rentas afectas",
            "r2_lvl1_match":"Sin derecho a devolución",
            "r3_match":"Asociados a rentas afectas > Sin derecho a devolución",
            "r3_index":48,
            "length":FIELD_LENGTHS['R3']["Asociados a rentas afectas > Sin derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Asociados a rentas afectas",
            "r2_lvl1_match":"Con derecho a devolución",
            "r3_match":"Asociados a rentas afectas > Con derecho a devolución",
            "r3_index":49,
            "length":FIELD_LENGTHS['R3']["Asociados a rentas afectas > Con derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Asociados a rentas exentas",
            "r2_lvl1_match":"Sin derecho a devolución",
            "r3_match":"Asociados a rentas exentas > Sin derecho a devolución",
            "r3_index":51,
            "length":FIELD_LENGTHS['R3']["Asociados a rentas exentas > Sin derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Asociados a rentas exentas",
            "r2_lvl1_match":"Con derecho a devolución",
            "r3_match":"Asociados a rentas exentas > Con derecho a devolución",
            "r3_index":52,
            "length":FIELD_LENGTHS['R3']["Asociados a rentas exentas > Con derecho a devolución"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Crédito por IPE",
            "r2_lvl1_match":"",
            "r3_match":"Crédito por IPE",
            "r3_index":53,
            "length":FIELD_LENGTHS['R3']["Crédito por IPE"]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Crédito por Impuesto Tasa Adicional ex. Art. 21 LIR.",
            "r2_lvl1_match":"",
            "r3_match":"Crédito por Impuesto Tasa Adicional ex. Art. 21 LIR.",
            "r3_index":54,
            "length":FIELD_LENGTHS['R3']["Crédito por Impuesto Tasa Adicional ex. Art. 21 LIR."]
        },
        {   "type":"sum",
            "r2_lvl0_match":"Devolución de Capital art.17 N° 7 LIR",
            "r2_lvl1_match":"",
            "r3_match":"Devolución de Capital art.17 N° 7 LIR",
            "r3_index":55,
            "length":FIELD_LENGTHS['R3']["Devolución de Capital art.17 N° 7 LIR"]
        },

    ]

    # 3) Procesar cada config
    for conf in config:
        total = 0.0
        if conf["type"] == "count":
            total = len(df_r2)
        else:
            lvl0 = conf.get("r2_lvl0_match","").lower()
            lvl1 = conf.get("r2_lvl1_match","").lower()
            for (c0, c1), serie in df_r2.iteritems():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    total += serie.astype(float).sum()

        # Formatear total
        text = str(int(total)) if float(total).is_integer() else str(total)
        length = conf.get("length", 0)
        if length:
            text = text.zfill(length)

        # Escribir en R3
        if "r3_index" in conf:
            df3.iat[conf["r3_index"], 2] = text
        else:
            row = label_to_row.get(conf["r3_match"].lower())
            if row is not None:
                df3.iat[row, 2] = text


def add_padding(lines):
    """
    Aplica los paddings finales para DJ 1949:
     - R0 (idx=0): +546 espacios
     - R1 (idx=1): inserta 6 espacios en pos 38 y +431 finales
     - R2 (2 <= idx < total-1): +59 espacios
     - R3 (última línea): sin cambios
    """
    padded = []
    total = len(lines)
    for idx, line in enumerate(lines):
        # Si trae '\n' al final, lo quitamos temporalmente
        nl = ''
        if line.endswith('\n'):
            line, nl = line[:-1], '\n'

        if idx == 0:
            # R0
            line = line.ljust(len(line) + 546)

        elif idx == 1:
            # R1: aseguramos al menos 38 chars, insertamos 6 spaces en pos 38
            line = line.ljust(38)
            line = line[:38] + ' ' * 6 + line[38:]
            # luego padding final de 431 espacios
            line = line.ljust(len(line) + 431)

        elif 2 <= idx < total - 1:
            # R2
            line = line.ljust(len(line) + 59)

        # R3 → sin cambios

        padded.append(line + nl)

    return padded

