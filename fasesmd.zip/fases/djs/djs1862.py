import pandas as pd
from tkinter import messagebox

NAME = "DJ 1862"
SHEET_KEYS = ['R0', 'R1', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',        # ← Ajusta estos nombres
    'R1': 'Registro1.1_Validacion',      #    según tus hojas de Excel
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
}

# -------------------------------------------------------------------
# Aquí vas rellenando una vez que sepas el largo de cada campo
# -------------------------------------------------------------------
FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT anterior > Número de RUT': 8,
        'RUT anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Codigo certificacion > Codigo empresa': 2,
        'Codigo certificacion > Número de clinete': 4,
        'Localización del docto. > Unidad': 5,
        'Localización del docto. > Número de caja': 3,
        'Localización del docto. > Número de paquete': 5,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Datos de la persona o entidad a nombre de quien se realiza la operación. > Nº de RUT': 8,
        'Datos de la persona o entidad a nombre de quien se realiza la operación. > Díg.verificador': 1,
        'Datos de la persona o entidad a nombre de quien se realiza la operación. > TAX - ID': 15,
        'Datos de la persona o entidad a nombre de quien se realiza la operación. > País otorgante del identificador': 3,
        'Datos de la persona o entidad a nombre de quien se realiza la operación. > Nombre o Razon Social': 30,
        'Código de Moneda': 4,
        'Monto en pesos': 15,
        'N° de transacción': 15,
        'Código Modalidad Operación': 2,
        'Código Concepto': 5,
        'Fecha de la Operación. > Día': 2,
        'Fecha de la Operación. > Mes': 2,
        'Fecha de la Operación. > Año': 4,
        'Datos de la contraparte en el exterior > Nombre o Razon Social': 30,
        'Datos de la contraparte en el exterior > Tax-ID': 15,
        'Datos de la contraparte en el exterior > Código País': 3,
        'Datos de la contraparte en el exterior > Banco': 30,
        'Localización del docto. > Unidad': 5,
        'Localización del docto. > Número de caja': 3,
        'Localización del docto. > Nº de paquete': 5,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Total de Casos Informados': 7,
        'Total de Ingresos Informados': 15,
        'Total de egresos Informados': 15,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}


def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames,
    e inyecta los campos faltantes en R1 y R3 para la DJ 1862.
    """
    dfs = {}
    # 1) Leer todas las hojas
    dfs['R0'] = pd.read_excel(path_excel,
                              sheet_name=SHEET_MAP['R0'],
                              header=None)
    dfs['R1'] = pd.read_excel(path_excel,
                              sheet_name=SHEET_MAP['R1'],
                              header=None)
    dfs['R2'] = (pd.read_excel(path_excel,
                               sheet_name=SHEET_MAP['R2'],
                               header=[0,1],
                               dtype=str)
                   .fillna(''))
    dfs['R3'] = pd.read_excel(path_excel,
                              sheet_name=SHEET_MAP['R3'],
                              header=None)

    # 2) DEBUG: asegúrate de que R1 y R3 ya existen
    print("Claves antes de ingresar_datos:", list(dfs.keys()))

    # 3) Inyectar filas forzadas sólo si faltan
    dfs = ingresar_datos(dfs)

    # 4) (opcional) imprimir índices/etiquetas
    for rec in ['R0','R1','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: índices y etiquetas ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val) or (hdr=='Folio anterior' and sub=='Cód.de presentación'):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(f"{i:3d}: {label}")

    # 5) imprimir R2 columnas
    df2 = dfs['R2']
    print("\n=== R2: índices de columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        lbl = lvl0 if str(lvl1).startswith("Unnamed") else f"{lvl0} > {lvl1}"
        print(f"{idx:3d}: {lbl}")

    return dfs



def ingresar_datos(dfs):
    """
    Para DJ 1862:
      - Inserta ‘Folio anterior > Cód.de presentación’ en R1 solo si NO existe
      - Inserta ‘Fecha de Presentación > mes’ en R3 solo si NO existe
    Ahora detectamos la etiqueta basándonos en header/subheader, 
    no en si val es NaN.
    """
    if NAME != "DJ 1862":
        return dfs

    # ——— R1 ———
    df1 = dfs['R1']

    # 1) Recolectar TODAS las etiquetas (hdr>sub) aunque su val esté vacío
    labels1 = []
    current = ''
    for i in range(1, len(df1)):
        hdr, sub = df1.iat[i,0], df1.iat[i,1]
        if pd.notna(hdr):
            current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        label = f"{current} > {sub_txt}" if sub_txt else current
        labels1.append(label.lower())

    # 2) Solo insertamos si NO está ya esa etiqueta
    forced1 = 'folio anterior > cód.de presentación'
    if forced1 not in labels1:
        # buscamos la fila de referencia 'folio anterior > nº folio'
        target1 = 'folio anterior > nº folio'
        idx1 = next((i for i, lab in enumerate(labels1, start=1) if lab == target1), None)
        if idx1 is not None:
            new_row1 = pd.Series({0: 'Folio anterior', 1: 'Cód.de presentación', 2: ''})
            df1 = pd.concat([
                df1.iloc[:idx1],
                new_row1.to_frame().T,
                df1.iloc[idx1:]
            ], ignore_index=True)
            dfs['R1'] = df1
        else:
            messagebox.showwarning(
                "DJ 1862",
                f"No encontré '{target1}' en R1. Omitiendo inserción de '{forced1}'."
            )

    # ——— R3 ———
    df3 = dfs['R3']
    labels3 = []
    current = ''
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        if pd.notna(hdr):
            current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        label = f"{current} > {sub_txt}" if sub_txt else current
        labels3.append(label.lower())

    forced3 = 'fecha de presentación > mes'
    if forced3 not in labels3:
        target3 = 'fecha de presentación > año'
        idx3 = next((i for i, lab in enumerate(labels3, start=1) if lab == target3), None)
        if idx3 is not None:
            new_row3 = pd.Series({0: 'Fecha de Presentación', 1: 'mes', 2: ''})
            df3 = pd.concat([
                df3.iloc[:idx3],
                new_row3.to_frame().T,
                df3.iloc[idx3:]
            ], ignore_index=True)
            dfs['R3'] = df3
        else:
            messagebox.showwarning(
                "DJ 1862",
                f"No encontré '{target3}' en R3. Omitiendo inserción de '{forced3}'."
            )

    return dfs



def print_fields(dfs):
    """
    Imprime en consola todos los labels de R0, R1, R2 y R3
    para ayudarte a poblar FIELD_LENGTHS.
    """
    # — R0, R1 y R3 (verticales de tres columnas) —
    for rec in ['R0','R1','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: campos ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(label)

    # — R2 (multi-índice) —
    df2 = dfs['R2']
    print("\n=== R2: columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        label = f"{lvl0} > {lvl1}" if not str(lvl1).startswith("Unnamed") else str(lvl0)
        print(f"{idx:3d}: {label}")

def _get_val_vertical(df, label):
    """Busca en df (tres columnas) el valor cuya etiqueta ensamblada == label."""
    current = ''
    for i in range(len(df)):
        hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        if pd.notna(val):
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return str(val)
    return ''

def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera las líneas de texto [R0_line, R1_line, *R2_rows, R3_line].
    Usa FIELD_LENGTHS para hacer padding:
      - Por defecto: ceros a la izquierda (txt.zfill)
      - Excepciones: espacios a la izquierda (.rjust) o derecha (.ljust)
    
    CORREGIDO: Ahora procesa TODOS los campos definidos en FIELD_LENGTHS,
    no solo los que tienen valores, para mantener las longitudes correctas.
    """

    # — reglas específicas —
    right_space_R1 = {
        'Folio anterior > Cód.de presentación',
        'Razón Social o Nombre',
        'Dirección Postal',
    }
    left_space_R1 = {
        'Correo Electrónico',
    }

    right_space_R2 = {
        'Razón Social o Nombre',
        'Dirección Postal',
        'Comuna',
    }
    left_space_R2 = {
        'Correo Electrónico',
        'Datos de la persona o entidad a nombre de quien se realiza la operación. > TAX - ID',
        'Datos de la persona o entidad a nombre de quien se realiza la operación. > Nombre o Razon Social',
        'Datos de la contraparte en el exterior > Nombre o Razon Social',
        'Datos de la contraparte en el exterior > Tax-ID',
        'Datos de la contraparte en el exterior > Banco',
    }

    left_space_R3 = {
        'Fecha de Presentación > mes',
    }

    lines = []

    # --- R0 ---
    df0 = dfs['R0']
    parts0 = []
    
    # Procesamos TODOS los campos definidos en FIELD_LENGTHS['R0']
    for field_name in FIELD_LENGTHS['R0'].keys():
        # Buscar el valor en el DataFrame
        txt = _get_val_vertical(df0, field_name)
        length = FIELD_LENGTHS['R0'][field_name]
        parts0.append(txt.zfill(length) if length else txt)
    
    lines.append(''.join(parts0))

    # --- R1 ---
    df1 = dfs['R1']
    parts1 = []
    
    # Procesamos TODOS los campos definidos en FIELD_LENGTHS['R1']
    for field_name in FIELD_LENGTHS['R1'].keys():
        # Buscar el valor en el DataFrame
        txt = _get_val_vertical(df1, field_name)
        length = FIELD_LENGTHS['R1'][field_name]

        if txt:
            if field_name in right_space_R1:
                txt = txt.ljust(length)
            elif field_name in left_space_R1:
                txt = txt.rjust(length)
            else:
                txt = txt.zfill(length)
        else:
            # Campo vacío: aplicar padding según reglas
            if field_name in right_space_R1 or field_name in left_space_R1:
                txt = ' ' * length
            else:
                txt = '0' * length

        parts1.append(txt)
    
    lines.append(''.join(parts1))

    # --- R2 (fila a fila) ---
    df2_clean = df_r2.loc[~(df_r2 == '').all(axis=1)]
    for _, row in df2_clean.iterrows():
        parts2 = []
        
        # Procesamos TODOS los campos definidos en FIELD_LENGTHS['R2']
        for field_name in FIELD_LENGTHS['R2'].keys():
            # Buscar el valor en la fila actual
            txt = ''
            for (lvl0, lvl1), raw_v in zip(df_r2.columns, row.values):
                hdr = str(lvl0).strip()
                sub = str(lvl1).strip()
                label = hdr if sub.startswith("Unnamed") else f"{hdr} > {sub}"
                
                if label == field_name:
                    txt = str(raw_v).strip() if pd.notna(raw_v) else ''
                    break
            
            length = FIELD_LENGTHS['R2'][field_name]

            if txt:
                if field_name in right_space_R2:
                    txt = txt.ljust(length)
                elif field_name in left_space_R2:
                    txt = txt.rjust(length)
                else:
                    txt = txt.zfill(length)
            else:
                # Campo vacío: aplicar padding según reglas
                if field_name in right_space_R2 or field_name in left_space_R2:
                    txt = ' ' * length
                else:
                    txt = '0' * length

            parts2.append(txt)
        
        lines.append(''.join(parts2))

    # --- R3: primero volcamos totales desde R2 ---
    update_r3_from_r2(dfs, df_r2)

    # --- R3: formateo final ---
    df3 = dfs['R3']
    parts3 = []
    
    # Procesamos TODOS los campos definidos en FIELD_LENGTHS['R3']
    for field_name in FIELD_LENGTHS['R3'].keys():
        # Buscar el valor en el DataFrame
        txt = _get_val_vertical(df3, field_name)
        length = FIELD_LENGTHS['R3'][field_name]

        if txt:
            txt = txt.zfill(length)
        else:
            # Campo vacío: aplicar padding según reglas
            txt = ' ' * length if field_name in left_space_R3 else '0' * length

        parts3.append(txt)

    lines.append(''.join(parts3))
    return lines

def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2.
    Para DJ 1862 aplica reglas especiales:
      - Código Concepto 11260 → suma Monto en pesos a 'Total de Ingresos Informados'
      - Código Concepto 21260 → suma Monto en pesos a 'Total de egresos Informados'
      - Cuenta todas las filas para 'Total de Casos Informados'
    Para las demás DJ usa la lógica genérica con `config`.
    """
    df3 = dfs['R3']

    # 1) Construir mapa label→fila en R3
    label_to_row = {}
    for i in range(1, len(df3)):
        raw_hdr = df3.iat[i,0]
        raw_sub = df3.iat[i,1]
        hdr_txt = str(raw_hdr).strip()
        sub_txt = str(raw_sub).strip() if pd.notna(raw_sub) else ''
        key = (f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt).lower()
        label_to_row[key] = i

    # 2) Lógica PARTICULAR para DJ 1862
    if NAME == "DJ 1862":
        # 2.1) Localizar las columnas multi-índice en df_r2
        monto_col    = next(col for col in df_r2.columns if col[0] == "Monto en pesos")
        concepto_col = next(col for col in df_r2.columns if col[0] == "Código Concepto")

        # 2.2) Convertir tipos
        series_monto    = df_r2[monto_col].astype(float)
        series_concepto = df_r2[concepto_col].astype(str)

        # 2.3) Calcular totales
        total_casos = len(df_r2)
        total_ing   = series_monto[ series_concepto == "11260" ].sum()
        total_eg    = series_monto[ series_concepto == "21260" ].sum()

        # 2.4) Dar formato y escribir en R3
        rows_and_vals = {
            "total de casos informados"    : total_casos,
            "total de ingresos informados" : total_ing,
            "total de egresos informados"  : total_eg,
        }
        for label_lower, val in rows_and_vals.items():
            row_idx = label_to_row.get(label_lower)
            if row_idx is None:
                continue

            # formatear valor
            text = str(int(val)) if float(val).is_integer() else str(val)

            # buscar la clave exacta en FIELD_LENGTHS['R3']
            real_key = next(
                (k for k in FIELD_LENGTHS['R3'].keys() if k.lower() == label_lower),
                None
            )
            if real_key:
                length = FIELD_LENGTHS['R3'][real_key]
                if length:
                    text = text.zfill(length)

            df3.iat[row_idx, 2] = text

        return  # salir tras la lógica especial

    # 3) LÓGICA GENÉRICA para otras DJ
    config = [
        {
          "type": "count",
          "r3_match": "Total de Casos Informados",
          "r3_index": 11,
          "length": FIELD_LENGTHS['R3']["Total de Casos Informados"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto en pesos",
          "r2_lvl1_match":"",
          "r3_match":"Total de Ingresos Informados",
          "r3_index":12,
          "length":FIELD_LENGTHS['R3']["Total de Ingresos Informados"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto en pesos",
          "r2_lvl1_match":"",
          "r3_match":"Total de egresos Informados",
          "r3_index":13,
          "length":FIELD_LENGTHS['R3']["Total de egresos Informados"]
        },
    ]

    # 4) Procesar cada config
    for conf in config:
        total = 0.0
        if conf["type"] == "count":
            total = len(df_r2)
        else:
            lvl0 = conf.get("r2_lvl0_match","").lower()
            lvl1 = conf.get("r2_lvl1_match","").lower()
            for (c0, c1), serie in df_r2.iteritems():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    total += serie.astype(float).sum()

        text = str(int(total)) if float(total).is_integer() else str(total)

        # buscar la clave exacta en FIELD_LENGTHS['R3'] para conf["r3_match"]
        match_lower = conf["r3_match"].lower()
        real_key = next(
            (k for k in FIELD_LENGTHS['R3'].keys() if k.lower() == match_lower),
            None
        )
        length = FIELD_LENGTHS['R3'][real_key] if real_key else 0
        if length:
            text = text.zfill(length)

        # escribir en R3
        if "r3_index" in conf:
            df3.iat[conf["r3_index"], 2] = text
        else:
            row = label_to_row.get(match_lower)
            if row is not None:
                df3.iat[row, 2] = text

def add_padding(lines):
    """
    Aplica padding final e inserciones específicas a la salida
    según las reglas de la DJ 1949:
      - R0 (idx=0): +134 espacios al final
      - R1 (idx=1): inserción de 6 espacios en pos 36, de 1 espacio en pos 184, +1 final
      - R2 (2 <= idx < total-1): sin cambios
      - R3 (idx == total-1): +142 espacios al final
    """
    padded = []
    total = len(lines)

    for idx, line in enumerate(lines):
        if idx == 0:
            # R0
            new_line = line.ljust(len(line) + 134)

        elif idx == 1:
            # R1
            # 1) Asegurar al menos 36 chars
            new_line = line.ljust(36)
            # 2) Insertar 6 espacios en pos 36
            new_line = new_line[:36] + ' ' * 6 + new_line[36:]
            # 3) Insertar 1 espacio en pos 184
            insert_pos = 183
            new_line = new_line.ljust(insert_pos)
            new_line = new_line[:insert_pos] + ' ' + new_line[insert_pos:]
            # 4) padding final de 1 espacio
            new_line = new_line.ljust(len(new_line) + 17)

        elif idx == total - 1:
            # R3: +142 espacios
            new_line = line.ljust(len(line) + 142)

        else:
            # R2: sin modificaciones
            new_line = line

        padded.append(new_line)

    return padded
