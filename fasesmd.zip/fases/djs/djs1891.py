import pandas as pd
from tkinter import messagebox

NAME = "DJ 1891"
SHEET_KEYS = ['R0', 'R1', 'R1.2', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R1.2': 'Registro1.2_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3_Validacion',
}

# -------------------------------------------------------------------
# FIELD_LENGTHS para DJ 1891 (rellenar los valores según correspondan)
# -------------------------------------------------------------------
FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora > Hora': 2,
        'Hora > Minuto': 2,
        'Hora > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
    },
    'R1.2': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Caja > Unidad': 5,
        'Caja > Número de caja': 3,
        'Número de paquete': 5,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Tipo de Documento': 1,
        'Número de Documento': 10,
        'Fecha del Documento': 8,
        'Rut emisor de acciones > Nº de RUT': 8,
        'Rut emisor de acciones > Díg.verificador': 1,
        'Nemotécnico': 50,
        'Rut del operante > Nº de RUT': 8,
        'Rut del operante > Díg.verificador': 1,
        'Numero de acciones': 20,
        'Monto Total > Compras': 15,
        'Monto Total > Ventas': 15,
        'Valor de Adquisición': 15,
        'Tipo de Transacción': 2,
    },
    'R3': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Monto Total > Compras': 18,
        'Monto Total > Ventas': 18,
        'Total de Casos Informados': 7,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}


def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con multi-índice y dtype=str para preservar ceros.
    Inyecta en R1 y R3 los campos forzados si faltan.
    """
    dfs = {}
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R1.2'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1.2'], header=None)
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)

    # Inyectar filas forzadas en R1 y R3 si faltan
    dfs = ingresar_datos(dfs)
    # — Ahora imprimimos los índices y etiquetas de R0, R1, R1.2 y R3 —
    for rec in ['R0','R1','R1.2','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: índices y etiquetas ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(f"{i:3d}: {label}")

    # — Imprimimos R2: nivel0 y nivel1 de cada columna con su índice —
    df2 = dfs['R2']
    print("\n=== R2: índices de columnas (lvl0, lvl1) ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        if str(lvl1).startswith("Unnamed"):
            print(f"{idx:3d}: {lvl0}")
        else:
            print(f"{idx:3d}: {lvl0} > {lvl1}")


    return dfs


def ingresar_datos(dfs):
    """
    Para DJ 1891:
      - Inserta 'Folio anterior > Cód.de presentación' antes de 'Folio anterior > Nº folio' en R1 si falta
      - Inserta 'Fecha de Presentación > mes' antes de 'Fecha de Presentación > año' en R3 si falta
    """
    if NAME != "DJ 1891":
        return dfs

    # R1
    df1 = dfs['R1']
    labels1 = []
    current = ''
    for i in range(1, len(df1)):
        hdr, sub = df1.iat[i,0], df1.iat[i,1]
        if pd.notna(hdr): current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        labels1.append((i, (f"{current} > {sub_txt}" if sub_txt else current).lower()))
    if not any(lab == 'folio anterior > cód.de presentación' for _, lab in labels1):
        idx = next((i for i, lab in labels1 if lab == 'folio anterior > nº folio'), None)
        if idx is not None:
            new = pd.Series({0: 'Folio anterior', 1: 'Cód.de presentación', 2: ''})
            dfs['R1'] = pd.concat([df1.iloc[:idx], new.to_frame().T, df1.iloc[idx:]], ignore_index=True)
        else:
            messagebox.showwarning(NAME, "No encontré 'Folio anterior > Nº folio' en R1.")

    # R3
    df3 = dfs['R3']
    labels3 = []
    current = ''
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        if pd.notna(hdr): current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        labels3.append((i, (f"{current} > {sub_txt}" if sub_txt else current).lower()))
    if not any(lab == 'fecha de presentación > mes' for _, lab in labels3):
        idx = next((i for i, lab in labels3 if lab == 'fecha de presentación > año'), None)
        if idx is not None:
            new = pd.Series({0: 'Fecha de Presentación', 1: 'mes', 2: ''})
            dfs['R3'] = pd.concat([df3.iloc[:idx], new.to_frame().T, df3.iloc[idx:]], ignore_index=True)
        else:
            messagebox.showwarning(NAME, "No encontré 'Fecha de Presentación > año' en R3.")

    return dfs


def print_fields(dfs):
    """
    Para depurar: imprime índices y etiquetas de R0,R1,R1.2,R2,R3.
    """
    for rec in ['R0','R1','R1.2','R3']:
        df = dfs[rec]
        print(f"=== {rec}: índices y etiquetas ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr): current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(f"{i:3d}: {label}")

    print("=== R2: columnas ===")
    for idx, (lvl0, lvl1) in enumerate(dfs['R2'].columns):
        lbl = lvl0 if str(lvl1).startswith('Unnamed') else f"{lvl0} > {lvl1}"
        print(f"{idx:3d}: {lbl}")


def _get_val_vertical(df, label):
    """
    Busca en df (3 col) la celda cuyo header>subheader == label y devuelve el val.
    """
    current = ''
    for i in range(1, len(df)):
        hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
        if pd.notna(hdr): current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        lab = f"{current} > {sub_txt}" if sub_txt else current
        if lab == label:
            return '' if pd.isna(val) else str(val).strip()
    return ''


def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera las líneas de texto [R0, R1, R1.2, *R2_rows, R3] para DJ 1891,
    aplicando ceros a la izquierda por defecto, y espacios cuando la etiqueta
    esté en right_space_* o left_space_*, sin descartar nunca esas filas.
    """

    import pandas as pd

    # — Helper para extraer valor verticalmente en DF de tres columnas —
    def _get_val_vertical(df, label):
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i, 0], df.iat[i, 1], df.iat[i, 2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return '' if pd.isna(val) else str(val).strip()
        return ''

    lines = []

    # — reglas de espacios para DJ 1891 —
    right_space_R1   = {'Razón Social o Nombre','Dirección Postal','Comuna',
        # p.ej. 'Folio anterior > Cód.de presentación',
    }
    left_space_R1    = {'Correo Electrónico',
        # p.ej. 'Razón Social o Nombre', 'Dirección Postal', ...
    }
    right_space_R12  = {
        # campos de R1.2 a la derecha
    }
    left_space_R12   = {
        # campos de R1.2 a la izquierda
    }
    # si necesitas excepciones en R2, las defines aquí:
    right_space_R2   = {'Nemotécnico',}
    left_space_R2    = set()

    left_space_R3    = {
        # p.ej. 'Fecha de Presentación > mes',
    }

    # --- R0 ---
    df0 = dfs['R0']
    parts0 = []
    for field_name, length in FIELD_LENGTHS['R0'].items():
        txt = _get_val_vertical(df0, field_name)
        if txt:
            parts0.append(txt.zfill(length))
        else:
            parts0.append('0' * length)
    lines.append(''.join(parts0))

    # --- R1 ---
    df1 = dfs['R1']
    parts1 = []
    for field_name, length in FIELD_LENGTHS['R1'].items():
        txt = _get_val_vertical(df1, field_name)
        if txt:
            if field_name in right_space_R1:
                txt = txt.ljust(length)
            elif field_name in left_space_R1:
                txt = txt.rjust(length)
            else:
                txt = txt.zfill(length)
        else:
            if field_name in right_space_R1 or field_name in left_space_R1:
                txt = ' ' * length
            else:
                txt = '0' * length
        parts1.append(txt)
    lines.append(''.join(parts1))

    # --- R1.2 ---
    df12 = dfs['R1.2']
    parts12 = []
    for field_name, length in FIELD_LENGTHS['R1.2'].items():
        txt = _get_val_vertical(df12, field_name)
        if txt:
            if field_name in right_space_R12:
                txt = txt.ljust(length)
            elif field_name in left_space_R12:
                txt = txt.rjust(length)
            else:
                txt = txt.zfill(length)
        else:
            if field_name in right_space_R12 or field_name in left_space_R12:
                txt = ' ' * length
            else:
                txt = '0' * length
        parts12.append(txt)
    lines.append(''.join(parts12))

    # --- R2 (fila a fila) ---
    df2_clean = df_r2.loc[~(df_r2 == '').all(axis=1)]
    for _, row in df2_clean.iterrows():
        parts2 = []
        for (lvl0, lvl1), raw_v in zip(df_r2.columns, row.values):
            hdr = str(lvl0).strip()
            sub = str(lvl1).strip()
            label = hdr if sub.startswith("Unnamed") else f"{hdr} > {sub}"
            length = FIELD_LENGTHS['R2'].get(label, 0)
            txt = str(raw_v).strip() if pd.notna(raw_v) else ''
            if txt:
                if label in right_space_R2:
                    txt = txt.ljust(length)
                elif label in left_space_R2:
                    txt = txt.rjust(length)
                else:
                    txt = txt.zfill(length)
            else:
                txt = ' ' * length if label in right_space_R2|left_space_R2 else '0'*length
            parts2.append(txt)
        lines.append(''.join(parts2))

    # --- actualizar R3 desde R2 ---
    update_r3_from_r2(dfs, df_r2)

    # --- R3 ---
    df3 = dfs['R3']
    parts3 = []
    for field_name, length in FIELD_LENGTHS['R3'].items():
        txt = _get_val_vertical(df3, field_name)
        if txt:
            txt = txt.zfill(length)
        else:
            if field_name in left_space_R3:
                txt = ' ' * length
            else:
                txt = '0' * length
        parts3.append(txt)
    lines.append(''.join(parts3))

    return lines



def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2 con count/sum según tu config.
    """
    df3 = dfs['R3']

    # 1) Construir mapa label→fila en R3 para los casos que no usen r3_index
    label_to_row = {}
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        hdr_txt = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        key = (f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt).lower()
        label_to_row[key] = i

    # 2) Tu config (no la tocamos)
    config = [
        {
          "type": "count",
          "r3_match": "Total de Casos Informados",
          "r3_index": 11,
          "length": FIELD_LENGTHS['R3']["Total de Casos Informados"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto Total",
          "r2_lvl1_match":"Compras",
          "r3_match":"Monto Total > Compras",
          "r3_index":9,
          "length":FIELD_LENGTHS['R3']["Monto Total > Compras"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto Total",
          "r2_lvl1_match":"Ventas",
          "r3_match":"Monto Total > Ventas",
          "r3_index":10,
          "length":FIELD_LENGTHS['R3']["Monto Total > Ventas"]
        },
    ]

    # 3) Procesar cada entrada de config
    for conf in config:
        # a) calcular total
        if conf["type"] == "count":
            total = len(df_r2)
        else:
            total = 0.0
            lvl0 = conf["r2_lvl0_match"].lower()
            lvl1 = conf["r2_lvl1_match"].lower()
            # df_r2.items() itera ( (lvl0, lvl1), Series )
            for (c0, c1), serie in df_r2.items():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    # aseguramos que sean numéricos
                    total += serie.astype(float).sum()

        # b) formatear según length
        text = str(int(total)) if float(total).is_integer() else str(total)
        if conf.get("length"):
            text = text.zfill(conf["length"])

        # c) volcar al DataFrame R3
        # si se indicó índice explícito, lo usamos
        if "r3_index" in conf and conf["r3_index"] is not None:
            df3.iat[conf["r3_index"], 2] = text
        else:
            # fallback: buscar por etiqueta
            row = label_to_row.get(conf["r3_match"].lower())
            if row is not None:
                df3.iat[row, 2] = text

def add_padding(lines):
    """
    Aplica padding final e inserciones específicas a la salida
    según las reglas de la DJ 1891:
      - R0 (idx=0): +91 espacios al final
      - R1 (idx=1): insertar 6 espacios en pos 36 y +16 espacios al final
      - R1.2 (idx=2): insertar 1 espacio en pos 25 y +133 espacios al final
      - R2 (filas intermedias): sin cambios
      - R3 (idx == total-1): +94 espacios al final
    """
    padded = []
    total = len(lines)

    for idx, line in enumerate(lines):
        if idx == 0:
            # R0
            line = line.ljust(len(line) + 91)

        elif idx == 1:
            # R1
            # 1) Asegurar al menos 36 caracteres
            new_line = line.ljust(36)
            # 2) Insertar 6 espacios en pos 36
            new_line = new_line[:36] + ' ' * 6 + new_line[36:]
            # 3) Padding final de 16 espacios
            line = new_line.ljust(len(new_line) + 16)

        elif idx == 2:
            # R1.2
            # 1) Asegurar al menos 25 caracteres
            new_line = line.ljust(25)
            # 2) Insertar 1 espacio en pos 25
            new_line = new_line[:25] + ' ' + new_line[25:]
            # 3) Padding final de 133 espacios
            line = new_line.ljust(len(new_line) + 133)

        elif idx == total - 1:
            # R3
            line = line.ljust(len(line) + 94)

        else:
            # R2 (filas intermedias): sin modificaciones
            pass

        padded.append(line)

    return padded
