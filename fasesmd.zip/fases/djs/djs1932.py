import pandas as pd

NAME = "DJ 1932"
SHEET_KEYS = ['R0', 'R1', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
}
FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Número de RUT': 8,
        'Número de RUT > Dígito verificador': 1,
        'Número de RUT > Total de Registros a transmitir': 10,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 6,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Calidad del Declarante': 1,
        'Localización del docto. > Unidad': 5,
        'Localización del docto. > Número de caja': 3,
        'Localización del docto. > Número de paquete': 5,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Casos Informados': 10,
        'Total Monto Depósitos, Inversiones o préstamos': 18,
        'Total Monto Rescates o Devoluciones': 18,
        'Total Rentas Percibidas > Intereses': 18,
        'Total Rentas Percibidas > Dividendos': 18,
        'Total Rentas Percibidas > Contratos por Diferencias': 18,
        'Total Rentas Percibidas > Otras Rentas': 18,
        'Total Rentas Devengadas > Intereses': 18,
        'Total Rentas Devengadas > Otras Rentas': 18,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Mes': 2,
        'Antecedentes de los depositantes, inversionistas, prestamistas o receptores de la renta > Número de RUT': 8,
        'Antecedentes de los depositantes, inversionistas, prestamistas o receptores de la renta > Dígito verificador': 1,
        'Antecedentes de los depositantes, inversionistas, prestamistas o receptores de la renta > TAX-ID del depositante, inversionista, prestamista o receptor de la renta': 15,
        'Antecedentes de los depositantes, inversionistas, prestamistas o receptores de la renta > País': 2,
        'Monto de las operaciones > Depósitos, inversiones o préstamos': 15,
        'Monto de las operaciones > Rescates o devoluciones': 15,
        'Percibidas > Intereses': 15,
        'Percibidas > Dividendos': 15,
        'Percibidas > Contratos por Diferencias': 15,
        'Percibidas > Otras Rentas': 15,
        'Devengadas > Intereses': 15,
        'Devengadas > Otras Rentas': 15,
        'Fuente (País) de la Renta': 3,
    },
}


def print_fields(dfs):
    """
    Imprime en consola todos los labels de R0, R1, R2 y R3
    para ayudarte a definir FIELD_LENGTHS.
    """
    # — R0, R1 y R3 (verticales de tres columnas) —**
    for rec in ['R0','R1','R3']:
        df = dfs[rec]
        print(f"=== {rec}: campos ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(label)
    # — R2 (multi‐índice) —**
    df2 = dfs['R2']
    print("=== R2: columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        label = f"{lvl0} > {lvl1}" if not str(lvl1).startswith("Unnamed") else str(lvl0)
        print(f"{idx:3d}: {label}")


def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con header=[0,1] y dtype=str para preservar ceros.
    """
    # 1) Inicializo el dict antes de usarlo
    dfs = {}

    # 2) Cargo cada hoja
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    df2 = dfs['R2']
    print("=== R2: índices de columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        if str(lvl1).startswith("Unnamed"):
            print(f"{idx:3d}: {lvl0}")
        else:
            print(f"{idx:3d}: {lvl0} > {lvl1}")
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)

    # 3) Imprimo índices de R3 para configurar tu update_r3_from_r2
    df3 = dfs['R3']
    print("=== R3: índices de filas ===")
    for i in range(1, len(df3)):
        hdr = str(df3.iat[i, 0]).strip()
        sub = df3.iat[i, 1]
        if pd.isna(sub) or not str(sub).strip():
            label = hdr
        else:
            label = f"{hdr} > {str(sub).strip()}"
        print(f"{i:3d}: {label}")

    # 4) (Opcional) Imprime TODOS los labels de R0, R1 y R3
    #    para que armes tu FIELD_LENGTHS de golpe.
    print_fields(dfs)

    return dfs


def print_fields(dfs):
    """
    Lista en consola todos los labels de R0, R1 y R3
    para que puedas copiar/pegar y rellenar tu FIELD_LENGTHS.
    """
    # — R0 —
    print("=== R0: campos ===")
    df0 = dfs['R0']
    current = ''
    for i in range(1, len(df0)):
        hdr, sub, val = df0.iat[i,0], df0.iat[i,1], df0.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        if pd.notna(val):
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            label = f"{current} > {sub_txt}" if sub_txt else current
            print(label)

    # — R1 —
    print("\n=== R1: campos ===")
    df1 = dfs['R1']
    current = ''
    for i in range(1, len(df1)):
        hdr, sub, val = df1.iat[i,0], df1.iat[i,1], df1.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        if pd.notna(val):
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            label = f"{current} > {sub_txt}" if sub_txt else current
            print(label)

    # — R3 —
    print("\n=== R3: campos ===")
    df3 = dfs['R3']
    current = ''
    for i in range(1, len(df3)):
        hdr, sub, val = df3.iat[i,0], df3.iat[i,1], df3.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        if pd.notna(val):
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            label = f"{current} > {sub_txt}" if sub_txt else current
            print(label)


def _get_val_vertical(df, label):
    """Busca en df (tres columnas) el valor cuya etiqueta ensamblada == label."""
    current = ''
    for i in range(len(df)):
        hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        if pd.notna(val):
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return str(val)
    return ''

def generar_lines_en_memoria(dfs, df_r2):
    import pandas as pd

    lines = []

    # — R0 —
    df0 = dfs['R0']
    parts0 = []
    for i in range(1, len(df0)):
        hdr, sub, val = df0.iat[i,0], df0.iat[i,1], df0.iat[i,2]
        if pd.isna(val) or str(val).strip() == "":
            continue

        # Convertir siempre a str antes de strip()
        hdr_txt = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ""
        label = f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt

        txt = str(val).strip()
        length = FIELD_LENGTHS['R0'].get(label)
        if length:
            txt = txt.zfill(int(length))
        parts0.append(txt)
    lines.append(''.join(parts0))

    # — R1 —
    df1 = dfs['R1']
    parts1 = []
    for i in range(1, len(df1)):
        hdr, sub, val = df1.iat[i,0], df1.iat[i,1], df1.iat[i,2]
        if pd.isna(val) or str(val).strip() == "":
            continue

        hdr_txt = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ""
        label = f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt

        txt = str(val).strip()
        length = FIELD_LENGTHS['R1'].get(label)
        if length:
            txt = txt.zfill(int(length))
        parts1.append(txt)
    lines.append(''.join(parts1))

    # — R2 — (fila por fila, multi-índice)
    df2 = df_r2.dropna(how='all')
    for _, row in df2.iterrows():
        parts2 = []
        for (lvl0, lvl1), v in zip(df2.columns, row.values):
            txt = str(v).strip() if pd.notna(v) else ""

            lvl0_txt = str(lvl0).strip()
            lvl1_txt = str(lvl1).strip()
            if lvl1_txt.startswith("Unnamed"):
                label = lvl0_txt
            else:
                label = f"{lvl0_txt} > {lvl1_txt}"

            length = FIELD_LENGTHS['R2'].get(label)
            if length:
                if label == (
                    "Antecedentes de los depositantes, inversionistas, "
                    "prestamistas o receptores de la renta > "
                    "TAX-ID del depositante, inversionista, prestamista o receptor de la renta"
                ):
                    # para este campo, espacios a la izquierda
                    txt = txt.rjust(int(length))
                else:
                    # para todos los demás, ceros a la izquierda
                    txt = txt.zfill(int(length))
            parts2.append(txt)
        lines.append(''.join(parts2))

    # — R3 —
    df3 = dfs['R3']
    parts3 = []
    for i in range(1, len(df3)):
        hdr, sub, val = df3.iat[i,0], df3.iat[i,1], df3.iat[i,2]
        if pd.isna(val) or str(val).strip() == "":
            continue

        hdr_txt = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ""
        label = f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt

        txt = str(val).strip()
        length = FIELD_LENGTHS['R3'].get(label)
        if length:
            txt = txt.zfill(int(length))
        parts3.append(txt)
    lines.append(''.join(parts3))

    return lines

def update_r3_from_r2(dfs, df_r2):
    """
    Rellena los campos de R3 a partir de los datos de R2 según la lista de config.
    Cada config debe llevar:
      - "type": "count" o "sum"
      - para sum: "r2_lvl0_match", "r2_lvl1_match" (puede estar vacío)
      - "r3_match": etiqueta exacta en R3
      - opcionalmente "r3_index": índice de fila en R3 si ya lo tienes
      - opcionalmente "length": FIELD_LENGTHS['R3'][r3_match]
    """
    df3 = dfs['R3']

    # 1) Mapeo etiqueta→fila en R3
    label_to_row = {}
    for i in range(1, len(df3)):
        hdr_txt = str(df3.iat[i,0]).strip()
        sub_txt = str(df3.iat[i,1]).strip()
        if sub_txt:
            label = f"{hdr_txt} > {sub_txt}"
        else:
            label = hdr_txt
        label_to_row[label.lower()] = i

    # 2) Definición de config (rellena tus 9 casos aquí)
    config = [
        # ejemplo 1: contar filas
        {
            "type":     "count",
            "r3_match": "Total de Casos Informados",
            "r3_index": 11,          # si ya conoces el índice
            "length":    FIELD_LENGTHS['R3']["Total de Casos Informados"],
        },
        # ejemplo 2: sumar un campo concreto
        {
            "type":           "sum",
            "r2_lvl0_match":  "Monto de las operaciones",
            "r2_lvl1_match":  "Depósitos, inversiones o préstamos",
            "r3_match":       "Total Monto Depósitos, Inversiones o préstamos",
            "r3_index":       12,
            "length":         FIELD_LENGTHS['R3'][ "Total Monto Depósitos, Inversiones o préstamos" ],
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Monto de las operaciones",
            "r2_lvl1_match":  "Rescates o devoluciones",
            "r3_match":       "Total Monto Rescates o Devoluciones",
            "r3_index":       13,
            "length":         FIELD_LENGTHS['R3'][ "Total Monto Rescates o Devoluciones" ],
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Percibidas",
            "r2_lvl1_match":  "Intereses",
            "r3_match":       "Total Rentas Percibidas > Intereses" ,
            "r3_index":       15,
            "length":         FIELD_LENGTHS['R3'][ "Total Rentas Percibidas > Intereses" ],
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Percibidas",
            "r2_lvl1_match":  "Dividendos",
            "r3_match":       "Total Rentas Percibidas > Dividendos",
            "r3_index":       16,
            "length":         FIELD_LENGTHS['R3'][ "Total Rentas Percibidas > Dividendos" ],
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Percibidas",
            "r2_lvl1_match":  "Contratos por Diferencias",
            "r3_match":       "Total Rentas Percibidas > Contratos por Diferencias",
            "r3_index":       17,
            "length":         FIELD_LENGTHS['R3'][ "Total Rentas Percibidas > Contratos por Diferencias" ],
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Percibidas",
            "r2_lvl1_match":  "Otras Rentas",
            "r3_match":       "Total Rentas Percibidas > Otras Rentas",
            "r3_index":       18,
            "length":         FIELD_LENGTHS['R3'][ "Total Rentas Percibidas > Otras Rentas" ],
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Devengadas",
            "r2_lvl1_match":  "Intereses",
            "r3_match":       "Total Rentas Devengadas > Intereses",
            "r3_index":       20,
            "length":         FIELD_LENGTHS['R3'][ "Total Rentas Devengadas > Intereses" ],
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Devengadas",
            "r2_lvl1_match":  "Otras Rentas",
            "r3_match":       "Total Rentas Devengadas > Otras Rentas",
            "r3_index":       21,
            "length":         FIELD_LENGTHS['R3'][ "Total Rentas Devengadas > Otras Rentas" ],
        },
  ]

    # 3) Procesar cada config
    for conf in config:
        total = 0.0
        matched = False

        if conf["type"] == "count":
            total = len(df_r2)
            matched = True
        else:
            lvl0_key = conf.get("r2_lvl0_match", "").lower()
            lvl1_key = conf.get("r2_lvl1_match", "").lower()
            # recorrer columnas de df_r2
            for (lvl0, lvl1), series in df_r2.iteritems():
                if lvl0_key in str(lvl0).lower() and (not lvl1_key or lvl1_key in str(lvl1).lower()):
                    matched = True
                    total += series.astype(float).sum()
            if not matched:
                continue

        # 4) Formatear texto
        text = str(int(total)) if float(total).is_integer() else str(total)
        # aplicar zfill si length indicado
        length = conf.get("length", 0)
        if length:
            text = text.zfill(int(length))

        # 5) Escribir en R3
        if "r3_index" in conf:
            df3.iat[conf["r3_index"], 2] = text
        else:
            key = conf["r3_match"].lower()
            row = label_to_row.get(key)
            if row is not None:
                df3.iat[row, 2] = text

def add_padding(lines):
    """
    Aplica padding e inserciones a las líneas generadas:
      - R0 (idx=0): +116 espacios al final.
      - R1 (idx=1): inserta 6 espacios entre pos 39–44.
      - R2 (idx 2..n-2): +32 espacios al final (antes era 31).
      - R3 (idx=n-1): +10 espacios al final.
    """
    padded = []
    total = len(lines)
    for idx, line in enumerate(lines):
        # inserción interna en R1
        if idx == 1:
            if len(line) >= 38:
                line = line[:38] + ' ' * 6 + line[38:]
            else:
                line = line.ljust(38) + ' ' * 6

        # padding final según tipo
        if idx == 0:
            line = line.ljust(len(line) + 116)
        elif 2 <= idx < total - 1:
            # R2: ahora 32 espacios
            line = line + ' ' * 31
        elif idx == total - 1:
            line = line.ljust(len(line) + 10)

        padded.append(line)
    return padded
