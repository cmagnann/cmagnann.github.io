import pandas as pd
from tkinter import messagebox

NAME = "DJ 1889"
SHEET_KEYS = ['R0', 'R1', 'R1.2', 'R1.3', 'R2', 'R3', 'R3.2']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R1.2': 'Registro1.2_Validacion',
    'R1.3': 'Registro1.3_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
    'R3.2': 'Registro3.2_Validacion',
}

# -------------------------------------------------------------------
# Rellena cuando sepas el largo de cada campo
# -------------------------------------------------------------------
FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
    },
    'R1.2': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
    },
    'R1.3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Caja > Unidad': 5,
        'Caja > Número de caja': 3,
        'Número de paquete': 5,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Rut del Afiliado > Nº de RUT': 8,
        'Rut del Afiliado > Díg.verificador': 1,
        'Retiros efectuados > Tipo Ahorro': 1,
        'Retiros efectuados Ctas.Ahorro Voluntario > Monto Anual Nominal de los Retiros': 12,
        'Renta Nominal Anual det. sobre los Retiros > Positiva': 12,
        'Renta Nominal Anual det. sobre los Retiros > Negativa': 12,
        'Renta Anual Actualizada > Positiva': 12,
        'Renta Anual Actualizada > Negativa': 12,
        'Número de Certificado': 7,
        'Caja > Unidad': 5,
        'Caja > Número de caja': 3,
        'Número de paquete': 5,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Retiros efectuados Ctas.Ahorro Voluntario > Monto Anual Nominal de los Retiros': 15,
        'Renta Nominal Anual det. sobre los Retiros > Positiva': 15,
        'Renta Nominal Anual det. sobre los Retiros > Negativa': 15,
        'Renta Anual Actualizada > Positiva': 15,
        'Renta Anual Actualizada > Negativa': 15,
        'Total de Casos Informados': 7,
    },
    'R3.2': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}

def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con multi-índice y dtype=str para preservar ceros.
    """
    dfs = {}
    # Leer registros básicos
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R1.2'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1.2'], header=None)
    dfs['R1.3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1.3'], header=None)
    # R2 multi-índice
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)
    dfs['R3.2'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3.2'], header=None)

    # 2) DEBUG: asegúrate de que ya cargaste e inyectaste los registros forzados
    print("Claves antes de ingresar_datos:", list(dfs.keys()))

    # 3) Inyectar filas forzadas sólo si faltan
    dfs = ingresar_datos(dfs)

    # 4) (opcional) imprimir índices y etiquetas de R0, R1, R1.2, R1.3, R3 y R3.2
    for rec in ['R0', 'R1', 'R1.2', 'R1.3', 'R3', 'R3.2']:
        df = dfs.get(rec)
        if df is None:
            continue
        print(f"\n=== {rec}: índices y etiquetas ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            # actualiza header cuando hay
            if pd.notna(hdr):
                current = str(hdr).strip()
            # decide si imprimo esta fila:
            # - si tiene valor (val no es NaN)
            # - o si es la inserción forzada de R1
            # - o si es la inserción forzada de R3.2
            forced_r1    = (rec == 'R1'   and hdr=='Folio anterior'       and str(sub).strip()=='Cód.de presentación')
            forced_r32   = (rec == 'R3.2' and hdr=='Fecha de Presentación' and str(sub).strip()=='mes')
            if pd.notna(val) or forced_r1 or forced_r32:
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label   = f"{current} > {sub_txt}" if sub_txt else current
                print(f"{i:3d}: {label}")

    # 5) imprimir R2: índice de cada columna multi-índice
    df2 = dfs.get('R2')
    if df2 is not None:
        print("\n=== R2: índices de columnas ===")
        for idx, (lvl0, lvl1) in enumerate(df2.columns):
            lbl = lvl0 if str(lvl1).startswith("Unnamed") else f"{lvl0} > {lvl1}"
            print(f"{idx:3d}: {lbl}")

    return dfs


import pandas as pd
from tkinter import messagebox

def ingresar_datos(dfs):
    """
    Para DJ 1889 inyecta:
      - en R1: 'Folio anterior > Cód.de presentación' antes de 'Folio anterior > Nº folio'
      - en R3.2: 'Fecha de Presentación > mes' antes de 'Fecha de Presentación > año'
    Sólo si no existían ya.
    """
    if NAME != "DJ 1889":
        return dfs

    # ——— R1 ———
    df1 = dfs.get('R1')
    if df1 is not None:
        # Recopilar etiquetas (hdr>sub) aunque val esté vacío
        labels1 = []
        current = ''
        for i in range(1, len(df1)):
            hdr, sub = df1.iat[i,0], df1.iat[i,1]
            if pd.notna(hdr):
                current = str(hdr).strip()
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            labels1.append(f"{current} > {sub_txt}".lower())

        forced1 = 'folio anterior > cód.de presentación'
        if forced1 not in labels1:
            # buscar referencia 'folio anterior > nº folio'
            target1 = 'folio anterior > nº folio'
            idx1 = next((i for i, lab in enumerate(labels1, start=1) if lab == target1), None)
            if idx1 is not None:
                new_row1 = pd.Series({0: 'Folio anterior', 1: 'Cód.de presentación', 2: ''})
                df1 = pd.concat([
                    df1.iloc[:idx1],
                    new_row1.to_frame().T,
                    df1.iloc[idx1:]
                ], ignore_index=True)
                dfs['R1'] = df1
            else:
                messagebox.showwarning(
                    f"{NAME}",
                    f"No encontré '{target1}' en R1. Omitiendo inserción de '{forced1}'."
                )

    # ——— R3.2 ———
    df32 = dfs.get('R3.2')
    if df32 is not None:
        labels32 = []
        current = ''
        for i in range(1, len(df32)):
            hdr, sub = df32.iat[i,0], df32.iat[i,1]
            if pd.notna(hdr):
                current = str(hdr).strip()
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            labels32.append(f"{current} > {sub_txt}".lower())

        forced32 = 'fecha de presentación > mes'
        if forced32 not in labels32:
            target32 = 'fecha de presentación > año'
            idx32 = next((i for i, lab in enumerate(labels32, start=1) if lab == target32), None)
            if idx32 is not None:
                new_row32 = pd.Series({0: 'Fecha de Presentación', 1: 'mes', 2: ''})
                df32 = pd.concat([
                    df32.iloc[:idx32],
                    new_row32.to_frame().T,
                    df32.iloc[idx32:]
                ], ignore_index=True)
                dfs['R3.2'] = df32
            else:
                messagebox.showwarning(
                    f"{NAME}",
                    f"No encontré '{target32}' en R3.2. Omitiendo inserción de '{forced32}'."
                )

    return dfs


def print_fields(dfs):
    """
    Imprime en consola los labels de R0, R1, R1.2, R1.3, R3 y R3.2,
    y las columnas de R2, para rellenar FIELD_LENGTHS.
    """
    for rec in ['R0','R1','R1.2','R1.3','R3','R3.2']:
        df = dfs.get(rec)
        if df is None: continue
        print(f"\n=== {rec}: campos ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr): current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(label)

    df2 = dfs.get('R2')
    if df2 is not None:
        print("\n=== R2: columnas ===")
        for idx, (lvl0, lvl1) in enumerate(df2.columns):
            label = lvl0 if str(lvl1).startswith("Unnamed") else f"{lvl0} > {lvl1}"
            print(f"{idx:3d}: {label}")


def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera las líneas de texto [R0, R1, R1.2, R1.3, *R2_rows, R3, R3.2] para DJ 1889,
    aplicando ceros a la izquierda por defecto, y espacios cuando la etiqueta
    esté en right_space / left_space, sin descartar nunca esas filas.
    """
    import pandas as pd

    # --- Helper para extraer valor verticalmente en DF de tres columnas ---
    def _get_val_vertical(df, label):
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i, 0], df.iat[i, 1], df.iat[i, 2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return '' if pd.isna(val) else str(val).strip()
        return ''

    lines = []
    # — reglas de espacios para DJ 1889 —
    right_space_R1   = {'Folio anterior > Cód.de presentación','Razón Social o Nombre',}
    left_space_R1    = set()

    # Si en R1.2 algunos campos también van a espacios
    right_space_R12 = {
        'Dirección Postal',
        'Comuna',
        'Correo Electrónico',
    }
   # p.ej. {} si no hay ninguno
    left_space_R12  = set()

    # R1.3, R2 y R3 suelen no llevar excepciones de espacios laterales
    left_space_R13  = set()
    left_space_R2   = set()
    left_space_R3   = set()
    left_space_R32  = {'Fecha de Presentación > mes'}

    # --- R0 ---
    df0 = dfs['R0']
    parts0 = []
    for field_name, length in FIELD_LENGTHS['R0'].items():
        txt = _get_val_vertical(df0, field_name)
        parts0.append(txt.zfill(length) if txt or length>0 else txt)
    lines.append(''.join(parts0))

    # --- R1 ---
    df1 = dfs['R1']
    parts1 = []
    for field_name, length in FIELD_LENGTHS['R1'].items():
        txt = _get_val_vertical(df1, field_name)
        if txt:
            if field_name in right_space_R1:
                txt = txt.ljust(length)
            elif field_name in left_space_R1:
                txt = txt.rjust(length)
            else:
                txt = txt.zfill(length)
        else:
            txt = ' ' * length if field_name in (right_space_R1|left_space_R1) else '0'*length
        parts1.append(txt)
    lines.append(''.join(parts1))

    # --- R1.2 ---
    df12 = dfs['R1.2']
    parts12 = []
    for field_name, length in FIELD_LENGTHS['R1.2'].items():
        txt = _get_val_vertical(df12, field_name)
        if txt:
            if field_name in right_space_R12:
                txt = txt.ljust(length)
            elif field_name in left_space_R12:
                txt = txt.rjust(length)
            else:
                txt = txt.zfill(length)
        else:
            txt = ' ' * length if field_name in (right_space_R12|left_space_R12) else '0'*length
        parts12.append(txt)
    lines.append(''.join(parts12))

    # --- R1.3 ---
    df13 = dfs['R1.3']
    parts13 = []
    for field_name, length in FIELD_LENGTHS['R1.3'].items():
        txt = _get_val_vertical(df13, field_name)
        if txt:
            if field_name in left_space_R13:
                txt = txt.rjust(length)
            else:
                txt = txt.zfill(length)
        else:
            txt = ' ' * length if field_name in left_space_R13 else '0'*length
        parts13.append(txt)
    lines.append(''.join(parts13))

    # --- R2 filas ---
    df2_clean = df_r2.loc[~(df_r2 == '').all(axis=1)]
    for _, row in df2_clean.iterrows():
        parts2 = []
        for (lvl0, lvl1), raw_v in zip(df_r2.columns, row.values):
            hdr = str(lvl0).strip()
            sub = str(lvl1).strip()
            label = hdr if sub.startswith("Unnamed") else f"{hdr} > {sub}"
            txt = str(raw_v).strip() if pd.notna(raw_v) else ''
            length = FIELD_LENGTHS['R2'].get(label, 0)
            parts2.append(txt.zfill(length) if txt or length>0 else txt)
        lines.append(''.join(parts2))

    # --- actualizar R3 desde R2 ---
    update_r3_from_r2(dfs, df_r2)

    # --- R3 ---
    df3 = dfs['R3']
    parts3 = []
    for field_name, length in FIELD_LENGTHS['R3'].items():
        txt = _get_val_vertical(df3, field_name)
        if txt:
            txt = txt.zfill(length)
        else:
            txt = ' ' * length if field_name in left_space_R3 else '0'*length
        parts3.append(txt)
    lines.append(''.join(parts3))

    # --- R3.2 ---
    df32 = dfs['R3.2']
    parts32 = []
    for field_name, length in FIELD_LENGTHS['R3.2'].items():
        txt = _get_val_vertical(df32, field_name)
        if txt:
            txt = txt.zfill(length)
        else:
            txt = ' ' * length if field_name in left_space_R32 else '0'*length
        parts32.append(txt)
    lines.append(''.join(parts32))

    return lines


def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2 (count/sum) según tu config.
    """
    df3 = dfs['R3']
    # construir mapa label→fila
    label_map = {}
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        key = (f"{hdr} > {sub}" if pd.notna(sub) else str(hdr)).lower()
        label_map[key] = i

    config = [
        {
          "type": "count",
          "r3_match": "Total de Casos Informados",
          "r3_index": 18,
          "length": FIELD_LENGTHS['R3']["Total de Casos Informados"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Retiros efectuados Ctas.Ahorro Voluntario",
          "r2_lvl1_match":"Monto Anual Nominal de los Retiros",
          "r3_match":"Retiros efectuados Ctas.Ahorro Voluntario > Monto Anual Nominal de los Retiros",
          "r3_index":11,
          "length":FIELD_LENGTHS['R3']["Retiros efectuados Ctas.Ahorro Voluntario > Monto Anual Nominal de los Retiros"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Renta Nominal Anual det. sobre los Retiros",
          "r2_lvl1_match":"Positiva",
          "r3_match":"Renta Nominal Anual det. sobre los Retiros > Positiva",
          "r3_index":13,
          "length":FIELD_LENGTHS['R3']["Renta Nominal Anual det. sobre los Retiros > Positiva"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Renta Nominal Anual det. sobre los Retiros",
          "r2_lvl1_match":"Negativa",
          "r3_match":"Renta Nominal Anual det. sobre los Retiros > Negativa",
          "r3_index":14,
          "length":FIELD_LENGTHS['R3']["Renta Nominal Anual det. sobre los Retiros > Negativa"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Renta Anual Actualizada",
          "r2_lvl1_match":"Positiva",
          "r3_match":"Renta Anual Actualizada > Positiva",
          "r3_index":16,
          "length":FIELD_LENGTHS['R3']["Renta Anual Actualizada > Positiva"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Renta Anual Actualizada",
          "r2_lvl1_match":"Negativa",
          "r3_match":"Renta Anual Actualizada > Negativa",
          "r3_index":17,
          "length":FIELD_LENGTHS['R3']["Renta Anual Actualizada > Negativa"]
        },
    ]

    for conf in config:
        total = len(df_r2) if conf['type']=='count' else 0.0
        if conf['type']=='sum':
            lvl0 = conf['r2_lvl0_match'].lower(); lvl1 = conf['r2_lvl1_match'].lower()
            for (c0,c1), series in df_r2.items():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    total += series.astype(float).sum()
        text = str(int(total)) if float(total).is_integer() else str(total)
        if conf.get('length'): text = text.zfill(conf['length'])
        df3.iat[conf['r3_index'],2] = text


def add_padding(lines):
    """
    Aplica padding final según reglas específicas de DJ 1889:
      - R0  (idx=0): +27 espacios al final
      - R1  (idx=1): 
          • asegurar al menos 36 chars,
          • insertar 6 espacios en pos 36,
          • +32 espacios al final
      - R1.2(idx=2):
          • insertar 1 espacio en pos 105 (índice 104),
          • +2 espacios al final
      - R1.3(idx=3): +98 espacios al final
      - R2  (4 <= idx < total-2): sin cambios
      - R3  (idx == total-2): +8 espacios al final
      - R3.2(idx == total-1): +93 espacios al final
    """
    padded = []
    total = len(lines)

    for idx, line in enumerate(lines):
        # R0
        if idx == 0:
            line = line.ljust(len(line) + 27)

        # R1
        elif idx == 1:
            # 1) asegurar mínimo 36 chars
            new = line.ljust(36)
            # 2) insertar 6 espacios en pos 36
            new = new[:36] + ' ' * 6 + new[36:]
            # 3) padding final de 32 espacios
            line = new.ljust(len(new) + 32)

        # R1.2
        elif idx == 2:
            # 1) insertar 1 espacio en pos 105 (índice 104)
            pos = 104
            if len(line) > pos:
                new = line[:pos] + ' ' + line[pos:]
            else:
                new = line.ljust(pos) + ' '
            # 2) padding final de 2 espacios (los que ya tenías)
            line = new.ljust(len(new) + 2)

        # R1.3
        elif idx == 3:
            # padding final de 98 espacios
            line = line.ljust(len(line) + 98)

        # R2
        elif 4 <= idx < total - 2:
            # sin modificaciones
            pass

        # R3
        elif idx == total - 2:
            line = line.ljust(len(line) + 8)

        # R3.2
        else:  # idx == total-1
            line = line.ljust(len(line) + 93)

        padded.append(line)

    return padded
