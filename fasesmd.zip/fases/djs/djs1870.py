import pandas as pd

NAME = "DJ 1870"
SHEET_KEYS = ['R0', 'R1', 'R1.2', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R1.2': 'Registro1.2_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3_Validacion',
}

# -------------------------------------------------------------------
# Aquí vas rellenando una vez que sepas el largo de cada campo
# -------------------------------------------------------------------
FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Número Formulario > Código de presentación': 1,
        'Número Formulario > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
    },
    'R1.2': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Código certificación > Cód. empresa': 2,
        'Código certificación > Nº de cliente': 4,
        'Localización del docto. > Unidad': 5,
        'Localización del docto. > Número de caja': 3,
        'Localización del docto. > Número de paquete': 5,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Rut Comprador o Vendedor > Nº de RUT': 8,
        'Rut Comprador o Vendedor > Díg.verificador': 1,
        'Identificador otorgado en el extranjero': 30,
        'País otorgante identificador': 2,
        'Nombre o Razon Social': 30,
        'Tipo Transacción': 1,
        'Valores transados': 1,
        'Fecha Transacción > día': 2,
        'Fecha Transacción > mes': 2,
        'Fecha Transacción > año': 4,
        'Documento > Tipo de documento': 1,
        'Documento > Número de Documento': 15,
        'Código Moneda': 5,
        'Monto Moneda Extranjera > Compras': 15,
        'Monto Moneda Extranjera > Ventas': 15,
        'Tipo de Cambio > Parte Entera': 7,
        'Tipo de Cambio > Parte Decimal': 2,
        'Caja > Unidad': 5,
        'Caja > Número de caja': 3,
        'Número de paquete': 5,
    },
    'R3': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Total de Casos Informados': 7,
        'Total compras': 18,
        'Total ventas': 18,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}

def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con multi-índice y dtype=str para preservar ceros.
    """
    dfs = {}
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R1.2'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1.2'], header=None)
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)

    # — Ahora imprimimos los índices y etiquetas de R0, R1, R1.2 y R3 —
    for rec in ['R0','R1','R1.2','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: índices y etiquetas ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(f"{i:3d}: {label}")

    # — Imprimimos R2: nivel0 y nivel1 de cada columna con su índice —
    df2 = dfs['R2']
    print("\n=== R2: índices de columnas (lvl0, lvl1) ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        if str(lvl1).startswith("Unnamed"):
            print(f"{idx:3d}: {lvl0}")
        else:
            print(f"{idx:3d}: {lvl0} > {lvl1}")

    return dfs
def ingresar_datos(dfs):
    """
    Para DJ 1870 inserta manualmente los campos vacíos en:
      - R1: 'Folio anterior > Cód.de presentación' antes de 'Folio anterior > Nº folio'
      - R3: 'Fecha de Presentación > mes'   antes de 'Fecha de Presentación > año'
    Solo si aún no existen.
    """
    if NAME != "DJ 1870":
        return dfs

    # ——— R1 ———
    df1 = dfs['R1']
    # Verifico si ya existe 'Folio anterior > Cód.de presentación'
    exists1 = any(
        (str(df1.iat[i,0]).strip() == 'Folio anterior' and 
         str(df1.iat[i,1]).strip() == 'Cód.de presentación')
        for i in range(1, len(df1))
    )
    if not exists1:
        # Busco índice de referencia
        ref1 = next(
            (i for i in range(1, len(df1))
             if str(df1.iat[i,0]).strip() == 'Folio anterior' and
                str(df1.iat[i,1]).strip() == 'Nº folio'),
            None
        )
        if ref1 is not None:
            new_row1 = pd.Series({0: 'Folio anterior', 1: 'Cód.de presentación', 2: ''})
            df1 = pd.concat([df1.iloc[:ref1], new_row1.to_frame().T, df1.iloc[ref1:]], ignore_index=True)
            dfs['R1'] = df1

    # ——— R3 ———
    df3 = dfs['R3']
    exists3 = any(
        (str(df3.iat[i,0]).strip() == 'Fecha de Presentación' and 
         str(df3.iat[i,1]).strip() == 'mes')
        for i in range(1, len(df3))
    )
    if not exists3:
        ref3 = next(
            (i for i in range(1, len(df3))
             if str(df3.iat[i,0]).strip() == 'Fecha de Presentación' and
                str(df3.iat[i,1]).strip() == 'año'),
            None
        )
        if ref3 is not None:
            new_row3 = pd.Series({0: 'Fecha de Presentación', 1: 'mes', 2: ''})
            df3 = pd.concat([df3.iloc[:ref3], new_row3.to_frame().T, df3.iloc[ref3:]], ignore_index=True)
            dfs['R3'] = df3

    return dfs



def print_fields(dfs):
    """
    Imprime en consola todos los labels de R0, R1, R1.2, R2 y R3
    para ayudarte a poblar FIELD_LENGTHS.
    """
    for rec in ['R0','R1','R1.2','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: campos ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(label)

    df2 = dfs['R2']
    print("\n=== R2: columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        label = f"{lvl0} > {lvl1}" if not str(lvl1).startswith("Unnamed") else str(lvl0)
        print(f"{idx:3d}: {label}")


def _get_val_vertical(df, label):
    """Busca en df (tres columnas) el valor cuya etiqueta ensamblada == label."""
    current = ''
    for i in range(len(df)):
        hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        if pd.notna(val):
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return str(val)
    return ''


def generar_lines_en_memoria(dfs, df_r2):
    lines = []

    # — reglas de spacing para DJ 1870 —
    # Campos de R1 que deben rellenarse con espacios por la izquierda
    left_space_R1  = {
        'Folio anterior > Cód.de presentación',
        'Razón Social o Nombre',
        'Dirección Postal',
        'Comuna',
        'Correo Electrónico',
    }

    # R1.2 no tiene excepciones de espacios
    right_space_R12 = set()
    left_space_R12  = set()

    # Campos de R2 con espacios a la izquierda (el resto cero-fill)
    left_space_R2 = {
        'Identificador otorgado en el extranjero',
        'Nombre o Razon Social',
        'Código Moneda',
    }
    right_space_R2 = set()  # añadir si hubiese campos a la derecha

    # R3
    left_space_R3   = {'Fecha de Presentación > mes'}

    def _get_val_vertical(df, label):
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return '' if pd.isna(val) else str(val).strip()
        return ''

    # — R0 —
    df0 = dfs['R0']
    parts0 = []
    for i in range(1, len(df0)):
        hdr, sub, val = df0.iat[i,0], df0.iat[i,1], df0.iat[i,2]
        if pd.isna(val):
            continue
        label = str(hdr).strip() + (f" > {str(sub).strip()}" if pd.notna(sub) else "")
        txt = str(val).strip()
        length = FIELD_LENGTHS['R0'].get(label, 0)
        if length:
            txt = txt.zfill(length)
        parts0.append(txt)
    lines.append(''.join(parts0))

    # — R1 —
    parts1 = []
    for field_name, length in FIELD_LENGTHS['R1'].items():
        txt = _get_val_vertical(dfs['R1'], field_name)
        if txt:
            if field_name in left_space_R1:
                txt = txt.rjust(length)
            else:
                txt = txt.zfill(length)
        else:
            # vacío → espacios a la izquierda si está en left_space_R1, sino ceros
            txt = ' ' * length if field_name in left_space_R1 else '0' * length
        parts1.append(txt)
    lines.append(''.join(parts1))

    # — R1.2 —
    parts12 = []
    for field_name, length in FIELD_LENGTHS['R1.2'].items():
        txt = _get_val_vertical(dfs['R1.2'], field_name)
        if txt:
            txt = txt.zfill(length)
        else:
            txt = '0' * length
        parts12.append(txt)
    lines.append(''.join(parts12))

    # — R2 —
    df2_clean = df_r2.loc[~(df_r2 == '').all(axis=1)]
    for _, row in df2_clean.iterrows():
        parts2 = []
        for (lvl0, lvl1), raw_v in zip(df_r2.columns, row.values):
            hdr = str(lvl0).strip()
            sub = str(lvl1).strip()
            label = hdr if sub.startswith("Unnamed") else f"{hdr} > {sub}"
            txt = str(raw_v).strip() if pd.notna(raw_v) else ''
            length = FIELD_LENGTHS['R2'].get(label, 0)

            if txt:
                if label in left_space_R2:
                    txt = txt.rjust(length)
                elif label in right_space_R2:
                    txt = txt.ljust(length)
                else:
                    txt = txt.zfill(length)
            else:
                if label in left_space_R2 or label in right_space_R2:
                    txt = ' ' * length
                else:
                    txt = '0' * length

            parts2.append(txt)
        lines.append(''.join(parts2))

    # — R3 totals —
    update_r3_from_r2(dfs, df_r2)

    # — R3 —
    parts3 = []
    for field_name, length in FIELD_LENGTHS['R3'].items():
        txt = _get_val_vertical(dfs['R3'], field_name)
        if txt:
            txt = txt.zfill(length)
        else:
            txt = ' ' * length if field_name in left_space_R3 else '0' * length
        parts3.append(txt)
    lines.append(''.join(parts3))

    return lines



def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2 (count/sum).
    Para DJ 1870 aplica reglas de count/sum según `config`.
    """
    df3 = dfs['R3']

    # 1) Construir mapa label→fila en R3
    label_to_row = {}
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        hdr_txt = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        key = (f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt).lower()
        label_to_row[key] = i

    # 2) Lista de configs
    config = [
        {
          "type": "count",
          "r3_match": "Total de Casos Informados",
          "r3_index": 9,
          "length": FIELD_LENGTHS['R3']["Total de Casos Informados"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto Moneda Extranjera",
          "r2_lvl1_match":"Compras",
          "r3_match":"Total compras",
          "r3_index":10,
          "length":FIELD_LENGTHS['R3']["Total compras"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto Moneda Extranjera",
          "r2_lvl1_match":"Ventas",
          "r3_match":"Total ventas",
          "r3_index":11,
          "length":FIELD_LENGTHS['R3']["Total ventas"]
        },
    ]

    # 3) Procesar cada config
    for conf in config:
        total = 0.0
        if conf["type"] == "count":
            total = len(df_r2)
        else:
            lvl0 = conf.get("r2_lvl0_match","").lower()
            lvl1 = conf.get("r2_lvl1_match","").lower()
            # <- aquí cambiamos iteritems() por items()
            for (c0, c1), serie in df_r2.items():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    total += serie.astype(float).sum()

        # Formatear total
        text = str(int(total)) if float(total).is_integer() else str(total)
        if conf.get("length", 0):
            text = text.zfill(conf["length"])

        # Escribir en R3
        df3.iat[conf["r3_index"], 2] = text

    # Si necesitases usar r3_match en lugar de r3_index:
    # else:
    #     row = label_to_row.get(conf["r3_match"].lower())
    #     if row is not None:
    #         df3.iat[row, 2] = text


def add_padding(lines):
    """
    Aplica padding final e inserciones específicas a la salida
    según las reglas de la DJ 1870:
      - R0 (idx=0): +91 espacios al final
      - R1 (idx=1):
         1) asegurar mínimo 36 caracteres
         2) insertar 6 espacios en pos 36
         3) padding final de 5 espacios
      - R1.2 (idx=2): +145 espacios al final
      - R2 (2 < idx < total-1): sin cambios
      - R3 (idx == total-1): +94 espacios al final
    """
    padded = []
    total = len(lines)

    for idx, line in enumerate(lines):
        if idx == 0:
            # R0
            line = line.ljust(len(line) + 91)

        elif idx == 1:
            # R1
            # 1) asegurar al menos 36 chars
            new_line = line.ljust(36)
            # 2) insertar 6 espacios en pos 36
            new_line = new_line[:36] + ' ' * 6 + new_line[36:]
            # 3) padding final de 5 espacios
            line = new_line.ljust(len(new_line) + 5)

        elif idx == 2:
            # R1.2
            line = line.ljust(len(line) + 145)

        elif idx == total - 1:
            # R3
            line = line.ljust(len(line) + 94)

        else:
            # R2: sin modificaciones
            pass

        padded.append(line)

    return padded
