import pandas as pd
from tkinter import messagebox

NAME = "DJ 1871"
SHEET_KEYS = ['R0', 'R1', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
}

# -------------------------------------------------------------------
# Define aquí los largos de cada campo una vez los tengas
# -------------------------------------------------------------------
FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Código certificación > Cód. empresa': 2,
        'Código certificación > Nº de cliente': 4,
        'Caja > Unidad': 5,
        'Caja > Número de caja': 3,
        'Número de paquete': 5,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Rut Trabajador > Nº de RUT': 8,
        'Rut Trabajador > Díg.verificador': 1,
        'Año Ahorro': 4,
        'Ahorro previsional voluntario colectivo(ahooro trabajador)': 12,
        'Depósito ahorro previsional voluntario': 12,
        'Cotizaciones Voluntarias': 12,
        'Ahorro previsional voluntario colectivo(ahooro trabajador)': 12,
        'Depósito ahorro previsional voluntario': 12,
        'Cotizaciones Voluntarias': 12,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Total Ahorros acogidos al inciso segundo del Art 42 BIS de la LIR': 15,
        'Total retiros correspondientes a depósitos realizados en el período que se informa acogidos al inciso segundo del Art 42 Bis de la LIR': 15,
        'Total de Casos Informados': 7,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}



def load_dfs(path_excel):
    """
    Carga cada hoja según SHEET_MAP y llama a ingresar_datos para inyectar
    campos faltantes en R1 y R3.
    """
    dfs = {}
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)

    # 2) DEBUG: asegúrate de que R1 y R3 ya existen
    print("Claves antes de ingresar_datos:", list(dfs.keys()))

    # 3) Inyectar filas forzadas sólo si faltan
    dfs = ingresar_datos(dfs)

    # 4) (opcional) imprimir índices/etiquetas
    for rec in ['R0','R1','R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: índices y etiquetas ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val) or (hdr=='Folio anterior' and sub=='Cód.de presentación'):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(f"{i:3d}: {label}")

    # 5) imprimir R2 columnas
    df2 = dfs['R2']
    print("\n=== R2: índices de columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        lbl = lvl0 if str(lvl1).startswith("Unnamed") else f"{lvl0} > {lvl1}"
        print(f"{idx:3d}: {lbl}")

    return dfs



def ingresar_datos(dfs):
    """
    Para DJ 1871, inserta sólo si no existen:
      - R1: 'Folio anterior > Cód.de presentación' antes de 'Folio anterior > Nº folio'
      - R3: 'Fecha de Presentación > mes'   antes de 'Fecha de Presentación > año'
    """
    if NAME != "DJ 1871":
        return dfs

    # — R1 —
    df1 = dfs['R1']
    # construir lista de etiquetas lower
    labels1 = []
    current = ''
    for i in range(1, len(df1)):
        hdr, sub = df1.iat[i,0], df1.iat[i,1]
        if pd.notna(hdr):
            current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        labels1.append(f"{current} > {sub_txt}".lower() if sub_txt else current.lower())
    forced1 = 'folio anterior > cód.de presentación'
    if forced1 not in labels1:
        # buscar posición de referencia
        try:
            idx_ref1 = labels1.index('folio anterior > nº folio') + 1
            new_row = pd.Series({0: 'Folio anterior', 1: 'Cód.de presentación', 2: ''})
            df1 = pd.concat([df1.iloc[:idx_ref1], new_row.to_frame().T, df1.iloc[idx_ref1:]],
                            ignore_index=True)
            dfs['R1'] = df1
        except ValueError:
            messagebox.showwarning("DJ 1871", 
                "No encontré 'Folio anterior > Nº folio' en R1; omitiendo inserción.")

    # — R3 —
    df3 = dfs['R3']
    labels3 = []
    current = ''
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        if pd.notna(hdr):
            current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        labels3.append(f"{current} > {sub_txt}".lower() if sub_txt else current.lower())
    forced3 = 'fecha de presentación > mes'
    if forced3 not in labels3:
        try:
            idx_ref3 = labels3.index('fecha de presentación > año') + 1
            new_row = pd.Series({0: 'Fecha de Presentación', 1: 'mes', 2: ''})
            df3 = pd.concat([df3.iloc[:idx_ref3], new_row.to_frame().T, df3.iloc[idx_ref3:]],
                            ignore_index=True)
            dfs['R3'] = df3
        except ValueError:
            messagebox.showwarning("DJ 1871", 
                "No encontré 'Fecha de Presentación > Año' en R3; omitiendo inserción.")

    return dfs


def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera las líneas de texto [R0, R1, *R2_rows, R3] para DJ 1871,
    aplicando por defecto ceros a la izquierda, pero:
      - R1:
          • 'Folio anterior > Cód.de presentación',
            'Razón Social o Nombre',
            'Dirección Postal',
            'Comuna',
            'Correo Electrónico'
            → siempre espacios a la derecha
      - R3:
          • 'Fecha de Presentación > mes' → espacios a la izquierda
    """
    # — excepciones de padding —
    right_space_R1 = {
        'Folio anterior > Cód.de presentación',
        'Razón Social o Nombre',
        'Dirección Postal',
        'Comuna',
        'Correo Electrónico',
    }
    # ya no hay left_space_R1
    left_space_R3  = {'Fecha de Presentación > mes'}

    def _get_val_vertical(df, label):
        current = ''
        for i in range(1, len(df)):
            hdr, sub, raw = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return '' if pd.isna(raw) else str(raw).strip()
        return ''

    lines = []

    # --- R0 ---
    df0 = dfs['R0']
    parts0 = []
    for field_name, length in FIELD_LENGTHS['R0'].items():
        val = _get_val_vertical(df0, field_name)
        parts0.append(val.zfill(length) if val else '0'*length)
    lines.append(''.join(parts0))

    # --- R1 ---
    df1 = dfs['R1']
    parts1 = []
    for field_name, length in FIELD_LENGTHS['R1'].items():
        val = _get_val_vertical(df1, field_name)
        if val:
            if field_name in right_space_R1:
                txt = val.ljust(length)
            else:
                txt = val.zfill(length)
        else:
            # vacío → espacios a la derecha en todos los excepcionados
            txt = ' ' * length if field_name in right_space_R1 else '0'*length
        parts1.append(txt)
    lines.append(''.join(parts1))

    # --- R2 (fila a fila) ---
    df2_clean = df_r2.loc[~(df_r2 == '').all(axis=1)]
    for _, row in df2_clean.iterrows():
        parts2 = []
        for (lvl0, lvl1), raw in zip(df_r2.columns, row.values):
            hdr = str(lvl0).strip()
            sub = str(lvl1).strip()
            label = hdr if sub.startswith("Unnamed") else f"{hdr} > {sub}"
            txt = str(raw).strip() if pd.notna(raw) else ''
            length = FIELD_LENGTHS['R2'].get(label, 0)
            parts2.append(txt.zfill(length) if txt else '0'*length)
        lines.append(''.join(parts2))

    # --- R3: actualizamos totales según config ---
    update_r3_from_r2(dfs, df_r2)

    # --- R3: formateo final ---
    df3 = dfs['R3']
    parts3 = []
    for field_name, length in FIELD_LENGTHS['R3'].items():
        val = _get_val_vertical(df3, field_name)
        if val:
            txt = val.zfill(length)
        else:
            txt = ' ' * length if field_name in left_space_R3 else '0'*length
        parts3.append(txt)
    lines.append(''.join(parts3))

    return lines



def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2 para DJ 1871:
      - count → total de filas
      - sum por índice de columna r2_col_index cuando esté presente
      - fallback a la lógica por lvl0/lvl1 si se usa r2_lvl*_match
    """
    df3 = dfs['R3']

    # 1) Construir mapa label→fila en R3
    label_to_row = {}
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        hdr_txt = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        key = (f"{hdr_txt} > {sub_txt}" if sub_txt else hdr_txt).lower()
        label_to_row[key] = i

    # 2) Configuración específica de DJ 1871
    config = [
        {
          "type": "count",
          "r3_match": "Total de Casos Informados",
          "r3_index": 12,
          "length": FIELD_LENGTHS['R3']["Total de Casos Informados"]
        },
        {
          "type": "sum",
          "r2_col_index": 11,   # primer "Depósito ahorro previsional voluntario"
          "r3_match": "Total Ahorros acogidos al inciso segundo del Art 42 BIS de la LIR",
          "r3_index": 10,
          "length": FIELD_LENGTHS['R3']["Total Ahorros acogidos al inciso segundo del Art 42 BIS de la LIR"]
        },
        {
          "type": "sum",
          "r2_col_index": 14,   # segundo "Depósito ahorro previsional voluntario"
          "r3_match": "Total retiros correspondientes a depósitos realizados en el período que se informa acogidos al inciso segundo del Art 42 Bis de la LIR",
          "r3_index": 11,
          "length": FIELD_LENGTHS['R3']["Total retiros correspondientes a depósitos realizados en el período que se informa acogidos al inciso segundo del Art 42 Bis de la LIR"]
        },
    ]

    # 3) Procesar cada regla
    for conf in config:
        # 3.1) Obtener total según tipo
        if conf["type"] == "count":
            total = len(df_r2)

        elif "r2_col_index" in conf:
            # sumamos la columna exacta
            col = df_r2.columns[conf["r2_col_index"]]
            total = df_r2[col].astype(float).sum()

        else:
            # lógica por lvl0/lvl1
            total = 0.0
            lvl0 = conf.get("r2_lvl0_match", "").lower()
            lvl1 = conf.get("r2_lvl1_match", "").lower()
            for (c0, c1), serie in df_r2.items():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    total += serie.astype(float).sum()

        # 3.2) Formatear el resultado
        text = str(int(total)) if float(total).is_integer() else str(total)
        if conf.get("length", 0):
            text = text.zfill(conf["length"])

        # 3.3) Escribir en R3
        row_idx = conf["r3_index"]
        df3.iat[row_idx, 2] = text


def add_padding(lines):
    """
    Aplica padding final e inserciones específicas según DJ 1871:

      - R0 (idx=0): +117 espacios al final
      - R1 (idx=1): 
          1) asegurar al menos 36 caracteres
          2) insertar 6 espacios en pos 36
          3) asegurar al menos 184 caracteres
          4) insertar 1 espacio en pos 184
      - R2 (2 <= idx < total-1): +95 espacios al final
      - R3 (idx == total-1): +125 espacios al final
    """
    padded = []
    total = len(lines)

    for idx, line in enumerate(lines):
        if idx == 0:
            # R0
            new_line = line.ljust(len(line) + 117)

        elif idx == 1:
            # R1
            # 1) asegurar al menos 36 caracteres
            new_line = line.ljust(36)
            # 2) insertar 6 espacios en pos 36
            new_line = new_line[:36] + ' ' * 6 + new_line[36:]
            # 3) asegurar al menos 184 caracteres
            insert_pos = 183
            new_line = new_line.ljust(insert_pos)
            # 4) insertar 1 espacio en pos 184
            new_line = new_line[:insert_pos] + ' ' + new_line[insert_pos:]

        elif idx == total - 1:
            # R3
            new_line = line.ljust(len(line) + 125)

        else:
            # R2
            new_line = line.ljust(len(line) + 95)

        padded.append(new_line)

    return padded
