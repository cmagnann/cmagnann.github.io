import pandas as pd

NAME = "DJ 1899"
SHEET_KEYS = ['R0', 'R1', 'R2', 'R3', 'R3.2']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
    'R3.2': 'Registro3.2_Validacion',
}

FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora > Hora': 2,
        'Hora > Minuto': 2,
        'Hora > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT anterior > Número de RUT': 8,
        'RUT anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Codigo certificacion > Codigo empresa': 2,
        'Codigo certificacion > Número de clinete': 4,
        'Localización del docto. > Unidad': 5,
        'Localización del docto. > Número de caja': 3,
        'Localización del docto. > Número de paquete': 5,
        'Periodo': 6,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Rut Afiliado o Pensionado > Nº de RUT': 8,
        'Rut Afiliado o Pensionado > Díg.verificador': 1,
        'Activo o Pensionado': 1,
        'Rut Empleador > Nº de RUT': 8,
        'Rut Empleador > Díg.verificador': 1,
        'Depósitos Convenidos con el empleador en UF > Depósitos Convenidos (Parte Entera)': 10,
        'Depósitos Convenidos con el empleador en UF > Depósitos Convenidos (Parte Decimal)': 3,
        'Aporte Empleador > Aporte Empleador (Parte Entera)': 10,
        'Aporte Empleador > Aporte Empleador (Parte Decimal)': 3,
        'Aporte Empleador > Traspaso Empleador (Parte Entera)': 10,
        'Aporte Empleador > Traspaso Empleador (Parte Decimal)': 3,
        'Aporte Empleador > Retiro Empleador': 10,
        'Aporte Empleador > Monto Retención 15%': 10,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (parte Entera)': 10,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (Parte Decimal)': 3,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (parte Entera)': 10,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (Parte Decimal)': 3,
        'DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador(Parte Entera)': 10,
        'DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador (Parte Decimal)': 3,
        'DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Entera)': 10,
        'DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Decimal)': 3,
        'DAPV o cotizaciones Voluntarias enteradas en calidad de trabajador Independiente del Art 42 de la LIR en UF > DAPV o cotizaciones Voluntarias (Parte Entera)': 10,
        'DAPV o cotizaciones Voluntarias enteradas en calidad de trabajador Independiente del Art 42 de la LIR en UF > DAPV o cotizaciones Voluntarias (Parte Decimal)': 3,
        'Monto de los retiros efectuados con cargo a los ahorros previsionales voluntarios realizados, Actualizados > Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42': 12,
        'Monto de los retiros efectuados con cargo a los ahorros previsionales voluntarios realizados, Actualizados > Retencion del impuesto de 15% practicada sobre retiros': 12,
        'Monto de los retiros efectuados con cargo a los ahorros previsionales voluntarios realizados, Actualizados > Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso segundo del Art. 42': 12,
        'Número de Certificado Trabajador': 7,
        'Número de Certificado Empleador': 7,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Depósitos convenidos con el empleador en UF > Depositos Convenidos pon Empleador en UF (Parte Entera)': 15,
        'Depósitos convenidos con el empleador en UF > Depositos Convenidos pon Empleador en UF (Parte Decimal)': 3,
        'Aporte Empleador > Aporte Empleador (Parte Entera)': 15,
        'Aporte Empleador > Aporte Empleador (Parte Decimal)': 3,
        'Aporte Empleador > Traspaso Empleador (Parte Entera)': 15,
        'Aporte Empleador > Traspaso Empleador (Parte Decimal)': 3,
        'Aporte Empleador > Retiro Empleador': 15,
        'Aporte Empleador > Monto Retención 15%': 15,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (parte Entera)': 15,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (Parte Decimal)': 3,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (parte Entera)': 15,
        'Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (Parte Decimal)': 3,
        'DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador(Parte Entera)': 15,
        'DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador (Parte Decimal)': 3,
        'DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Entera)': 15,
        'DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Decimal)': 3,
        'DAPV o cotizaciones Voluntarias enteradas en calidad de trabajador Independiente del Art 42 de la LIR en UF > DAPV o cotizaciones Voluntarias(Parte Entera)': 15,
        'DAPV o cotizaciones Voluntarias enteradas en calidad de trabajador Independiente del Art 42 de la LIR en UF > DAPV o cotizaciones Voluntarias (Parte Decimal)': 3,
    },
    'R3.2': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42 > Trabajadores Activos': 15,
        'Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42 > Pensionados o personas que cumplen con los requisitos para pensionarse': 15,
        'Retencione de Impuesto de 15% practicada sobre retiros': 15,
        'Monto proveniente de Ahorros Acogidos a Beneficio Tributario': 15,
        'Total de Casos Informados': 7,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}


def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con multi-índice y dtype=str para preservar ceros.
    """
    dfs = {}
    dfs['R0']  = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1']  = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R2']  = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3']  = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)
    dfs['R3.2']= pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3.2'], header=None)

    # debug: imprime índices y etiquetas
    print("Claves cargadas:", list(dfs.keys()))
    for rec in SHEET_KEYS:
        df = dfs[rec]
        print(f"=== {rec}: índices y etiquetas ===")
        if rec == 'R2':
            for idx, (lvl0, lvl1) in enumerate(df.columns):
                lbl = lvl0 if str(lvl1).startswith("Unnamed") else f"{lvl0} > {lvl1}"
                print(f"{idx:3d}: {lbl}")
        else:
            curr = ''
            for i in range(1, len(df)):
                hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
                if pd.notna(hdr): curr = str(hdr).strip()
                if pd.notna(val):
                    sub_txt = str(sub).strip() if pd.notna(sub) else ''
                    lbl = f"{curr} > {sub_txt}" if sub_txt else curr
                    print(f"{i:3d}: {lbl}")
    return dfs

def ingresar_datos(dfs):
    """
    Inserta filas vacías en R1 o R3.2 si faltan etiquetas específicas.
    Por ejemplo:
      - en R1: 'Folio anterior > Cód.de presentación' antes de 'Folio anterior > Nº folio'
      - en R3.2: 'Fecha de Presentación > mes' antes de 'Fecha de Presentación > año'
    """
    if NAME != "DJ 1899":
        return dfs

    # ——— R1 ———
    df1 = dfs['R1']
    # 1) Recolectar etiquetas
    labels1 = []
    current = ''
    for i in range(1, len(df1)):
        hdr, sub = df1.iat[i,0], df1.iat[i,1]
        if pd.notna(hdr):
            current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        labels1.append(f"{current} > {sub_txt}".lower() if sub_txt else current.lower())
    # 2) Insertar si no existe
    forced1 = 'folio anterior > cód.de presentación'
    if forced1 not in labels1:
        # buscamos índice de 'folio anterior > nº folio'
        target1 = 'folio anterior > nº folio'
        idx1 = next((i for i, lab in enumerate(labels1, start=1) if lab == target1), None)
        if idx1 is not None:
            new_row = pd.Series({0: 'Folio anterior', 1: 'Cód.de presentación', 2: ''})
            df1 = pd.concat([df1.iloc[:idx1], new_row.to_frame().T, df1.iloc[idx1:]], ignore_index=True)
            dfs['R1'] = df1

    # ——— R3.2 ———
    df32 = dfs['R3.2']
    labels32 = []
    current = ''
    for i in range(1, len(df32)):
        hdr, sub = df32.iat[i,0], df32.iat[i,1]
        if pd.notna(hdr):
            current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        labels32.append(f"{current} > {sub_txt}".lower() if sub_txt else current.lower())
    forced32 = 'fecha de presentación > mes'
    if forced32 not in labels32:
        target32 = 'fecha de presentación > año'
        idx32 = next((i for i, lab in enumerate(labels32, start=1) if lab == target32), None)
        if idx32 is not None:
            new_row = pd.Series({0: 'Fecha de Presentación', 1: 'mes', 2: ''})
            df32 = pd.concat([df32.iloc[:idx32], new_row.to_frame().T, df32.iloc[idx32:]], ignore_index=True)
            dfs['R3.2'] = df32

    return dfs

def _get_val_vertical(df, label):
    """Extrae de un df de 3 cols el valor de la fila cuya etiqueta ensamblada == label"""
    current = ''
    for i in range(1, len(df)):
        hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
        if pd.notna(hdr):
            current = str(hdr).strip()
        sub_txt = str(sub).strip() if pd.notna(sub) else ''
        lab = f"{current} > {sub_txt}" if sub_txt else current
        if lab == label:
            return '' if pd.isna(val) else str(val).strip()
    return ''

def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera las líneas de texto [R0_line, R1_line, *R2_rows, R3_line, R3.2_line].
    Usa FIELD_LENGTHS para padding: por defecto ceros a la izquierda,
    y txt.ljust / txt.rjust en tus excepciones.
    """
    lines = []
    right_space_R1   = {'Folio anterior > Cód.de presentación'}
    left_space_R1    = set()  # o los que necesites
    left_space_R32   = {'Fecha de Presentación > mes'}
    # --- R0 ---
    df0 = dfs['R0']
    parts0 = []
    for field, length in FIELD_LENGTHS['R0'].items():
        val = _get_val_vertical(df0, field)
        parts0.append(val.zfill(length) if val else '0'*length)
    lines.append(''.join(parts0))

    # --- R1 ---
    df1 = dfs['R1']
    parts1 = []
    for field, length in FIELD_LENGTHS['R1'].items():
        txt = _get_val_vertical(dfs['R1'], field)
        if txt:
            if field in right_space_R1:
                txt = txt.ljust(length)
            else:
                txt = txt.zfill(length)
        else:
            txt = ' ' * length if field in right_space_R1 else '0' * length
        parts1.append(txt)
    lines.append(''.join(parts1))

    # --- R2 filas ---
    df2 = df_r2.loc[~(df_r2=='').all(axis=1)]
    for _, row in df2.iterrows():
        out = []
        for (lvl0,lvl1), raw in zip(df_r2.columns, row.values):
            hdr, sub = str(lvl0).strip(), str(lvl1).strip()
            label = hdr if sub.startswith("Unnamed") else f"{hdr} > {sub}"
            length = FIELD_LENGTHS['R2'].get(label, 0)
            val = str(raw).strip() if pd.notna(raw) else ''
            out.append(val.zfill(length) if val else '0'*length)
        lines.append(''.join(out))

    # --- R3 ---
    df3 = dfs['R3']
    parts3 = []
    for field, length in FIELD_LENGTHS['R3'].items():
        val = _get_val_vertical(df3, field)
        parts3.append(val.zfill(length) if val else '0'*length)
    lines.append(''.join(parts3))

    # --- R3.2 ---
    # después de generar R3...
    parts32 = []
    for field, length in FIELD_LENGTHS['R3.2'].items():
        val = _get_val_vertical(dfs['R3.2'], field)
        if val:
            txt = val.zfill(length)
        else:
            txt = ' ' * length  # o '0'*length según tus reglas
        parts32.append(txt)
    lines.append(''.join(parts32))

    return lines

def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2 (count/sum).
    Convierte valores de R2 a numérico con errors='coerce' para tratar cadenas vacías como 0.
    """
    import pandas as pd
    from collections import defaultdict

    df3  = dfs['R3']
    df32 = dfs.get('R3.2', None)

    # Normalizador de etiquetas
    def _normalize(lbl):
        return lbl.strip().lower()

    # 1) Construir mapa normalized_label → fila en R3
    label_map_3 = {}
    for i in range(1, len(df3)):
        hdr, sub = df3.iat[i,0], df3.iat[i,1]
        key = f"{hdr} > {sub}" if pd.notna(sub) else str(hdr)
        label_map_3[_normalize(key)] = i

    config = [
        {
          "type": "count",
          "r3.2_match": "Total de Casos Informados",
          "r3.2_index": 10,
          "length_key": ("R3.2", "Total de Casos Informados")
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Depósitos Convenidos con el empleador en UF",
          "r2_lvl1_match":"Depósitos Convenidos (Parte Entera)",
          "match":1,
          "r3_match":"Depósitos convenidos con el empleador en UF > Depositos Convenidos pon Empleador en UF (Parte Entera)",
          "r3_index":12,
          "length":FIELD_LENGTHS['R3']["Depósitos convenidos con el empleador en UF > Depositos Convenidos pon Empleador en UF (Parte Entera)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Depósitos Convenidos con el empleador en UF",
          "r2_lvl1_match":"Depósitos Convenidos (Parte Decimal)",
          "match":1,
          "r3_match":"Depósitos convenidos con el empleador en UF > Depositos Convenidos pon Empleador en UF (Parte Decimal)",
          "r3_index":13,
          "length":FIELD_LENGTHS['R3']["Depósitos convenidos con el empleador en UF > Depositos Convenidos pon Empleador en UF (Parte Decimal)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Aporte Empleador",
          "r2_lvl1_match":"Aporte Empleador (Parte Entera)",
          "match":2,
          "r3_match":"Aporte Empleador > Aporte Empleador (Parte Entera)",
          "r3_index":16,
          "length":FIELD_LENGTHS['R3']["Aporte Empleador > Aporte Empleador (Parte Entera)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Aporte Empleador",
          "r2_lvl1_match":"Aporte Empleador (Parte Decimal)",
          "match":2,
          "r3_match":"Aporte Empleador > Aporte Empleador (Parte Decimal)",
          "r3_index":17,
          "length":FIELD_LENGTHS['R3']["Aporte Empleador > Aporte Empleador (Parte Decimal)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Aporte Empleador",
          "r2_lvl1_match":"Traspaso Empleador (Parte Entera)",
          "match":3,
          "r3_match":"Aporte Empleador > Traspaso Empleador (Parte Entera)",
          "r3_index":18,
          "length":FIELD_LENGTHS['R3']["Aporte Empleador > Traspaso Empleador (Parte Entera)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Aporte Empleador",
          "r2_lvl1_match":"Traspaso Empleador (Parte Decimal)",
          "match":3,
          "r3_match":"Aporte Empleador > Traspaso Empleador (Parte Decimal)",
          "r3_index":19,
          "length":FIELD_LENGTHS['R3']["Aporte Empleador > Traspaso Empleador (Parte Decimal)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Aporte Empleador",
          "r2_lvl1_match":"Retiro Empleador",
          "r3_match":"Aporte Empleador > Retiro Empleador",
          "r3_index":20,
          "length":FIELD_LENGTHS['R3']["Aporte Empleador > Retiro Empleador"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Aporte Empleador",
          "r2_lvl1_match":"Monto Retención 15%",
          "r3_match":"Aporte Empleador > Monto Retención 15%",
          "r3_index":21,
          "length":FIELD_LENGTHS['R3']["Aporte Empleador > Monto Retención 15%"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Ahorros del trabajador acogidos al inciso primero Art.42",
          "r2_lvl1_match":"Modalidad Indirecta vía Empleador (parte Entera)",
          "match":4,
          "r3_match":"Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (parte Entera)",
          "r3_index":23,
          "length":FIELD_LENGTHS['R3']["Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (parte Entera)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Ahorros del trabajador acogidos al inciso primero Art.42",
          "r2_lvl1_match":"Modalidad Indirecta vía Empleador (Parte Decimal)",
          "match":4,
          "r3_match":"Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (Parte Decimal)",
          "r3_index":24,
          "length":FIELD_LENGTHS['R3']["Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Indirecta vía Empleador (Parte Decimal)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Ahorros del trabajador acogidos al inciso primero Art.42",
          "r2_lvl1_match":"Modalidad Directa vía Trabajador (parte Entera)",
          "match":5,
          "r3_match":"Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (parte Entera)",
          "r3_index":25,
          "length":FIELD_LENGTHS['R3']["Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (parte Entera)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Ahorros del trabajador acogidos al inciso primero Art.42",
          "r2_lvl1_match":"Modalidad Directa vía Trabajador (Parte Decimal)",
          "match":5,
          "r3_match":"Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (Parte Decimal)",
          "r3_index":26,
          "length":FIELD_LENGTHS['R3']["Ahorros del trabajador acogidos al inciso primero Art.42 > Modalidad Directa vía Trabajador (Parte Decimal)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF",
          "r2_lvl1_match":"Modalidad Indirecta Via Empleador(Parte Entera)",
          "match":6,
          "r3_match":"DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador(Parte Entera)",
          "r3_index":29,
          "length":FIELD_LENGTHS['R3']["DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador(Parte Entera)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF",
          "r2_lvl1_match":"Modalidad Indirecta Via Empleador (Parte Decimal)",
          "match":6,
          "r3_match":"DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador (Parte Decimal)",
          "r3_index":30,
          "length":FIELD_LENGTHS['R3']["DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Indirecta Via Empleador (Parte Decimal)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF",
          "r2_lvl1_match":"Modalidad Directa Via Trabajador (Parte Entera)",
          "match":7,
          "r3_match":"DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Entera)",
          "r3_index":31,
          "length":FIELD_LENGTHS['R3']["DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Entera)"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"DAPV o ctizaciones Voluntarias enterado en calidad del trabajador Dependiente del Art 42 de la LIR en UF",
          "r2_lvl1_match":"Modalidad Directa Via Trabajador (Parte Decimal)",
          "match":7,
          "r3_match":"DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Decimal)",
          "r3_index":32,
          "length":FIELD_LENGTHS['R3']["DAPV o cotizaciones Voluntarias enterado en calidad de trabajador Dependiente del Art 42 de la LIR en UF > Modalidad Directa Via Trabajador (Parte Decimal)"]
        },
        {
            # tratamiento especial: según 'Activo o Pensionado' =1 o =2
            "type":"sum",
            "r2_lvl0_match":"Monto de los retiros efectuados con cargo a los ahorros previsionales voluntarios realizados, Actualizados",
            "r2_lvl1_match":"Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42",
            "r3.2_match_1":"Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42 > Trabajadores Activos",
            "r3.2_match_2":"Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42 > Pensionados o personas que cumplen con los requisitos para pensionarse",
            "r3.2_indexM1":6,
            "r3.2_indexM2":7,
            "lengthM1":FIELD_LENGTHS['R3.2']["Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42 > Trabajadores Activos"],
            "lengthM2":FIELD_LENGTHS['R3.2']["Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso primero del Art. 42 > Pensionados o personas que cumplen con los requisitos para pensionarse"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto de los retiros efectuados con cargo a los ahorros previsionales voluntarios realizados, Actualizados",
          "r2_lvl1_match":"Retencion del impuesto de 15% practicada sobre retiros",
          "r3.2_match":"Retencione de Impuesto de 15% practicada sobre retiros",
          "r3.2_index":8,
          "length":FIELD_LENGTHS['R3.2']["Retencione de Impuesto de 15% practicada sobre retiros"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Monto de los retiros efectuados con cargo a los ahorros previsionales voluntarios realizados, Actualizados",
          "r2_lvl1_match":"Monto del Retiro proveniente de Ahorros Acogidos a Beneficio Tributario del inciso segundo del Art. 42",
          "r3.2_match":"Monto proveniente de Ahorros Acogidos a Beneficio Tributario",
          "r3.2_index":9,
          "length":FIELD_LENGTHS['R3.2']["Monto proveniente de Ahorros Acogidos a Beneficio Tributario"]
        },
    ]

    # 3) Count/Sum genérico para R3 (solo entradas con r3_match y con r2_lvl0_match)
    for conf in config:
        if 'r3_match' not in conf or 'r2_lvl0_match' not in conf:
            continue

        if conf['type'] == 'count':
            total = len(df_r2)
        else:
            total = 0.0
            lvl0 = conf['r2_lvl0_match'].lower()
            lvl1 = conf.get('r2_lvl1_match', '').lower()
            for (c0, c1), ser in df_r2.items():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    total += pd.to_numeric(ser, errors='coerce').fillna(0).sum()

        # formateo
        text = str(int(total)) if float(total).is_integer() else str(total)
        if conf.get('length', 0):
            text = text.zfill(conf['length'])

        key = _normalize(conf['r3_match'])
        if key in label_map_3:
            df3.iat[label_map_3[key], 2] = text

    # 4) Overflow de pares Entera/Decimal (match) en R3
    pairs = defaultdict(list)
    for conf in config:
        if 'match' in conf:
            pairs[conf['match']].append(conf)

    for _, group in pairs.items():
        int_conf = next(c for c in group if 'Entera' in c['r2_lvl1_match'])
        dec_conf = next(c for c in group if 'Decimal' in c['r2_lvl1_match'])

        col_int = next(col for col in df_r2.columns
                       if int_conf['r2_lvl0_match'].lower() in str(col[0]).lower()
                          and int_conf['r2_lvl1_match'].lower() in str(col[1]).lower())
        col_dec = next(col for col in df_r2.columns
                       if dec_conf['r2_lvl0_match'].lower() in str(col[0]).lower()
                          and dec_conf['r2_lvl1_match'].lower() in str(col[1]).lower())

        s_int = pd.to_numeric(df_r2[col_int], errors='coerce').fillna(0).sum()
        s_dec = pd.to_numeric(df_r2[col_dec], errors='coerce').fillna(0).sum()

        overflow = int(s_dec // 1000)
        s_int += overflow
        s_dec %= 1000

        txt_int = str(int(s_int)).zfill(int_conf['length'])
        txt_dec = str(int(s_dec)).zfill(dec_conf['length'])

        df3.iat[int_conf['r3_index'],  2] = txt_int
        df3.iat[dec_conf['r3_index'],  2] = txt_dec

    # 5) Tratamiento especial "Activo o Pensionado" en R3.2
    special = next((c for c in config if 'r3.2_match_1' in c), None)
    if special and df32 is not None:
        lvl0 = special['r2_lvl0_match'].lower()
        lvl1 = special['r2_lvl1_match'].lower()

        col_val  = next(col for col in df_r2.columns
                        if lvl0 in str(col[0]).lower() and lvl1 in str(col[1]).lower())
        col_stat = next(col for col in df_r2.columns
                        if str(col[0]).lower() == 'activo o pensionado')

        ser_val = pd.to_numeric(df_r2[col_val], errors='coerce').fillna(0)
        status  = df_r2[col_stat].astype(str)

        sum_act = ser_val[status == '1'].sum()
        sum_pen = ser_val[status == '2'].sum()

        txt1 = str(int(sum_act)).zfill(special['lengthM1'])
        txt2 = str(int(sum_pen)).zfill(special['lengthM2'])

        df32.iat[special['r3.2_indexM1'], 2] = txt1
        df32.iat[special['r3.2_indexM2'], 2] = txt2

    # 6) Resto de R3.2 (sumas simples), ahora con filtro de presencia de r2_lvl0_match
    if df32 is not None:
        for conf in config:
            if not conf.get('r3.2_index') or 'r3.2_match_1' in conf or 'r2_lvl0_match' not in conf:
                continue

            total = 0.0
            lvl0 = conf['r2_lvl0_match'].lower()
            lvl1 = conf.get('r2_lvl1_match', '').lower()
            for (c0, c1), ser in df_r2.items():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    total += pd.to_numeric(ser, errors='coerce').fillna(0).sum()

            text = str(int(total)) if float(total).is_integer() else str(total)
            if conf.get('length', 0):
                text = text.zfill(conf['length'])

            df32.iat[conf['r3.2_index'], 2] = text

def add_padding(lines):
    """
    Aplica padding final según reglas de la DJ 1899:
      - R0  (idx=0): +130 espacios al final
      - R1  (idx=1):
          1) asegurar al menos 36 caracteres
          2) insertar 6 espacios en pos 37 (índice 36)
          3) asegurar al menos 184 caracteres
          4) insertar 1 espacio en pos 184 (índice 183)
          5) +7 espacios al final
      - R2  (2 <= idx < total-2): sin cambios
      - R3  (idx == total-2): +19 espacios al final
      - R3.2(idx == total-1): +129 espacios al final
    """
    padded = []
    total = len(lines)

    for idx, line in enumerate(lines):
        if idx == 0:
            # R0
            line = line + ' ' * 130

        elif idx == 1:
            # R1
            # 1) garantizar mínimo de 36 chars
            if len(line) < 36:
                line = line.ljust(36)
            # 2) insertar 6 espacios tras el char 36
            line = line[:36] + ' ' * 6 + line[36:]
            # 3) garantizar mínimo de 184 chars
            if len(line) < 184:
                line = line.ljust(184)
            # 4) insertar 1 espacio en pos 184 (índice 183)
            line = line[:183] + ' ' + line[183:]
            # 5) padding final de 7 espacios
            line = line + ' ' * 7

        elif idx == total - 2:
            # R3
            line = line + ' ' * 19

        elif idx == total - 1:
            # R3.2
            line = line + ' ' * 129

        # R2 (2 <= idx < total-2) queda sin modificar

        padded.append(line)

    return padded
