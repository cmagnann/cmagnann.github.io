import pandas as pd

NAME = "DJ 1922"
SHEET_KEYS = ['R0', 'R1', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
}

FIELD_LENGTHS = {
    'R0': {
        "Tipo de registro":              1,
        "Año Tributario":                4,
        "Número Formulario":             4,
        "Número de RUT":                 8,
        "Dígito verificador":            1,
        "Total de Registros a transmitir": 10,
        "Código empresa":                2,
        "Número de cliente":             4,
        "Checksum declarante":           10,
        "Checksum SII":                  10,
        "Código de presentación":        1,
        "Tipo de Declaración":           1,
        "Nº de folio":                   7,
        "Día":                           2,
        "Mes":                           2,
        "Año":                           4,
        "Hora":                          2,
        "Minuto":                        2,
        "Segundo":                       4,
        "Número de Versión":             2,
        "Número de Atención":            8,
    },
    'R1': {
        # Subcampos sin header (inician con " > ")
        ' > Determina tipo': 1,
        ' > Determina orden preced.': 1,

        # Campos principales
        'Año Tributario': 6,
        'Número Formulario': 4,

        # Subcampos de presentación
        ' > Código de presentación': 1,
        ' > Nº de folio': 7,

        'Tipo de Declaración': 1,

        # Subcampos de RUT
        ' > Número de RUT': 8,
        ' > Dígito verificador': 1,

        ' > Cód.de presentación': 1,
        ' > Nº folio': 7,

        # Datos de la empresa / cliente
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,

        # Contacto telefónico
        ' > Cód Pais': 2,
        ' > Cód.  Ärea Ciudad': 2,
        ' > Teléfono': 7,

        # Repeticiones de país/ciudad/teléfono (si aplica)
        ' > Cód. empresa': 2,
        ' > Nº de cliente': 4,
        ' > Unidad': 5,
        ' > Número de caja': 3,
        ' > Número de paquete': 5,
    },

    'R2': {
        "Tipo de registro": 1,
        "Número Formulario": 4,
        "Folio > Código de presentación": 1,
        "Folio > Nº de folio": 7,
        "Tipo de Declaración": 1,
        "Rut Declarante > Nº de RUT": 8,
        "Rut Declarante > Díg.verificador": 1,
        "Número de Sección": 1,
        "Rut Administradora > Nº de RUT": 8,
        "Rut Administradora > Díg.verificador": 1,
        "RUT del Fondo > Nº de RUT": 8,
        "RUT del Fondo > Díg.verificador": 1,
        "RUN del Fondo Mutuo > Nº de RUT": 8,
        "RUN del Fondo Mutuo > Díg.verificador": 1,
        "Tipo de Fondo": 1,
        "Tributa como S.A.": 1,
        "Nombre o razón Social del Partícipe o Aportante": 30,
        "RUT del Partícipe o Aportante > Nº de RUT": 8,
        "RUT del Partícipe o Aportante > Díg.verificador": 1,
        "TAX-ID": 15,
        "Código del País de Residencia del Partícipe o Aportante": 2,
        "Tipo de Operación": 1,
        "Información de los Aportes al Fondo > Fecha de la Operación": 8,
        "Información de los Aportes al Fondo > Moneda o Unidad de reajuste": 1,
        "Información de los Aportes al Fondo > Monto Nominal de Aportes al Fondo en $": 15,
        "Información de los Aportes al Fondo > Serie de Cuotas de Propiedad del Aprtícipe o Aportante": 21,
        "Información de los Aportes al Fondo > Número de Cuotas de la Serie de Propiedad del Partícipe o Aportante": 10,
        "Información de los Aportes al Fondo > Partícipe o Aportante cumple requisitos": 1,
        "Información de los Aportes al Fondo > Cuotas de Fondos que cumplen requisitos": 1,
        "Información de los Aportes al Fondo > valor de la Cuota $": 15,
        "Información de los Aportes al Fondo > Valor Mercado al cierre del ejercicio": 15,
        "Información de los Aportes al Fondo > % de Participación en el Patrimonio del fondo al cierre del ejercicio": 5,
        "Detalle de Operaciones y Movimientos > Valor Nominal cuotas rescatadas o enajenadas": 15,
        "Detalle de Operaciones y Movimientos > Cantidad de cuotas rescatadas o enajenadas": 10,
        "Detalle de Operaciones y Movimientos > Diferencia obtenida en el rescate o enajenación de cuotas de fondos (Actualizada)": 15,
        "Detalle de Operaciones y Movimientos > Diferencia obtenida en el rescate o enajenación de cuotas de Fondos de Inversión que cumplen requisitos Art.107 LIR (Actualizada)": 15,
        "Detalle de Operaciones y Movimientos > Valor Nominal Inversión Liquidada o Disminución de Capital": 15,
        "Detalle de Operaciones y Movimientos > Cantidad de cuotas sometidas a la Liquidación del Fondo o rescatadas con la ocación de la Disminución de Capital": 10,
        "Detalle de Operaciones y Movimientos > Diferencia entre valor de Cuotas a la Fecha de Liquidación del fondo o disminución de Captial y valor de Cuotas": 15,
        "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional > Con crédito por IDPC generados a contar del 01.01.2017": 15,
        "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional > Con crédito por IDPC acumulados hasta el 31.12.2016": 15,
        "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional > Con crédito por pago de IDPC voluntario": 15,
        "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional > Sin derecho a crédito": 15,
        "Renta con tributación cumplida > Rentas provenientes del registro RAP y Diferencia Inicial de sociedad acogida al ex Art. 14 TER A) LIR": 15,
        "Renta con tributación cumplida > Otras rentas percibidas Sin Prioridad en su orden de imputación": 15,
        "Renta con tributación cumplida > Exceso Distribuciones Desproporcionadas": 15,
        "Renta con tributación cumplida > Utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°20.780": 15,
        "Renta con tributación cumplida > Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681": 15,
        "Rentas exentas > RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) (ARTÍCULO 11, LEY 18.401), AFECTAS A IMPUESTO ADICIONAL": 15,
        "Rentas exentas > RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) Y/O IMPUESTO ADICIONAL (I": 15,
        "Dividendos Remesas o Distribuciones No constitutivos de renta > Monto no Constitutivos de Renta": 15,
        "Dividendos Remesas o Distribuciones No constitutivos de renta > Rentas o cantidades de fuente extranjera (RFE) según lo establecido en numeral iii de la letra B) del Art.82 de Ley N°20.712": 15,
        "Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 10%": 15,
        "Dividendos, Remesas o Distribuciones  afectas a Impto Único Tasa 4%": 15,
        "Distribuciones efectuadas mediante la Disminución del Valor de Cuota del Fondo no Imputada a Capital": 15,
        "Devoluciones de Capital": 15,
        "No sujetos a restitución generados hasta el 31/12/2019 > Sin Derecho a Devolución": 15,
        "No sujetos a restitución generados hasta el 31/12/2019 > Con Derecho a Devolución": 15,
        "No sujetos a restitución generados a contar del 01.01.2020 > Sin Derecho a Devolución": 15,
        "No sujetos a restitución generados a contar del 01.01.2020 > Con Derecho a Devolución": 15,
        "Sujetos a restitución > Sin Derecho a Devolución": 15,
        "Sujetos a restitución > Con Derecho a Devolución": 15,
        "Sujetos a restitución > Sin Derecho a Devolución.1": 15,
        "Sujetos a restitución > Con Derecho a Devolución.1": 15,
        "Crédito por IPE": 15,
        "Asociados a rentas afectas > Sin Derecho a Devolución": 15,
        "Asociados a rentas afectas > Con Derecho a Devolución": 15,
        "Asociados a rentas exentas  (artículo 11, Ley 18.401) > Sin Derecho a Devolución": 15,
        "Asociados a rentas exentas  (artículo 11, Ley 18.401) > Con Derecho a Devolución": 15,
        "Crédito por IPE": 15,
        "Crédito Impto. Tasa Adicional EX. Art. 21 LIR ($)": 15,
        "MONTO INVERSIÓN EN CUOTAS DE FONDOS DE INVERSIÓN LEY N° 18.815, ADQUIRIDAS ANTES DEL 04.06.93 (EX-ART. 32, LEY N° 18.815)": 15,
        "N° Certificado": 7,
        "RUT Fondo Mutuo de inversión > Nº de RUT": 8,
        "RUT Fondo Mutuo de inversión > Díg.verificador": 1,
        "Beneficio positivo neto percibido": 18,
        "Beneficio negativo neto percibido": 20,
        "Utilidades percibidas": 20,
        "Intereses percibidos": 20,
        "Dividendos perciibidos": 20,
        "Ganancias de capital percibidas": 20,
        "Perdidas y gastos devengados": 20,
    },
    'R3': {
        ' > Determina tipo': 1,
        ' > Determina orden preced.': 1,
        'Número Formulario': 4,
        ' > Código de presentación': 1,
        ' > Nº de folio': 7,
        ' > Nº de RUT': 8,
        ' > Díg.verificador': 1,
        'Total de Operaciones Informadas': 10,
        'DIFERENCIA OBTENIDA EN LA ENAJENACIÓN O RESCATE DE CUOTAS (ACTUALIZADA)': 18,
        'Diferencia obtenida en el rescate o enajenación de cuotas de Fondos de Inversión que cumplen requisitos Art.107 LIR (Actualizada)': 18,
        'Diferencia entre valor de Cuotas a la Fecha de Liquidación del fondo o disminución de Captial y Valor de Cuotas': 18,
        ' > Con crédito por IDPC generados a contar del 01.01.2017': 18,
        ' > Con crédito por IDPC generados hasta el 31.12.2016': 18,
        ' > Con crédito por pado de IDPC voluntario': 18,
        ' > Sin derecho a crédito': 18,
        ' > Rentas provenientes del registro RAP y Diferencia Inicial de sociedad acogida al ex Art. 14 TER A) LIR': 18,
        ' > Otras rentas percibidas Sin Prioridad en su orden de imputación': 18,
        ' > Exceso Distribuciones Desproporcionadas': 18,
        ' > Utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°20.780': 18,
        ' > Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681': 18,
        ' > RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) (ARTÍCULO 11, LEY 18.401), AFECTAS A IMPUESTO ADICIONAL': 18,
        ' > RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) Y/O IMPUESTO ADICIONAL (IA)': 18,
        ' > No Constutivos de Renta': 18,
        ' > Rentas o cantidades de fuente extranjera (RFE) según lo establecido en numeral iii de la letra B) del Art.82 de Ley N°20.712': 18,
        'Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 10%': 18,
        'Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 4%': 18,
        'Distribuciones efectuadas mediante la Disminución del Valor de Cuota del Fondo no Imputada a Capital': 18,
        'Devoluciones de Capital': 18,
        ' > Sin Derecho a Devolución': 18,
        ' > Con Derecho a Devolución': 18,
        'Crédito por IPE': 18,
        'Crédito Impto. Tasa Adicional EX. Art. 21 LIR ($)': 18,
        'MONTO INVERSIÓN EN CUOTAS DE FONDOS DE INVERSIÓN LEY N° 18.815, ADQUIRIDAS ANTES DEL 04.06.93 (EX-ART. 32, LEY N° 18.815)': 18,
        'Beneficio positivo neto percibido': 18,
        'Beneficio negativo neto percibido': 18,
        'Utilidades percibidas': 18,
        'Intereses percibidos': 18,
        'Dividendos perciibidos': 18,
        'Ganancias de capital percibidas': 18,
        'Perdidas y gastos devengados': 18,
        ' > día': 2,
        ' > mes': 3,
        ' > año': 4,
        ' > Nº de RUT': 8,
        ' > Dígito verific.': 1,
    }
}


def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames,
    asegurando que la columna de datos (índice 2) se lea como texto
    para preservar ceros a la izquierda.
    """
    dfs = {}

    # Para R0, R1 y R3 forzamos dtype=str en toda la hoja y rellenamos NaN con ''
    for key in ['R0', 'R1', 'R3']:
        dfs[key] = (
            pd.read_excel(path_excel,
                          sheet_name=SHEET_MAP[key],
                          header=None,
                          dtype=str)
              .fillna('')
        )

    # R2 ya lo tenías correcto
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )

    return dfs


def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera las líneas crudas:
      - R0 y R1: concatenación de todos sus campos, aplicando zero‐fill
      - R2: una línea por cada fila, concatenando columnas con zero‐fill
      - R3: concatenación de todos sus campos, aplicando zero‐fill
    Devuelve: [line0, line1] + filas_R2 + [line3]
    """
    lines = []

    # — R0 —
    df0 = dfs['R0']
    parts0 = []
    for i in range(1, len(df0)):
        hdr, sub, val = df0.iat[i,0], df0.iat[i,1], df0.iat[i,2]
        if pd.isna(val) or str(val).strip() == "":
            continue
        sub_txt = str(sub).strip() if pd.notna(sub) else ""
        label = f"{hdr.strip()} > {sub_txt}" if sub_txt else hdr.strip()
        txt = str(val).strip()
        length = FIELD_LENGTHS['R0'].get(label)
        if length is not None:
            txt = txt.zfill(length)
        parts0.append(txt)
    lines.append(''.join(parts0))

    # — R1 —
    df1 = dfs['R1']
    parts1 = []
    for i in range(1, len(df1)):
        hdr, sub, val = df1.iat[i,0], df1.iat[i,1], df1.iat[i,2]
        if pd.isna(val) or str(val).strip() == "":
            continue
        sub_txt = str(sub).strip() if pd.notna(sub) else ""
        label = f"{hdr.strip()} > {sub_txt}" if sub_txt else hdr.strip()
        txt = str(val).strip()
        length = FIELD_LENGTHS['R1'].get(label)
        if length is not None:
            txt = txt.zfill(length)
        parts1.append(txt)
    lines.append(''.join(parts1))

    # — R2 (con padding especial) —
    rows = []
    for _, row in df_r2.dropna(how='all').iterrows():
        parts = []
        for (lvl0, lvl1), v in zip(df_r2.columns, row.values):
            txt = str(v).strip() if pd.notna(v) else ""
            # definir etiqueta
            if str(lvl1).lower().startswith("unnamed"):
                label = str(lvl0).strip()
            else:
                label = f"{lvl0.strip()} > {lvl1.strip()}"

            length = FIELD_LENGTHS['R2'].get(label)
            if length is not None:
                # padding a la derecha para nombre y TAX-ID
                if label in (
                    "Nombre o razón Social del Partícipe o Aportante",
                    "TAX-ID"
                ):
                    txt = txt.ljust(length)
                # padding a la izquierda con espacios para serie de cuotas
                elif label == (
                    "Información de los Aportes al Fondo > Serie de Cuotas de Propiedad del Aprtícipe o Aportante"
                ):
                    txt = txt.rjust(length)
                # cero‐fill para el resto
                else:
                    txt = txt.zfill(length)

            parts.append(txt)
        rows.append(''.join(parts))
    lines.extend(rows)

    # — R3 —
    df3 = dfs['R3']
    parts3 = []
    for i in range(1, len(df3)):
        hdr, sub, val = df3.iat[i,0], df3.iat[i,1], df3.iat[i,2]
        if pd.isna(val) or str(val).strip() == "":
            continue
        sub_txt = str(sub).strip() if pd.notna(sub) else ""
        label = f"{hdr.strip()} > {sub_txt}" if sub_txt else hdr.strip()
        txt = str(val).strip()
        length = FIELD_LENGTHS['R3'].get(label)
        if length is not None:
            txt = txt.zfill(length)
        parts3.append(txt)
    lines.append(''.join(parts3))

    return lines



def update_r3_from_r2(dfs, df_r2):

    df3 = dfs['R3']


    # 1) Mapeo etiqueta → fila (saltamos la fila 0 de headers)
    label_to_row = {}
    for i in range(1, len(df3)):
        h0 = str(df3.iat[i,0]).strip()
        h1 = df3.iat[i,1]
        if pd.notna(h1) and str(h1).strip():
            label = f"{h0} > {str(h1).strip()}"
        else:
            label = h0
        label_to_row[label.lower()] = i

    # — Configuración unificada —
    config = [
        {
            "type":           "count",
            "r3_match":       "TOTAL DE OPERACIONES INFORMADAS",
            "r3_index":       11,
            "length":         FIELD_LENGTHS['R3']["Total de Operaciones Informadas"]

        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "detalle de operaciones y movimientos",
            "r2_lvl1_match":  "diferencia obtenida en el rescate o enajenación de cuotas de fondos (actualizada)",
            "r3_match":       "DIFERENCIA OBTENIDA EN LA ENAJENACIÓN O RESCATE DE CUOTAS (ACTUALIZADA)",
            "r3_index":       12,
            "length":         FIELD_LENGTHS['R3']["DIFERENCIA OBTENIDA EN LA ENAJENACIÓN O RESCATE DE CUOTAS (ACTUALIZADA)"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "detalle de operaciones y movimientos",
            "r2_lvl1_match":  "diferencia obtenida en el rescate o enajenación de cuotas de fondos de inversión que cumplen requisitos art.107 lir (actualizada)",
            "r3_match":       "Diferencia obtenida en el rescate o enajenación de cuotas de Fondos de Inversión que cumplen requisitos Art.107 LIR (Actualizada)",
            "r3_index":       13,
            "length":         FIELD_LENGTHS['R3']["Diferencia obtenida en el rescate o enajenación de cuotas de Fondos de Inversión que cumplen requisitos Art.107 LIR (Actualizada)"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "detalle de operaciones y movimientos",   # pon aquí el nivel 0 que corresponda
            "r2_lvl1_match":  "diferencia entre valor de cuotas a la fecha de liquidación del fondo o disminución de captial y valor de cuotas",
            "r3_match":       "Diferencia entre valor de Cuotas a la Fecha de Liquidación del fondo o disminución de Captial y Valor de Cuotas",
            "r3_index":       14,
            "length":         FIELD_LENGTHS['R3']["Diferencia entre valor de Cuotas a la Fecha de Liquidación del fondo o disminución de Captial y Valor de Cuotas"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "con crédito por idpc generados a contar del 01.01.2017",
            "r3_match":       "Con crédito por IDPC generados a contar del 01.01.2017",
            "r3_index":       17,
            "length":         FIELD_LENGTHS['R3'][" > Con crédito por IDPC generados a contar del 01.01.2017"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Con crédito por IDPC acumulados hasta el 31.12.2016",
            "r3_match":       "Con crédito por IDPC generados hasta el 31.12.2016",
            "r3_index":       18,
            "length":         FIELD_LENGTHS['R3'][" > Con crédito por IDPC generados hasta el 31.12.2016"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Con crédito por pago de IDPC voluntario",
            "r3_match":       "Con crédito por pado de IDPC voluntario",
            "r3_index":       19,
            "length":         FIELD_LENGTHS['R3'][" > Con crédito por pado de IDPC voluntario"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos Remesas o Distribuciones Afectas a G. Compl. O Adicional", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Sin derecho a crédito",
            "r3_match":       "Sin derecho a crédito",
            "r3_index":       20,
            "length":         FIELD_LENGTHS['R3'][" > Sin derecho a crédito"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Renta con tributación cumplida", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Rentas provenientes del registro RAP y Diferencia Inicial de sociedad acogida al ex Art. 14 TER A) LIR",
            "r3_match":       "Rentas provenientes del registro RAP y Diferencia Inicial de sociedad acogida al ex Art. 14 TER A) LIR",
            "r3_index":       22,
            "length":         FIELD_LENGTHS['R3'][" > Rentas provenientes del registro RAP y Diferencia Inicial de sociedad acogida al ex Art. 14 TER A) LIR"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Renta con tributación cumplida", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Otras rentas percibidas Sin Prioridad en su orden de imputación",
            "r3_match":       "Otras rentas percibidas Sin Prioridad en su orden de imputación",
            "r3_index":       23,
            "length":         FIELD_LENGTHS['R3'][" > Otras rentas percibidas Sin Prioridad en su orden de imputación"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Renta con tributación cumplida", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Exceso Distribuciones Desproporcionadas",
            "r3_match":       "Exceso Distribuciones Desproporcionadas",
            "r3_index":       24,
            "length":         FIELD_LENGTHS['R3'][" > Exceso Distribuciones Desproporcionadas"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Renta con tributación cumplida", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°20.780",
            "r3_match":       "Utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°20.780",
            "r3_index":       25,
            "length":         FIELD_LENGTHS['R3'][" > Utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°20.780"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Renta con tributación cumplida", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681",
            "r3_match":       "Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681",
            "r3_index":       26,
            "length":         FIELD_LENGTHS['R3'][" > Rentas generadas hasta el 31.12.1983 y/o utilidades afectadas con impuesto sustitutivo al FUT (ISFUT) Ley N°21.210 y/o con impuesto sustitutivo de impuestos finales (ISIF) Ley N° 21.681"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Rentas exentas", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) (ARTÍCULO 11, LEY 18.401), AFECTAS A IMPUESTO ADICIONAL",
            "r3_match":       "RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) (ARTÍCULO 11, LEY 18.401), AFECTAS A IMPUESTO ADICIONAL",
            "r3_index":       28,
            "length":         FIELD_LENGTHS['R3'][" > RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) (ARTÍCULO 11, LEY 18.401), AFECTAS A IMPUESTO ADICIONAL"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Rentas exentas", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) Y/O IMPUESTO ADICIONAL (I",
            "r3_match":       "RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) Y/O IMPUESTO ADICIONAL (IA)",
            "r3_index":       29,
            "length":         FIELD_LENGTHS['R3'][" > RENTAS EXENTAS DE IMPUESTO GLOBAL COMPLEMENTARIO (IGC) Y/O IMPUESTO ADICIONAL (IA)"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos Remesas o Distribuciones No constitutivos de renta", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Monto no Constitutivos de Renta",
            "r3_match":       "No Constutivos de Renta",
            "r3_index":       31,
            "length":         FIELD_LENGTHS['R3'][" > No Constutivos de Renta"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos Remesas o Distribuciones No constitutivos de renta", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "Rentas o cantidades de fuente extranjera (RFE) según lo establecido en numeral iii de la letra B) del Art.82 de Ley N°20.712",
            "r3_match":       "Rentas o cantidades de fuente extranjera (RFE) según lo establecido en numeral iii de la letra B) del Art.82 de Ley N°20.712",
            "r3_index":       32,
            "length":         FIELD_LENGTHS['R3'][" > Rentas o cantidades de fuente extranjera (RFE) según lo establecido en numeral iii de la letra B) del Art.82 de Ley N°20.712"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 10%", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "",
            "r3_match":       "Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 10%",
            "r3_index":       33,
            "length":         FIELD_LENGTHS['R3']["Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 10%"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Dividendos, Remesas o Distribuciones  afectas a Impto Único Tasa 4%", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "",
            "r3_match":       "Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 4%",
            "r3_index":       34,
            "length":         FIELD_LENGTHS['R3']["Dividendos, Remesas o Distribuciones afectas a Impto Único Tasa 4%"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Distribuciones efectuadas mediante la Disminución del Valor de Cuota del Fondo no Imputada a Capital", # nivel 0 para el segundo caso
            "r2_lvl1_match":  "",
            "r3_match":       "Distribuciones efectuadas mediante la Disminución del Valor de Cuota del Fondo no Imputada a Capital",
            "r3_index":       35,
            "length":         FIELD_LENGTHS['R3']["Distribuciones efectuadas mediante la Disminución del Valor de Cuota del Fondo no Imputada a Capital"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Devoluciones de Capital",
            "r2_lvl1_match":  "",
            "r3_match":       "Devoluciones de Capital",
            "r3_index":       36,
            "length":         FIELD_LENGTHS['R3']["Devoluciones de Capital"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "No sujetos a restitución generados hasta el 31/12/2019",
            "r2_lvl1_match":  "Sin Derecho a Devolución",
            "r3_match":       "> Sin Derecho a Devolución",
            "r3_index":       40,
            "length":         FIELD_LENGTHS['R3'][" > Sin Derecho a Devolución"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "No sujetos a restitución generados hasta el 31/12/2019",
            "r2_lvl1_match":  "Con Derecho a Devolución",
            "r3_match":       "> Con Derecho a Devolución",
            "r3_index":       41,
            "length":         FIELD_LENGTHS['R3'][" > Con Derecho a Devolución"]
        },

        # — No sujetos a restitución generados a contar del 01.01.2020 —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "No sujetos a restitución generados a contar del 01.01.2020",
            "r2_lvl1_match":  "Sin Derecho a Devolución",
            "r3_match":       "> Sin Derecho a Devolución",
            "r3_index":       43,
            "length":         FIELD_LENGTHS['R3'][" > Sin Derecho a Devolución"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "No sujetos a restitución generados a contar del 01.01.2020",
            "r2_lvl1_match":  "Con Derecho a Devolución",
            "r3_match":       "> Con Derecho a Devolución",
            "r3_index":       44,
            "length":         FIELD_LENGTHS['R3'][" > Con Derecho a Devolución"]
        },

        # — Sujetos a restitución (4 variantes) —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "Sujetos a restitución",
            "r2_lvl1_match":  "Sin Derecho a Devolución",
            "r2_index":       60, 
            "r3_match":       "> Sin Derecho a Devolución",
            "r3_index":       46,
            "length":         FIELD_LENGTHS['R3'][" > Sin Derecho a Devolución"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Sujetos a restitución",
            "r2_lvl1_match":  "Con Derecho a Devolución",
            "r2_index":       61, 
            "r3_match":       "> Con Derecho a Devolución",
            "r3_index":       47,
            "length":         FIELD_LENGTHS['R3'][" > Con Derecho a Devolución"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Sujetos a restitución",
            "r2_lvl1_match":  "Sin Derecho a Devolución.1",
            "r2_index":       62, 
            "r3_match":       "> Sin Derecho a Devolución",
            "r3_index":       49,  # mismo destino que la primera “Sin…”
            "length":         FIELD_LENGTHS['R3'][" > Sin Derecho a Devolución"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Sujetos a restitución",
            "r2_lvl1_match":  "Con Derecho a Devolución.1",
            "r2_index":       63, 
            "r3_match":       "> Con Derecho a Devolución",
            "r3_index":       50,  # mismo destino que la primera “Con…”
            "length":         FIELD_LENGTHS['R3'][" > Con Derecho a Devolución"]
        },

        # — Crédito por IPE (2 columnas en R2) —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "Crédito por IPE",
            "r2_lvl1_match":  "",
            "r2_index":       64, 
            "r3_match":       "Crédito por IPE",
            "r3_index":       51,
            "length":         FIELD_LENGTHS['R3']["Crédito por IPE"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Crédito por IPE",
            "r2_lvl1_match":  "",
            "r2_index":       69, 
            "r3_match":       "Crédito por IPE",
            "r3_index":       59,
            "length":         FIELD_LENGTHS['R3']["Crédito por IPE"]
        },

        # — Asociados a rentas afectas —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "Asociados a rentas afectas",
            "r2_lvl1_match":  "Sin Derecho a Devolución",
            "r3_match":       "> Sin Derecho a Devolución",
            "r3_index":       54,
            "length":         FIELD_LENGTHS['R3'][" > Sin Derecho a Devolución"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Asociados a rentas afectas",
            "r2_lvl1_match":  "Con Derecho a Devolución",
            "r3_match":       "> Con Derecho a Devolución",
            "r3_index":       55,
            "length":         FIELD_LENGTHS['R3'][" > Con Derecho a Devolución"]
        },

        # — Asociados a rentas exentas —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "Asociados a rentas exentas  (artículo 11, Ley 18.401)",
            "r2_lvl1_match":  "Sin Derecho a Devolución",
            "r3_match":       "> Sin Derecho a Devolución",
            "r3_index":       57,
            "length":         FIELD_LENGTHS['R3'][" > Sin Derecho a Devolución"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Asociados a rentas exentas  (artículo 11, Ley 18.401)",
            "r2_lvl1_match":  "Con Derecho a Devolución",
            "r3_match":       "> Con Derecho a Devolución",
            "r3_index":       58,
            "length":         FIELD_LENGTHS['R3'][" > Con Derecho a Devolución"]
        },

        # — Crédito Impto. Tasa Adicional EX. Art. 21 LIR ($) —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "Crédito Impto. Tasa Adicional EX. Art. 21 LIR ($)",
            "r2_lvl1_match":  "",
            "r3_match":       "Crédito Impto. Tasa Adicional EX. Art. 21 LIR ($)",
            "r3_index":       60,
            "length":         FIELD_LENGTHS['R3']["Crédito Impto. Tasa Adicional EX. Art. 21 LIR ($)"]
        },

        # — MONTO INVERSIÓN EN CUOTAS… (Ley N° 18.815) —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "MONTO INVERSIÓN EN CUOTAS DE FONDOS DE INVERSIÓN LEY N° 18.815, ADQUIRIDAS ANTES DEL 04.06.93 (EX-ART. 32, LEY N° 18.815)",
            "r2_lvl1_match":  "",
            "r3_match":       "MONTO INVERSIÓN EN CUOTAS DE FONDOS DE INVERSIÓN LEY N° 18.815, ADQUIRIDAS ANTES DEL 04.06.93 (EX-ART. 32, LEY N° 18.815)",
            "r3_index":       61,
            "length":         FIELD_LENGTHS['R3']["MONTO INVERSIÓN EN CUOTAS DE FONDOS DE INVERSIÓN LEY N° 18.815, ADQUIRIDAS ANTES DEL 04.06.93 (EX-ART. 32, LEY N° 18.815)"]
        },

        # — Beneficios netos —  
        {
            "type":           "sum",
            "r2_lvl0_match":  "Beneficio positivo neto percibido",
            "r2_lvl1_match":  "",
            "r3_match":       "Beneficio positivo neto percibido",
            "r3_index":       62,
            "length":         FIELD_LENGTHS['R3']["Beneficio positivo neto percibido"]
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Beneficio negativo neto percibido",
            "r2_lvl1_match":  "",
            "r3_match":       "Beneficio negativo neto percibido",
            "r3_index":       63,
            "length":         FIELD_LENGTHS['R3']["Beneficio negativo neto percibido"]
        },    
    ]
    # justo antes del for conf in config:
    for idx, conf in enumerate(config):
        if 'r3_match' not in conf:
            print(f"⚠️ config[{idx}] no tiene r3_match:", conf)


    for conf in config:
        if conf["type"] == "count":
            total = len(df_r2)
            matched = True
        elif "r2_index" in conf:
            # si me indicaste columna exacta, solo sumo esa
            idx = conf["r2_index"]
            serie = df_r2.iloc[:, idx].astype(str).replace('', '0')
            total = serie.astype(float).sum()
            matched = True
        else:
            total, matched = 0.0, False
            lvl0_key = conf["r2_lvl0_match"].lower()
            lvl1_key = conf.get("r2_lvl1_match", "").lower()
            for (lvl0, lvl1), series in df_r2.items():
                if lvl0_key in str(lvl0).lower() and (not lvl1_key or lvl1_key in str(lvl1).lower()):
                    matched = True
                    for v in series:
                        try:
                            total += float(str(v).strip() or 0)
                        except ValueError:
                            pass
        if conf["type"]=="sum" and not matched:
            continue

        # --- 2) formateo ---
        text = str(int(total)) if float(total).is_integer() else str(total)

        # --- 3) zero-fill según FIELD_LENGTHS['R3'] ---
        length = FIELD_LENGTHS['R3'].get(conf["r3_match"], 0)
        text = text.zfill(length)

        # --- 4) escribo en R3 ---
        if "r3_index" in conf:
            df3.iat[conf["r3_index"], 2] = text
        else:
            row = label_to_row.get(conf["r3_match"].lower())
            if row is not None:
                df3.iat[row, 2] = text

def add_padding(lines):
    """
    Aplica:
      - Inserción de 6 espacios en R1 (índice 1) entre los caracteres 38 y 39.
      - Padding final de 857 esp. en R0, 742 esp. en R1 y 211 esp. en R3.
    """
    padded = []
    total = len(lines)
    for idx, line in enumerate(lines):
        # 1) Inserción de 6 espacios en R1
        if idx == 1 and len(line) >= 38:
            line = line[:38] + ' ' * 6 + line[38:]
        # 2) Padding final según registro
        if idx == 0:
            line = line + ' ' * 857
        elif idx == 1:
            line = line + ' ' * 742
        elif idx == total - 1:
            line = line + ' ' * 211
        padded.append(line)
    return padded
