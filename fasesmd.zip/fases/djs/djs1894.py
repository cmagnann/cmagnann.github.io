import pandas as pd

NAME = "DJ 1894"
SHEET_KEYS = ['R0', 'R1', 'R1.2', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R1.2': 'Registro1.2_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
}

FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
    },
    'R1.2': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Caja > Unidad': 5,
        'Caja > Número de caja': 3,
        'Número de paquete': 5,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Tipo de Declarante': 1,
        'Rut Emisor Instrumento > Nº de RUT': 8,
        'Rut Emisor Instrumento > Díg.verificador': 1,
        'Rut participe > Nº de RUT': 8,
        'Rut participe > Díg.verificador': 1,
        'Rut Fondo Mutuo > Nº de RUT': 8,
        'Rut Fondo Mutuo > Díg.verificador': 1,
        'RUN Fondo Mutuo > Nº de RUT': 8,
        'RUN Fondo Mutuo > Díg.verificador': 1,
        'Tipo Operación': 2,
        'Sección B1: Inversiones y Reinversiones recibidas en el Ejercicio > Fecha Inversión': 8,
        'Sección B1: Inversiones y Reinversiones recibidas en el Ejercicio > Inversión Nominal': 15,
        'Sección B2: Rescates > Fecha Rescate': 8,
        'Sección B2: Rescates > Rescate Nominal': 15,
        'Sección B2: Rescates > Mayor valor': 15,
        'Sección B2: Rescates > Menor valor': 15,
        'Sección B3: Liquidaciones de Cuotas para Reinversiones inciso quinto Art.108 > Nº de RUT': 8,
        'Sección B3: Liquidaciones de Cuotas para Reinversiones inciso quinto Art.108 > Díg.verificador': 1,
        'Sección B3: Liquidaciones de Cuotas para Reinversiones inciso quinto Art.108 > Monto Reinvertido a Valor de la liquidación': 15,
        'Número de Certificado': 7,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Código de presentación': 1,
        'Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Inversión Nominal': 18,
        'Rescate Nominal': 18,
        'Mayor o menor valor actualizado > Mayor valor': 18,
        'Mayor o menor valor actualizado > Menor valor': 18,
        'Monto Reinvertido': 18,
        'Total de Casos Informados': 7,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}



def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con multi-índice y dtype=str para preservar ceros.
    Inyecta filas forzadas si fuese necesario.
    """
    dfs = {}
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R1.2'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1.2'], header=None)
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)

    # TODO: llamar a ingresar_datos(dfs) si hay inserciones forzadas
    # dfs = ingresar_datos(dfs)

    # DEBUG: muestra claves y etiquetas
    print("Claves cargadas:", list(dfs.keys()))
    for rec in SHEET_KEYS:
        df = dfs[rec]
        print(f"=== {rec}: índices y etiquetas ===")
        if rec == 'R2':
            for idx, (lvl0, lvl1) in enumerate(df.columns):
                lbl = lvl0 if str(lvl1).startswith("Unnamed") else f"{lvl0} > {lvl1}"
                print(f"{idx:3d}: {lbl}")
        else:
            current = ''
            for i in range(1, len(df)):
                hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
                if pd.notna(hdr): current = str(hdr).strip()
                if pd.notna(val):
                    sub_txt = str(sub).strip() if pd.notna(sub) else ''
                    lbl = f"{current} > {sub_txt}" if sub_txt else current
                    print(f"{i:3d}: {lbl}")
    return dfs


def ingresar_datos(dfs):
    """
    Inserta filas vacías en R1 o R3.2 si faltan etiquetas específicas.
    """
    if NAME != "DJ 1894":
        return dfs

    # TODO: implementar inserciones forzadas en R1 o R1.2 si corresponde
    # p.ej., folio anterior > Cód.de presentación antes de Nº folio

    return dfs


def generar_lines_en_memoria(dfs, df_r2):
    import pandas as pd

    def _get_val_vertical(df, label):
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            sub_txt = str(sub).strip() if pd.notna(sub) else ''
            lab = f"{current} > {sub_txt}" if sub_txt else current
            if lab == label:
                return '' if pd.isna(val) else str(val).strip()
        return ''

    lines = []

    # ——— excepciones de padding por registro ———
    # Ahora Left-space en R1:
    left_space_R1  = {
        'Razón Social o Nombre',
    }
    # R1.2 sigue con espacios a la derecha si quieres:
    right_space_R12 = {
        'Dirección Postal',
        'Comuna',
        'Correo Electrónico',
    }

    # --- R0 (igual) ---
    df0 = dfs['R0']
    parts0 = []
    for field, length in FIELD_LENGTHS['R0'].items():
        val = _get_val_vertical(df0, field)
        parts0.append(val.zfill(length) if val else '0'*length)
    lines.append(''.join(parts0))

    # --- R1 (cambia sólo aquí) ---
    df1 = dfs['R1']
    parts1 = []
    for field, length in FIELD_LENGTHS['R1'].items():
        val = _get_val_vertical(df1, field)
        if val:
            if field in left_space_R1:
                # espacios a la izquierda
                parts1.append(val.rjust(length))
            else:
                parts1.append(val.zfill(length))
        else:
            # vacío → espacios sólo en excepciones de left_space, ceros en resto
            if field in left_space_R1:
                parts1.append(' ' * length)
            else:
                parts1.append('0' * length)
    lines.append(''.join(parts1))

    # --- R1.2 ---
    df12 = dfs['R1.2']
    parts12 = []
    for field, length in FIELD_LENGTHS['R1.2'].items():
        val = _get_val_vertical(df12, field)
        if val:
            if field in right_space_R12:
                parts12.append(val.ljust(length))
            else:
                parts12.append(val.zfill(length))
        else:
            if field in right_space_R12:
                parts12.append(' ' * length)
            else:
                parts12.append('0' * length)
    lines.append(''.join(parts12))

    # --- R2 (fila a fila) ---
    df2_clean = df_r2.loc[~(df_r2 == '').all(axis=1)]
    for _, row in df2_clean.iterrows():
        parts2 = []
        for (lvl0, lvl1), raw in zip(df_r2.columns, row.values):
            hdr = str(lvl0).strip()
            sub = str(lvl1).strip()
            label = hdr if sub.startswith("Unnamed") else f"{hdr} > {sub}"
            length = FIELD_LENGTHS['R2'].get(label, 0)
            val = str(raw).strip() if pd.notna(raw) else ''
            if val:
                parts2.append(val.zfill(length))
            else:
                parts2.append('0' * length)
        lines.append(''.join(parts2))

    # --- R3: primero actualiza totales según R2 ---
    update_r3_from_r2(dfs, df_r2)

    # --- R3 final ---
    df3 = dfs['R3']
    parts3 = []
    for field, length in FIELD_LENGTHS['R3'].items():
        val = _get_val_vertical(df3, field)
        if val:
            parts3.append(val.zfill(length))
        else:
            parts3.append('0' * length)
    lines.append(''.join(parts3))

    return lines


def update_r3_from_r2(dfs, df_r2):
    """
    Rellena R3 basándose en R2 con count/sum según tu config.
    Convierte valores de R2 a numérico con errors='coerce' para tratar cadenas vacías como 0.
    """
    import pandas as pd

    df3 = dfs['R3']

    # Tu configuración personalizada:
    config = [
        {
          "type": "count",
          "r3_match": "Total de Casos Informados",
          "r3_index": 16,
          "length": FIELD_LENGTHS['R3']["Total de Casos Informados"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Sección B1: Inversiones y Reinversiones recibidas en el Ejercicio",
          "r2_lvl1_match":"Inversión Nominal",
          "r3_match":"Inversión Nominal",
          "r3_index":10,
          "length":FIELD_LENGTHS['R3']["Inversión Nominal"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Sección B2: Rescates",
          "r2_lvl1_match":"Rescate Nominal",
          "r3_match":"Rescate Nominal",
          "r3_index":11,
          "length":FIELD_LENGTHS['R3']["Rescate Nominal"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Sección B2: Rescates",
          "r2_lvl1_match":"Mayor valor",
          "r3_match":"Mayor o menor valor actualizado > Mayor valor",
          "r3_index":13,
          "length":FIELD_LENGTHS['R3']["Mayor o menor valor actualizado > Mayor valor"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Sección B2: Rescates",
          "r2_lvl1_match":"Menor valor",
          "r3_match":"Mayor o menor valor actualizado > Menor valor",
          "r3_index":14,
          "length":FIELD_LENGTHS['R3']["Mayor o menor valor actualizado > Menor valor"]
        },
        {
          "type":"sum",
          "r2_lvl0_match":"Sección B3: Liquidaciones de Cuotas para Reinversiones inciso quinto Art.108",
          "r2_lvl1_match":"Monto Reinvertido a Valor de la liquidación",
          "r3_match":"Monto Reinvertido",
          "r3_index":15,
          "length":FIELD_LENGTHS['R3']["Monto Reinvertido"]
        },
    ]

    for conf in config:
        if conf["type"] == "count":
            total = len(df_r2)
        else:
            total = 0.0
            lvl0 = conf["r2_lvl0_match"].lower()
            lvl1 = conf["r2_lvl1_match"].lower()
            # Itera sobre cada columna multi-índice
            for (c0, c1), series in df_r2.items():
                if lvl0 in str(c0).lower() and (not lvl1 or lvl1 in str(c1).lower()):
                    # Convertir a numérico, tratar cadenas vacías como NaN → luego fillna(0)
                    nums = pd.to_numeric(series, errors="coerce").fillna(0)
                    total += nums.sum()

        # Formatear con ceros a la izquierda si length > 0
        text = str(int(total)) if float(total).is_integer() else str(total)
        length = conf.get("length", 0)
        if length:
            text = text.zfill(length)

        # Escribir en la posición indicada de R3
        df3.iat[conf["r3_index"], 2] = text


def add_padding(lines):
    """
    Aplica padding final según reglas de DJ 1894:
      - R0 (idx=0): +83 espacios al final
      - R1 (idx=1):
         • asegurar al menos 36 chars
         • insertar 6 espacios en pos 37 (índice 36)
         • luego agregar 88 espacios al final
      - R1.2 (idx=2): +46 espacios al final
      - R2 (2 < idx < total-1): sin cambios
      - R3 (idx == total-1): +31 espacios al final
    """
    padded = []
    total = len(lines)
    for idx, line in enumerate(lines):
        if idx == 0:
            # R0
            line = line + ' ' * 83

        elif idx == 1:
            # R1: inyectamos primero 6 espacios tras el char 36
            if len(line) < 36:
                line = line.ljust(36)
            # ahora insertamos 6 espacios
            line = line[:36] + ' ' * 6 + line[36:]
            # finalmente, los 88 al final
            line = line + ' ' * 88

        elif idx == 2:
            # R1.2
            line = line + ' ' * 46

        elif idx == total - 1:
            # R3
            line = line + ' ' * 31

        # R2 (los índices entre 3 y total-2) no se tocan

        padded.append(line)

    return padded
