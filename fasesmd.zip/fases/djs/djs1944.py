import pandas as pd

NAME = "DJ 1944"
SHEET_KEYS = ['R0', 'R1', 'R2', 'R3']
SHEET_MAP = {
    'R0': 'Registro0_Validacion',
    'R1': 'Registro1.1_Validacion',
    'R2': 'Registro2_Validacion',
    'R3': 'Registro3.1_Validacion',
}

FIELD_LENGTHS = {
    'R0': {
        'Tipo de registro': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Total de Registros a transmitir': 10,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Checksum declarante': 10,
        'Checksum SII': 10,
        'Código de presentación': 1,
        'Tipo de Declaración': 1,
        'Nº de folio': 7,
        'Fecha de envío > Día': 2,
        'Fecha de envío > Mes': 2,
        'Fecha de envío > Año': 4,
        'Hora de envío > Hora': 2,
        'Hora de envío > Minuto': 2,
        'Hora de envío > Segundo': 4,
        'Número de Versión': 2,
        'Número de Atención': 8,
    },
    'R1': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Año Tributario': 4,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'RUT  anterior > Número de RUT': 8,
        'RUT  anterior > Dígito verificador': 1,
        'Folio anterior > Cód.de presentación': 1,
        'Folio anterior > Nº folio': 7,
        'Rut Declarante > Número de RUT': 8,
        'Rut Declarante > Dígito verificador': 1,
        'Razón Social o Nombre': 30,
        'Dirección Postal': 35,
        'Comuna': 15,
        'Correo Electrónico': 30,
        'Nº de Fax > Cód Pais': 2,
        'Nº de Fax > Cód.  Ärea Ciudad': 2,
        'Nº de Fax > Teléfono': 7,
        'Nº de Teléfono > Cód Pais': 2,
        'Nº de Teléfono > Cód.  Ärea Ciudad': 2,
        'Nº de Teléfono > Teléfono': 7,
        'Código certificación > Código empresa': 2,
        'Código certificación > Número de cliente': 4,
        'Localización del docto. > Unidad': 5,
        'Localización del docto. > Número de caja': 3,
        'Localización del docto. > Número de paquete': 5,
    },
    'R2': {
        'Tipo de registro': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Tipo de Declaración': 1,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Rut del Inversionista > Nº de RUT': 8,
        'Rut del Inversionista > Díg.verificador': 1,
        'Rut Institución titular de la Inversión > Nº de RUT': 8,
        'Rut Institución titular de la Inversión > Díg.verificador': 1,
        'Inversiones efectuadas con anterioridad del 01.08.98 > Saldo de Ahorro Neto del ejercicio Negativo': 15,
        'Inversiones efectuadas con anterioridad del 01.08.98 > Saldo Arrastre ejercicio siguiente': 15,
        'Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014 > Saldo deAhorro Neto del ejercicio Negativo': 15,
        'Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014 > Saldo de Arrastre ejercicio siguiente Negativo': 15,
        'Monto retiro inv. 57 BIS hasta 31.12.2014': 15,
        'Saldo de Ahorro Neto del ejercicio > Negativo': 15,
        'Saldo de Ahorro Neto del ejercicio > Saldo de arrastre ejercicios siguientes Negativo': 15,
        'Monto Retiro del año': 15,
        'Monto Rentabilidad o ganancia retirada en FFMM > Positiva': 15,
        'Monto Rentabilidad o ganancia retirada en FFMM > Negativa': 15,
        'Monto Rentabilidad o ganancia retirada en Otros instrumentos > Positiva': 15,
        'Monto Rentabilidad o ganancia retirada en Otros instrumentos > Negativa': 15,
        'Número de Certificado': 7,
    },
    'R3': {
        'Tipo de registro > Determina tipo': 1,
        'Tipo de registro > Determina orden preced.': 1,
        'Número Formulario': 4,
        'Folio > Código de presentación': 1,
        'Folio > Nº de folio': 7,
        'Rut Declarante > Nº de RUT': 8,
        'Rut Declarante > Díg.verificador': 1,
        'Inversiones efectuadas con anterioridad del 01.08.98 > Saldo de Ahorro Neto del ejercicio Negativo': 15,
        'Inversiones efectuadas con anterioridad del 01.08.98 > Saldo Arrastre ejercicio siguiente': 15,
        'Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014 > Saldo deAhorro Neto del ejercicio Negativo': 15,
        'Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014 > Saldo de Arrastre ejercicio siguiente Negativo': 15,
        'Monto retiro inv. 57 BIS hasta 31.12.2014': 15,
        'Saldo de Ahorro Neto del ejercicio > Negativo': 15,
        'Saldo de Ahorro Neto del ejercicio > Saldo de arrastre ejercicios siguientes Negativo': 15,
        'Monto Retiro del año': 15,
        'Monto Rentabilidad o ganancia retirada en FFMM > Positiva': 15,
        'Monto Rentabilidad o ganancia retirada en FFMM > Negativa': 15,
        'Monto Rentabilidad o ganancia retirada en Otros instrumentos > Positiva': 15,
        'Monto Rentabilidad o ganancia retirada en Otros instrumentos > Negativa': 15,
        'Tipo Declarante': 1,
        'Total de Casos Informados': 7,
        'Fecha de Presentación > día': 2,
        'Fecha de Presentación > mes': 3,
        'Fecha de Presentación > año': 4,
        'Rut Representante legal > Nº de RUT': 8,
        'Rut Representante legal > Dígito verific.': 1,
    },
}

def print_fields(dfs):
    """
    Imprime en consola todos los labels de R0, R1, R2 y R3
    para ayudarte a definir FIELD_LENGTHS.
    """
    # — R0, R1 y R3 (verticales de 3 columnas) —
    for rec in ['R0', 'R1', 'R3']:
        df = dfs[rec]
        print(f"\n=== {rec}: campos ===")
        current = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            if pd.notna(hdr):
                current = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current} > {sub_txt}" if sub_txt else current
                print(label)

    # — R2 (multi-índice de columnas) —
    df2 = dfs['R2']
    print("\n=== R2: índices de columnas ===")
    for idx, (lvl0, lvl1) in enumerate(df2.columns):
        label = (
            lvl0.strip() if str(lvl1).startswith("Unnamed")
            else f"{lvl0.strip()} > {str(lvl1).strip()}"
        )
        print(f"{idx:3d}: {label}")

    # — R3 (índice de filas) —
    df3 = dfs['R3']
    print("\n=== R3: índices de filas ===")
    for i in range(1, len(df3)):
        hdr = str(df3.iat[i,0]).strip()
        sub = df3.iat[i,1]
        if pd.isna(sub) or not str(sub).strip():
            label = hdr
        else:
            label = f"{hdr} > {str(sub).strip()}"
        print(f"{i:3d}: {label}")
    print("\n" + "="*50 + "\n")


def load_dfs(path_excel):
    """
    Lee cada hoja según SHEET_MAP y devuelve un dict de DataFrames.
    R2 con header=[0,1] y dtype=str para preservar ceros.
    """
    # 1) Cargo todas las hojas
    dfs = {}
    dfs['R0'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R0'], header=None)
    dfs['R1'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R1'], header=None)
    dfs['R2'] = (
        pd.read_excel(path_excel,
                      sheet_name=SHEET_MAP['R2'],
                      header=[0,1],
                      dtype=str)
          .fillna('')
    )
    dfs['R3'] = pd.read_excel(path_excel, sheet_name=SHEET_MAP['R3'], header=None)

    # 2) ¡Aquí imprimimos TODO antes de devolver dfs!
    print("\n>>> DJ 1944 cargado, ahora imprimiendo índices y etiquetas:\n")
    print_fields(dfs)

    df1 = dfs['R1']
    print("=== R1: índices de filas ===")
    current_hdr = ""
    for i in range(1, len(df1)):
        hdr = df1.iat[i, 0]
        sub = df1.iat[i, 1]
        # actualiza header si no es NaN
        if pd.notna(hdr):
            current_hdr = str(hdr).strip()
        # construye etiqueta completa
        if pd.notna(df1.iat[i,2]):  # sólo filas con valor
            sub_txt = str(sub).strip() if pd.notna(sub) else ""
            label = f"{current_hdr} > {sub_txt}" if sub_txt else current_hdr
            print(f"{i:3d}: {label}")

    # 3) Finalmente devolvemos los dfs
    return dfs



def generar_lines_en_memoria(dfs, df_r2):
    """
    Genera la lista de líneas [R0, R1, filas de R2, R3] usando los dfs en memoria.
    Por ahora aplica padding muy básico; ajusta según FIELD_LENGTHS luego.
    """
    lines = []

    # --- R0 ---
    df0 = dfs['R0']
    parts0 = []
    for i in range(1, len(df0)):
        val = df0.iat[i,2]
        if pd.notna(val):
            parts0.append(str(val))
    lines.append(''.join(parts0))

    # --- R1 ---
    df1 = dfs['R1']
    parts1 = []
    for i in range(1, len(df1)):
        val = df1.iat[i,2]
        if pd.notna(val):
            parts1.append(str(val))
    lines.append(''.join(parts1))

    # --- R2 (fila por fila) ---
    for _, row in df_r2.dropna(how='all').iterrows():
        parts2 = []
        for (lvl0, lvl1), v in zip(df_r2.columns, row.values):
            txt = v or ''
            # Ejemplo de padding específico:
            # if lvl0.strip() == 'TAX-ID':
            #     txt = txt.ljust(15)
            # elif lvl0.strip().startswith('Nombre o razón Social'):
            #     txt = txt.ljust(30)
            # elif (lvl0.strip() == 'Información de los Aportes al Fondo'
            #       and lvl1.strip().startswith('Serie de Cuotas')):
            #     txt = txt.rjust(21)
            parts2.append(txt)
        lines.append(''.join(parts2))

    # --- R3 ---
    df3 = dfs['R3']
    parts3 = []
    for i in range(1, len(df3)):
        val = df3.iat[i,2]
        if pd.notna(val):
            parts3.append(str(val))
    lines.append(''.join(parts3))

    return lines


def update_r3_from_r2(dfs, df_r2):
    df3 = dfs['R3']

    # 1) Mapeo etiqueta→fila en R3
    label_to_row = {}
    for i in range(1, len(df3)):
        hdr_txt = str(df3.iat[i, 0]).strip()
        sub = df3.iat[i, 1]
        sub_txt = str(sub).strip() if pd.notna(sub) else ""
        if sub_txt:
            label = f"{hdr_txt} > {sub_txt}"
        else:
            label = hdr_txt
        label_to_row[label.lower()] = i

    # 2) Tu lista de config (13 items)
    config = [
        {
            "type":     "count",
            "r3_match": "Total de Casos Informados",
            "r3_index": 30,
            "length":   7,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Inversiones efectuadas con anterioridad del 01.08.98",
            "r2_lvl1_match":  "Saldo de Ahorro Neto del ejercicio Negativo",
            "r3_match":       "Inversiones efectuadas con anterioridad del 01.08.98 > Saldo de Ahorro Neto del ejercicio Negativo",
            "r3_index":       11,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Inversiones efectuadas con anterioridad del 01.08.98",
            "r2_lvl1_match":  "Saldo Arrastre ejercicio siguiente",
            "r3_match":       "Inversiones efectuadas con anterioridad del 01.08.98 > Saldo Arrastre ejercicio siguiente",
            "r3_index":       12,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014",
            "r2_lvl1_match":  "Saldo deAhorro Neto del ejercicio Negativo",
            "r3_match":       "Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014 > Saldo deAhorro Neto del ejercicio Negativo",
            "r3_index":       14,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014",
            "r2_lvl1_match":  "Saldo de Arrastre ejercicio siguiente Negativo",
            "r3_match":       "Inversiones efectuadas a contar del 01.08.98 hasta el 31.12.2014 > Saldo de Arrastre ejercicio siguiente Negativo",
            "r3_index":       15,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "",  # completar si lvl0 no está vacío
            "r2_lvl1_match":  "Monto retiro inv. 57 BIS hasta 31.12.2014",
            "r3_match":       "Monto retiro inv. 57 BIS hasta 31.12.2014",
            "r3_index":       16,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Saldo de Ahorro Neto del ejercicio",
            "r2_lvl1_match":  "Negativo",
            "r3_match":       "Saldo de Ahorro Neto del ejercicio > Negativo",
            "r3_index":       19,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Saldo de Ahorro Neto del ejercicio",
            "r2_lvl1_match":  "Saldo de arrastre ejercicios siguientes Negativo",
            "r3_match":       "Saldo de Ahorro Neto del ejercicio > Saldo de arrastre ejercicios siguientes Negativo",
            "r3_index":       20,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "",  # completar si lvl0 no está vacío
            "r2_lvl1_match":  "Monto Retiro del año",
            "r3_match":       "Monto Retiro del año",
            "r3_index":       22,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Monto Rentabilidad o ganancia retirada en FFMM",
            "r2_lvl1_match":  "Positiva",
            "r3_match":       "Monto Rentabilidad o ganancia retirada en FFMM > Positiva",
            "r3_index":       24,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Monto Rentabilidad o ganancia retirada en FFMM",
            "r2_lvl1_match":  "Negativa",
            "r3_match":       "Monto Rentabilidad o ganancia retirada en FFMM > Negativa",
            "r3_index":       25,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Monto Rentabilidad o ganancia retirada en Otros instrumentos",
            "r2_lvl1_match":  "Positiva",
            "r3_match":       "Monto Rentabilidad o ganancia retirada en Otros instrumentos > Positiva",
            "r3_index":       27,
            "length":         15,
        },
        {
            "type":           "sum",
            "r2_lvl0_match":  "Monto Rentabilidad o ganancia retirada en Otros instrumentos",
            "r2_lvl1_match":  "Negativa",
            "r3_match":       "Monto Rentabilidad o ganancia retirada en Otros instrumentos > Negativa",
            "r3_index":       28,
            "length":         15,
        },
    ]

    # 3) Procesar cada config y escribir en R3
    for conf in config:
        # 3.1) calcular total
        if conf["type"] == "count":
            total = len(df_r2)
        else:
            total = 0.0
            lvl0_key = conf["r2_lvl0_match"].lower()
            lvl1_key = conf["r2_lvl1_match"].lower()
            for (lvl0, lvl1), series in df_r2.iteritems():
                if (not lvl0_key or lvl0_key in lvl0.lower()) and \
                   (not lvl1_key or lvl1_key in lvl1.lower()):
                    total += series.astype(float).sum()

        # 3.2) formatear texto y aplicar zfill
        text = str(int(total)) if float(total).is_integer() else str(total)
        if conf.get("length"):
            text = text.zfill(conf["length"])

        # 3.3) escribir en R3
        if conf.get("r3_index") is not None:
            df3.iat[conf["r3_index"], 2] = text
        else:
            row = label_to_row.get(conf["r3_match"].lower())
            if row is not None:
                df3.iat[row, 2] = text

def add_padding(lines):
    """
    Aplica los paddings e inserciones para DJ 1944:
      1) En R1 (idx=1):
         - Inserta 6 espacios justo después del carácter 36.
         - Inserta 1 espacio justo antes del carácter 184.
      2) Padding final:
         - R0 (idx=0): +140 espacios
         - R1 (idx=1): +26 espacios
         - R2 (idx 2..n-2): +1 espacio
         - R3 (idx=n-1): +211 espacios
    """
    padded = []
    total = len(lines)
    for idx, line in enumerate(lines):
        # — Lógica especial para R1 —
        if idx == 1:
            # 1) Inserción de 6 espacios a los 36 caracteres
            if len(line) > 36:
                line = line[:36] + ' ' * 6 + line[36:]
            else:
                line = line.ljust(36) + ' ' * 6

            # 2) Inserción de 1 espacio antes del carácter 184 (índice 184)
            insert_pos = 184
            if len(line) > insert_pos:
                line = line[:insert_pos] + ' ' + line[insert_pos:]
            else:
                line = line.ljust(insert_pos) + ' '

        # — Padding final según tipo de registro —
        if idx == 0:
            # R0
            line = line.ljust(len(line) + 140)
        elif idx == 1:
            # R1
            line = line.ljust(len(line) + 26)
        elif 2 <= idx < total - 1:
            # R2
            line = line.ljust(len(line) + 1)
        else:
            # R3 (última línea)
            line = line.ljust(len(line) + 211)

        padded.append(line)
    return padded
