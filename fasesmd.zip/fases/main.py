import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import pkgutil, importlib
from pathlib import Path
import pandas as pd
import threading


# -------------------------------------------------------------------
# 1) Descubre y carga dinámicamente todos los módulos en la carpeta djs
# -------------------------------------------------------------------
DJ_MODULES = {}
import djs  # asegúrate de tener __init__.py en djs/

DJ_MODULES = {}
for finder, name, ispkg in pkgutil.iter_modules(djs.__path__):
    module = importlib.import_module(f'djs.{name}')
    DJ_MODULES[module.NAME] = module

print("DJs disponibles:", list(DJ_MODULES.keys()))


class RegistroEditorApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self._mod_all_entry = None
        self._mod_all_apply = None

        self.main_frame = ttk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        style = ttk.Style(self)
        style.configure("Handle.TFrame", background="black")
        # forzar que el Treeview siga mostrando selection aun desenfocado
        style.map("Treeview",
            background=[("selected", "skyblue")],
            foreground=[("selected", "black")]
        )

        self.title("Editor de Registros")
        self.geometry("900x600")

        # Estado
        self.current_module = None  # módulo del DJ seleccionado
        self.dfs = {}               # DataFrames cargados
        self.df_r2 = None
        self.page_size = 200
        self.current_page = 0
        self.current_r2_df = None
        self.page_label = None
        self.registros_path = None

        # UI
        self.main_frame = ttk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self._build_selector()

    def _build_selector(self):
        """Construye la vista inicial: selección de DJ y registro, restaurando la DJ elegida."""
        # limpia pantalla
        for w in self.main_frame.winfo_children():
            w.destroy()

        # 1) Selector de DJ
        ttk.Label(self.main_frame, text="Seleccione DJ:").pack(pady=(10,2))
        dj_values = list(DJ_MODULES.keys())
        self.dj_combo = ttk.Combobox(
            self.main_frame,
            values=dj_values,
            state="readonly",
            width=30
        )
        # restaura selección si ya había una
        if hasattr(self, 'selected_dj_name') and self.selected_dj_name in dj_values:
            self.dj_combo.current(dj_values.index(self.selected_dj_name))
        else:
            self.dj_combo.current(0)
            # inicializar selected_dj_name la primera vez
            self.selected_dj_name = dj_values[0]
        self.dj_combo.bind("<<ComboboxSelected>>", self._on_dj_selected)
        self.dj_combo.pack(pady=(0,10))

        # 2) Etiqueta del Excel cargado
        label_text = (
            f"Archivo Excel: {os.path.basename(self.registros_path)}"
            if self.registros_path else "Archivo Excel: [ninguno]"
        )
        self.lbl_excel = ttk.Label(self.main_frame, text=label_text)
        self.lbl_excel.pack(pady=(0,10))

        # 3) Selector de registro, según módulo activo
        ttk.Label(self.main_frame, text="Seleccione registro a modificar:").pack(pady=(10,2))
        self.sel_combo = ttk.Combobox(
            self.main_frame,
            values=(self.current_module.SHEET_KEYS if self.current_module else []),
            state="readonly",
            width=30
        )
        self.sel_combo.pack(pady=(0,10))

        # 4) Botones
        btnf = ttk.Frame(self.main_frame)
        btnf.pack(pady=20)
        ttk.Button(btnf, text="Abrir Excel", command=self.cargar_archivo).pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Modificar", command=self.abrir_registro).pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Procesar datos", command=self.procesar_todo).pack(side=tk.LEFT, padx=5)

    def _on_dj_selected(self, event):
        """Al escoger una DJ, guardamos su nombre y actualizamos el segundo combobox."""
        name = self.dj_combo.get()
        self.selected_dj_name = name
        self.current_module = DJ_MODULES[name]
        # actualizar registros disponibles
        self.sel_combo['values'] = self.current_module.SHEET_KEYS
        # opcionalmente, borra selección anterior
        self.sel_combo.set('')
    
    def _add_empty_row(self):
        """
        Añade una nueva fila vacía al final de self.df_r2,
        con 'Tipo de registro' = '2' y 'Número Formulario' = '1922'.
        Luego refresca la tabla.
        """
        if self.df_r2 is None:
            return

        # 1) Calcular nuevo índice
        try:
            new_idx = int(self.df_r2.index.max()) + 1
        except:
            new_idx = 0

        # 2) Construir dict con valores por defecto
        new_row = {}
        for col in self.df_r2.columns:
            lvl0 = str(col[0]).strip()
            if lvl0 == 'Tipo de registro':
                new_row[col] = '2'
            elif lvl0 == 'Número Formulario':
                new_row[col] = '1922'
            else:
                new_row[col] = ''

        # 3) Insertar la fila en el DataFrame
        self.df_r2.loc[new_idx] = new_row

        # 4) Refrescar la vista (mantiene filtros y paginación)
        self._update_table_r2()



    def cargar_archivo(self):
        """Carga el Excel y utiliza el módulo activo para parsear."""
        if not self.current_module:
            messagebox.showwarning("Atención", "Primero selecciona una DJ.")
            return
        path = filedialog.askopenfilename(
            filetypes=[("Excel","*.xls* *.xlsx")]
        )
        if not path:
            return
        self.registros_path = path
        # 1) Leemos las hojas originales
        self.dfs = self.current_module.load_dfs(path)
        # 2) Insertamos manualmente los dos campos en blanco (sólo para DJ 1862)
        if hasattr(self.current_module, 'ingresar_datos'):
            self.dfs = self.current_module.ingresar_datos(self.dfs)
        # Si existe R2, lo guardamos aparte
        if 'R2' in self.dfs:
            self.df_r2 = self.dfs['R2']
            self.current_r2_df = self.df_r2.copy()
        self.lbl_excel.config(text=f"Archivo Excel: {os.path.basename(path)}")
        messagebox.showinfo("Listo", f"Excel cargado: {os.path.basename(path)}")

    def abrir_registro(self):
        """Muestra la UI de edición según el registro elegido."""
        reg = self.sel_combo.get()
        if not reg or reg not in self.dfs:
            messagebox.showwarning("Atención", "Selecciona un registro válido.")
            return
        if reg == 'R2':
            self._build_editor_r2()
        else:
            self._build_editor_otros(reg)

    def _build_editor_otros(self, reg):
        """UI de edición para R0, R1, R3 u otros registros sencillos."""
        df = self.dfs[reg]
        for w in self.main_frame.winfo_children(): w.destroy()
        ttk.Label(self.main_frame, text=f"Editando {reg}").pack(pady=10)

        # Lógica idéntica a la que ya tenías: construir field_combo, etc.
        # … (aquí reutilizas tu código de _build_editor_otros existente) …
        opciones, self.field_map = [], []
        cur = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i,0], df.iat[i,1], df.iat[i,2]
            # actualiza cur si hay nuevo header
            if pd.notna(hdr):
                cur = str(hdr).strip()
            # sólo para filas con valor y que NO sean LARGO DEL REGISTRO
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{cur} > {sub_txt}" if sub_txt else cur
                # filtramos los validadores de longitud
                if label.startswith("LARGO DEL REGISTRO"):
                    continue
                opciones.append(label)
                self.field_map.append(i)

        self.field_combo = ttk.Combobox(
            self.main_frame, values=opciones, state="readonly", width=60
        )
        self.field_combo.pack(pady=5)
        self.value_entry = ttk.Entry(self.main_frame, width=50)
        self.value_entry.pack(pady=5)

        self.field_combo.bind(
            "<<ComboboxSelected>>", lambda e, df=df: self._cargar_valor(df)
        )
        self.value_entry.bind(
            "<Return>", lambda e, df=df: self._guardar_valor(df)
        )

        btnf = ttk.Frame(self.main_frame); btnf.pack(pady=20)
        ttk.Button(btnf, text="Guardar cambio", command=lambda df=df: self._guardar_valor(df))\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Listo", command=self._build_selector)\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Procesar datos", command=self.procesar_todo)\
            .pack(side=tk.LEFT, padx=5)

    def _build_editor_r2(self):
        # 1) Estado inicial
        self.current_page = 0
        self.filter_vars   = {}
        self.filter_widgets= {}

        # 2) Limpia la pantalla
        for w in self.main_frame.winfo_children():
            w.destroy()

        # Título
        ttk.Label(self.main_frame, text="Editando R2 (múltiples filas)").pack(pady=5)

        # 3) Combobox de columnas
        df = self.df_r2
        nivel0 = df.columns.get_level_values(0)
        nivel1 = df.columns.get_level_values(1)
        labels, self.col_map = [], []
        for idx, (h0, h1) in enumerate(zip(nivel0, nivel1)):
            lbl = h0 if str(h1).startswith("Unnamed") else f"{h0} > {h1}"
            labels.append(lbl)
            self.col_map.append(idx)

        self.col_combo = ttk.Combobox(
            self.main_frame,
            values=labels,
            state="readonly",
            width=60
        )
        self.col_combo.pack(pady=(0,5))

        # 4) Frame de controles: “Agregar filtro” + “Modificar toda la columna”
        ctrl_frame = ttk.Frame(self.main_frame)
        ctrl_frame.pack(pady=(0,10))

        # — Botón “Agregar filtro” —
        ttk.Button(ctrl_frame,
                   text="Agregar filtro",
                   command=self._add_filter_column)\
            .pack(side=tk.LEFT, padx=5)

        # — Botón “Modificar Toda la Columna” —
        self.mod_all_btn = ttk.Button(
            ctrl_frame,
            text="Modificar Toda la Columna",
            command=self._on_modify_all_click
        )
        self.mod_all_btn.pack(side=tk.LEFT, padx=5)

        # — Contenedor para la entrada + botón “Modificar” (aún oculto) —
        self.col_modifier_frame = ttk.Frame(ctrl_frame)
        # no lo .pack() hasta que el usuario pulse “Modificar Toda la Columna”

        # — Ahora sí el frame de filtros (antes del Treeview) —
        self.filter_frame = ttk.Frame(self.main_frame)
        self.filter_frame.pack(fill=tk.X, pady=5)

        # 7) Treeview con scrollbars
        cont = ttk.Frame(self.main_frame)
        cont.pack(fill=tk.BOTH, expand=True)
        vsb = ttk.Scrollbar(cont, orient=tk.VERTICAL)
        hsb = ttk.Scrollbar(cont, orient=tk.HORIZONTAL)
        self.tree = ttk.Treeview(
            cont, show="headings",
            yscrollcommand=vsb.set,
            xscrollcommand=hsb.set,
            selectmode="extended"
        )
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)

        # 8) Bindings
        self.tree.bind("<Double-1>", self._edit_cell_r2)
        self.tree.bind("<ButtonPress-1>",   self._on_drag_start)
        self.tree.bind("<B1-Motion>",       self._on_drag_motion)
        self.tree.bind("<ButtonRelease-1>", self._on_drag_end)

        # 9) Botones final y paginación (igual que antes) …
        btnf = ttk.Frame(self.main_frame)
        btnf.pack(pady=10)
        ttk.Button(btnf, text="Guardar Cambios", command=self._guardar_cambios_r2)\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Eliminar fila", command=self._delete_row)\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Agregar fila", command=self._add_empty_row)\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Listo", command=self._build_selector)\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Procesar datos", command=self.procesar_todo)\
            .pack(side=tk.LEFT, padx=5)

        nav = ttk.Frame(self.main_frame)
        nav.pack(pady=(0,5))
        ttk.Button(nav, text="« Prev", command=self._prev_page)\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(nav, text="Next »", command=self._next_page)\
            .pack(side=tk.LEFT, padx=5)
        self.page_label = ttk.Label(self.main_frame, text="")
        self.page_label.pack()

        # 10) Finalmente, rellena la tabla
        self._update_table_r2()

    def _on_modify_all_click(self):
        # Si ya está visible, lo ocultamos y destruimos
        if getattr(self, "_mod_all_entry", None):
            self.col_modifier_frame.pack_forget()
            self._mod_all_entry.destroy()
            self._mod_all_apply.destroy()
            del self._mod_all_entry, self._mod_all_apply
            return

        # 1) Creamos la casilla de texto y el botón “Modificar”
        self._mod_all_entry = ttk.Entry(self.col_modifier_frame, width=20)
        self._mod_all_apply = ttk.Button(
            self.col_modifier_frame,
            text="Modificar",
            command=self._apply_modify_all
        )
        # 2) Los empaquetamos uno junto al otro DENTRO de col_modifier_frame
        self._mod_all_entry.pack(side=tk.LEFT, padx=(10,0))
        self._mod_all_apply.pack(side=tk.LEFT, padx=5)
        # 3) Ahora sí mostramos el frame completo
        self.col_modifier_frame.pack(side=tk.LEFT, padx=5)


    def _apply_modify_all(self, value):
        # 1) Columnas visibles en la página actual
        col_idx = self.col_combo.current()
        if col_idx < 0:
            messagebox.showwarning("Atención", "Selecciona primero una columna.")
            return

        # 2) Column real según col_map
        real_col = list(self.df_r2.columns)[ self.col_map[col_idx] ]

        # 3) Aplicar el valor a TODO el DataFrame R2
        for idx in self.df_r2.index:
            self.df_r2.at[idx, real_col] = value

        # 4) Refrescar vista
        self._update_table_r2()

        # 5) Limpiar UI de “modificar toda la columna”
        self._mod_all_entry.destroy()
        self._mod_all_apply.destroy()
        self._mod_all_entry = None
        self._mod_all_apply = None


    def _show_column_modifier(self):
        # Limpia lo que hubiera antes
        for w in self.col_modifier_frame.winfo_children():
            w.destroy()

        # Casilla de texto
        self.mod_col_entry = ttk.Entry(self.col_modifier_frame, width=30)
        self.mod_col_entry.pack(side=tk.LEFT, padx=(0,5))

        # Botón “Modificar”
        ttk.Button(
            self.col_modifier_frame,
            text="Modificar",
            command=self._apply_column_modification
        ).pack(side=tk.LEFT)

    def _apply_column_modification(self):
        val = self.mod_col_entry.get().strip()
        idx = self.col_combo.current()
        if idx < 0:
            return  # no hay columna seleccionada

        # Averigua la tupla real de column index en df_r2
        real_col = self.df_r2.columns[self.col_map[idx]]

        # Reemplaza TODOS los valores de esa columna
        self.df_r2[real_col] = val

        # Refresca la vista (y mantiene paginación / filtros)
        self._update_table_r2()

        messagebox.showinfo("Columna modificada",
                            f"Todos los valores de “{self.col_combo.get()}” se han actualizado.")



    def _add_filter_column(self):
        sel_idx = self.col_combo.current()
        if sel_idx < 0:
            return
        col_idx = self.col_map[sel_idx]
        col = self.df_r2.columns[col_idx]
        if col in self.filter_vars:
            return

        var = tk.StringVar()
        cont = ttk.Frame(self.filter_frame)
        cont.pack(side=tk.LEFT, padx=2)
        ttk.Label(cont, text=self.col_combo.get()).pack(side=tk.LEFT)
        ttk.Entry(cont, textvariable=var, width=15).pack(side=tk.LEFT)
        ttk.Button(cont, text="X", width=2, command=lambda c=col: self._remove_filter(c))\
            .pack(side=tk.LEFT, padx=(2,0))

        var.trace_add('write', lambda *a: self._update_table_r2())
        self.filter_vars[col] = var
        self.filter_widgets[col] = cont
        self._update_table_r2()
    
    def _remove_filter(self, col):
        if col in self.filter_vars:
            del self.filter_vars[col]
        if col in self.filter_widgets:
            self.filter_widgets[col].destroy()
            del self.filter_widgets[col]
        self._update_table_r2()

    def _update_table_r2(self):
        df = self.df_r2.copy()
        # filtros…
        for col, var in self.filter_vars.items():
            v = var.get().strip()
            if v:
                df = df[df[col].astype(str).str.contains(v)]

        # paginación
        total_rows = len(df)
        total_pages = (total_rows - 1) // self.page_size + 1
        start = self.current_page * self.page_size
        end   = start + self.page_size
        df_page = df.iloc[start:end]

        # refrescar Treeview
        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = list(df_page.columns)
        for c in df_page.columns:
            hdr = f"{c[0]}|{c[1]}"
            self.tree.heading(c, text=hdr)
            self.tree.column(c, width=120, stretch=False)
        for i, row in df_page.iterrows():
            self.tree.insert("", tk.END, iid=i, values=list(row))
        self.current_r2_df = df_page

        # actualizar etiqueta de página
        if self.page_label:
            self.page_label.config(
                text=f"Página {self.current_page+1} de {total_pages}"
            )



    def _edit_cell_r2(self, event):
        # 1) Identificar celda sobre la que se hizo doble‐clic
        item = self.tree.identify_row(event.y)
        col  = self.tree.identify_column(event.x)
        if not item or not col.startswith("#"):
            return
        ci = int(col.strip("#")) - 1
        bbox = self.tree.bbox(item, col)
        if not bbox:
            return
        x, y, w, h = bbox

        # 2) Crear Entry in situ
        val = self.tree.set(item, col)
        entry = ttk.Entry(self.tree)
        entry.place(x=x, y=y, width=w, height=h)
        entry.insert(0, val)
        entry.focus()

        # 3) Crear el “handle” en la esquina inferior derecha
        handle = ttk.Frame(self.tree, width=6, height=6, style="Handle.TFrame")
        handle.place(x=x + w - 6, y=y + h - 6)

        # 4) Bindings del handle
        # doble‐clic → copiar a toda la columna
        handle.bind(
            "<Double-1>",
            lambda e, r=item, c=ci: self._autofill_all(r, c)
        )
        # arrastre → drag‐fill
        handle.bind(
            "<ButtonPress-1>",
            lambda e, r=item, c=ci: self._start_autofill(e, r, c)
        )

        # 5) Al cerrar el Entry, destruimos también el handle
        def on_close(evt=None):
            entry.destroy()
            handle.destroy()
        entry.bind("<FocusOut>", on_close)

        # 6) Guardar valor con Enter
        def save(evt=None):
            new = entry.get()
            self.tree.set(item, col, new)
            real_col = list(self.current_r2_df.columns)[ci]
            self.df_r2.at[int(item), real_col] = new
            on_close()
        entry.bind("<Return>", save)

    def _guardar_cambios_r2(self):
        # Convierte todas las columnas de R2 a string para evitar warnings
        for col in self.df_r2.columns:
            self.df_r2[col] = self.df_r2[col].astype(str)
        # Refresca la tabla para que se vean los valores actualizados
        self._update_table_r2()
        # 3) Actualiza R3 a partir de R2 llamando al módulo activo
        if hasattr(self.current_module, 'update_r3_from_r2'):
            self.current_module.update_r3_from_r2(self.dfs, self.df_r2)

        messagebox.showinfo("Guardado", "Cambios en R2 (y R3) guardados correctamente.")


    def _build_editor_otros(self, reg):
        """
        Crea la UI para editar un registro sencillo (R0, R1, R3…),
        llenando el combobox con los campos no-NaN de la columna 2.
        """
        df = self.dfs[reg]
        # Limpia todo
        for w in self.main_frame.winfo_children():
            w.destroy()

        ttk.Label(self.main_frame, text=f"Editando {reg}").pack(pady=10)

        # Generar opciones (skip header fila 0)
        opciones, self.field_map = [], []
        current_hdr = ''
        for i in range(1, len(df)):
            hdr, sub, val = df.iat[i, 0], df.iat[i, 1], df.iat[i, 2]
            if pd.notna(hdr):
                current_hdr = str(hdr).strip()
            if pd.notna(val):
                sub_txt = str(sub).strip() if pd.notna(sub) else ''
                label = f"{current_hdr} > {sub_txt}" if sub_txt else current_hdr
                # Omitir validadores de longitud si quisieras:
                if label.startswith("LARGO DEL REGISTRO"):
                    continue
                opciones.append(label)
                self.field_map.append(i)

        # Combobox de campos
        self.field_combo = ttk.Combobox(
            self.main_frame, values=opciones, state="readonly", width=60
        )
        self.field_combo.pack(pady=5)
        self.field_combo.bind("<<ComboboxSelected>>",
                              lambda e, df=df: self._cargar_valor(df))

        # Entry para editar valor
        self.value_entry = ttk.Entry(self.main_frame, width=50)
        self.value_entry.pack(pady=5)
        self.value_entry.bind("<Return>",
                              lambda e, df=df: self._guardar_valor(df))

        # Botones
        btnf = ttk.Frame(self.main_frame)
        btnf.pack(pady=20)
        ttk.Button(btnf, text="Guardar cambio",
                   command=lambda df=df: self._guardar_valor(df))\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Listo",
                   command=self._build_selector)\
            .pack(side=tk.LEFT, padx=5)
        ttk.Button(btnf, text="Procesar datos",
                   command=self.procesar_todo)\
            .pack(side=tk.LEFT, padx=5)

    def _delete_row(self):
        for iid in self.tree.selection():
            self.tree.delete(iid)
            self.df_r2.drop(index=int(iid), inplace=True)

    def _cargar_valor(self, df):
        """
        Al seleccionar un campo en el combobox, carga su valor en el Entry.
        """
        idx = self.field_combo.current()
        if idx < 0:
            return
        row = self.field_map[idx]
        val = df.iat[row, 2]
        self.value_entry.delete(0, tk.END)
        self.value_entry.insert(0, val)

    def _guardar_valor(self, df):
        """
        Toma lo que haya en el Entry y lo escribe en el df en memoria.
        """
        idx = self.field_combo.current()
        if idx < 0:
            return
        row = self.field_map[idx]
        df.iat[row, 2] = self.value_entry.get()
        messagebox.showinfo("Guardado", "Cambio registrado.")

    def _procesar_y_guardar(self, path, lines_gen):
        try:
            # 1) Recolecta todas las líneas (ya filtradas y padded)
            lines = list(lines_gen())
            # 2) Escribe sin añadir newline final
            with open(path, 'w', encoding='utf-8', newline='') as f:
                if lines:
                    f.write('\n'.join(lines))
            # 3) Mensaje de éxito
            self.after(0, lambda: messagebox.showinfo(
                'Procesado', f'Archivo guardado en: {path}'
            ))
        except Exception as e:
            # capturamos e en el parámetro del lambda
            self.after(0, lambda err=e: messagebox.showerror(
                'Error', f'No se pudo guardar: {err}'
            ))


    def procesar_todo(self):
        if not self.registros_path:
            messagebox.showwarning("Atención", "Primero carga un archivo válido.")
            return

        path = filedialog.asksaveasfilename(
            parent=self,
            title='Guardar archivo como',
            initialdir=os.getcwd(),
            defaultextension='.txt',
            filetypes=[('Archivo de texto','*.txt')]
        )
        if not path:
            messagebox.showwarning('Procesar', 'Operación cancelada.')
            return

        def lines_gen():
            raw = self.current_module.generar_lines_en_memoria(self.dfs, self.df_r2)

            # — Debug: solo R1 (idx=1) y R3 (última línea) —
            if len(raw) > 1:
                print("RAW R1  (idx=1):", repr(raw[1]))
            if len(raw) > 0:
                print("RAW R3  (idx=-1):", repr(raw[-1]))

            # Luego el filtrado/padding normal:
            clean = [ str(l).rstrip() for l in raw if l is not None and str(l) != '' ]
            padded = self.current_module.add_padding(clean)
            for l in padded:
                yield l



        # Lanzamos el hilo que escribe el archivo y mostrará el diálogo al terminar
        threading.Thread(
            target=self._procesar_y_guardar,
            args=(path, lines_gen),
            daemon=True
        ).start()

    def _next_page(self):
        max_page = (len(self.df_r2) - 1) // self.page_size
        if self.current_page < max_page:
            self.current_page += 1
            self._update_table_r2()

    def _prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self._update_table_r2()

    # — Autofill handle —
    def _autofill_all(self, row_id, col_index):
        """
        Doble-clic en el handle: copia el valor SOLO hacia abajo,
        no hacia arriba.
        """
        # 1) Obtén lista de IDs de fila en el orden del Treeview
        children = list(self.tree.get_children())
        start_idx = children.index(row_id)

        # 2) Lee el valor de la celda origen
        cell_tag = f'#{col_index+1}'
        val = self.tree.set(row_id, cell_tag)

        # 3) Recorre solo las filas que vienen DESPUÉS de start_idx
        real_col = list(self.current_r2_df.columns)[col_index]
        for rid in children[start_idx+1:]:
            # 3a) Pinta en el Treeview
            self.tree.set(rid, cell_tag, val)
            # 3b) Actualiza el DataFrame subyacente
            self.df_r2.at[int(rid), real_col] = val


    def _start_autofill(self, event, row_id, col_index):
        """Marca inicio de drag-fill."""
        self._af_start = row_id
        self._af_col   = col_index
        self._dragging_fill = True
        # bind ADITIVO para no eliminar el rubber-band
        self.tree.bind("<B1-Motion>",       self._drag_autofill, add='+')
        self.tree.bind("<ButtonRelease-1>", self._end_autofill,   add='+')

    def _drag_autofill(self, event):
        if not getattr(self, '_dragging_fill', False):
            return
        row_h = self.tree.identify_row(event.y)
        if not row_h: return
        children = list(self.tree.get_children())
        i0 = children.index(self._af_start)
        i1 = children.index(row_h)
        lo, hi = sorted((i0, i1))
        val = self.tree.set(self._af_start, f'#{self._af_col+1}')
        for idx in range(lo, hi+1):
            rid = children[idx]
            self.tree.set(rid, f'#{self._af_col+1}', val)
            real_col = list(self.current_r2_df.columns)[self._af_col]
            self.df_r2.at[int(rid), real_col] = val

    def _end_autofill(self, event):
        self._dragging_fill = False
        # ya no deshacemos los binds, así preservamos el rubber-band

    def _rubberband_start(self, event):
        # empieza el rectángulo en (x,y)
        self._rb_start = (event.x, event.y)
        if self._rb_rect:
            self.sel_canvas.delete(self._rb_rect)
        self._rb_rect = self.sel_canvas.create_rectangle(
            event.x, event.y, event.x, event.y,
            dash=(2,2), outline="gray"
        )

    def _rubberband_draw(self, event):
        # actualiza el tamaño del rectángulo
        x0, y0 = self._rb_start
        self.sel_canvas.coords(self._rb_rect, x0, y0, event.x, event.y)

    def _rubberband_end(self, event):
        # al soltar, calcula intersección con cada fila
        x0, y0 = self._rb_start
        x1, y1 = event.x, event.y
        x0, x1 = sorted((x0, x1))
        y0, y1 = sorted((y0, y1))

        seleccion = []
        for iid in self.tree.get_children():
            bbox = self.tree.bbox(iid)
            if not bbox:
                continue
            bx, by, bw, bh = bbox
            # si la fila entra en el rectángulo, la agregamos
            if (bx + bw >= x0 and bx <= x1 and
                by + bh >= y0 and by <= y1):
                seleccion.append(iid)

        self.tree.selection_set(seleccion)
        self.sel_canvas.delete(self._rb_rect)
        self._rb_rect = None

    def _on_drag_start(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self._drag_start = item
            self.tree.selection_set([item])

    def _on_drag_motion(self, event):
        if not hasattr(self, "_drag_start"):
            return
        start = self._drag_start
        current = self.tree.identify_row(event.y)
        if not current:
            return
        children = list(self.tree.get_children())
        i0 = children.index(start)
        i1 = children.index(current)
        lo, hi = sorted((i0, i1))
        tosel = children[lo:hi+1]
        self.tree.selection_set(tosel)

    def _on_drag_end(self, event):
        if hasattr(self, "_drag_start"):
            del self._drag_start

    def _on_modify_all_click(self):
        """Muestra un Entry + botón ‘Modificar’ justo debajo del desplegable."""
        # Si ya está mostrado, no hacer nada
        if self._mod_all_entry:
            return

        # crea el Entry
        self._mod_all_entry = ttk.Entry(self.main_frame, width=40)
        self._mod_all_entry.pack(pady=(2,0))

        # crea el botón de aplicar
        self._mod_all_apply = ttk.Button(self.main_frame,
                                         text="Modificar",
                                         command=self._apply_modify_all)
        self._mod_all_apply.pack(pady=(0,5))

    def _apply_modify_all(self):
        """Toma el valor del entry y lo vuelca en TODAS las filas de la columna."""
        # 1) recoger valor y columna seleccionada
        new_val = self._mod_all_entry.get()
        col_idx = self.col_combo.current()
        if col_idx < 0:
            messagebox.showwarning("Atención", "Selecciona primero una columna.")
            return

        # 2) determinar la columna real en df_r2
        real_col = self.df_r2.columns[self.col_map[col_idx]]

        # 3) asignar el valor en TODO el DataFrame (todas las páginas)
        #    así actualizamos tanto la vista como el dato subyacente
        self.df_r2[real_col] = new_val

        # 4) refrescar la tabla (mantiene filtros/paginación)
        self._update_table_r2()

        # 5) limpiar el Entry y botón
        self._mod_all_entry.destroy()
        self._mod_all_apply.destroy()
        self._mod_all_entry = None
        self._mod_all_apply = None


if __name__ == '__main__':
    app = RegistroEditorApp()
    app.mainloop()